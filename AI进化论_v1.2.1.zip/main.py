"""
AI进化论 — 主入口
整合所有模块并启动 GUI
"""

import sys
import os
from pathlib import Path

# 确保项目根目录在 sys.path
ROOT = Path(__file__).parent
sys.path.insert(0, str(ROOT))

from loguru import logger
from core.config import config, VERSION


def setup_logging():
    """配置日志"""
    log_path = Path(config.get("system.log_path", "./data/logs"))
    log_path.mkdir(parents=True, exist_ok=True)

    logger.remove()
    logger.add(
        log_path / "app_{time:YYYY-MM-DD}.log",
        rotation="10 MB",
        retention="7 days",
        level=config.get("system.log_level", "INFO"),
        format="{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {name}:{function}:{line} | {message}",
    )
    logger.add(sys.stderr, level="INFO",
               format="<green>{time:HH:mm:ss}</green> | <level>{level: <8}</level> | {message}")


def check_first_run() -> bool:
    """检查是否首次运行"""
    marker = ROOT / "data" / ".initialized"
    return not marker.exists()


def mark_initialized():
    """标记已初始化"""
    marker = ROOT / "data" / ".initialized"
    marker.parent.mkdir(parents=True, exist_ok=True)
    marker.write_text(VERSION)


def main():
    """程序入口"""
    # 加载配置
    config.load(str(ROOT / "config.yaml"))
    setup_logging()

    logger.info("=" * 50)
    logger.info(f"  {config.get('system.app_name', 'AI进化论')} v{VERSION} 启动中...")
    logger.info("=" * 50)

    # ---- 启动 GUI ----
    try:
        from PyQt6.QtWidgets import QApplication, QSplashScreen, QPixmap
        from PyQt6.QtGui import QFont, QPainter, QColor
        from PyQt6.QtCore import Qt
    except ImportError:
        print("错误：PyQt6 未安装。请运行: pip install PyQt6")
        sys.exit(1)

    app = QApplication(sys.argv)
    app.setApplicationName("AI进化论")
    app.setOrganizationName("AI进化论")

    # Splash Screen
    splash_pixmap = QPixmap(400, 200)
    splash_pixmap.fill(QColor("#2D2D2D"))
    painter = QPainter(splash_pixmap)
    painter.setPen(QColor("#FFFFFF"))
    painter.setFont(QFont("Microsoft YaHei", 18, QFont.Weight.Bold))
    painter.drawText(splash_pixmap.rect(), Qt.AlignmentFlag.AlignCenter, "AI进化论\n正在启动...")
    painter.end()
    splash = QSplashScreen(splash_pixmap)
    splash.show()
    app.processEvents()

    # ---- 初始化核心模块 ----
    splash.showMessage("初始化 LLM 后端...", Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignHCenter, QColor("#4A90D9"))
    app.processEvents()
    from llm.router import LLMRouter
    llm = LLMRouter()

    splash.showMessage("初始化记忆库...", Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignHCenter, QColor("#4A90D9"))
    app.processEvents()
    from memory.manager import MemoryManager
    memory = MemoryManager()

    splash.showMessage("初始化技能库...", Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignHCenter, QColor("#4A90D9"))
    app.processEvents()
    from skills.manager import SkillManager
    skills = SkillManager()

    splash.showMessage("初始化上下文管理器...", Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignHCenter, QColor("#4A90D9"))
    app.processEvents()
    from core.context_manager import ContextManager
    max_history = config.get("system.max_history_turns", 20)
    max_tokens = config.get("system.max_context_tokens", 30000)
    context = ContextManager(memory, max_history=max_history, max_tokens=max_tokens)

    # 初始化角色卡管理器
    splash.showMessage("初始化角色卡系统...", Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignHCenter, QColor("#4A90D9"))
    app.processEvents()
    from core.character_card import CharacterCardManager
    card_manager = CharacterCardManager()
    # 注入角色卡管理器到上下文管理器
    context.set_card_manager(card_manager)

    splash.showMessage("初始化 Agent 引擎...", Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignHCenter, QColor("#4A90D9"))
    app.processEvents()
    from core.agent import Agent
    agent = Agent(llm, memory, skills, context)

    # ---- 初始化 MCP 服务 ----
    splash.showMessage("初始化 MCP 服务...", Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignHCenter, QColor("#4A90D9"))
    app.processEvents()
    from mcp.server import MCPServer
    mcp_server = MCPServer(
        host=config.get("mcp.host", "127.0.0.1"),
        port=config.get("mcp.port", 9527),
        auto_start=config.get("mcp.auto_start", True),
    )

    # ---- 全局样式 ----
    app.setStyleSheet("""
        QMainWindow { background: #FAFBFC; }
        QTabWidget::pane { border: 1px solid #ddd; background: white; }
        QTabBar::tab {
            padding: 8px 16px;
            margin-right: 2px;
            background: #E8ECF0;
            border-top-left-radius: 4px;
            border-top-right-radius: 4px;
        }
        QTabBar::tab:selected { background: white; border-bottom: 2px solid #4A90D9; }
        QPushButton { padding: 6px 12px; border: 1px solid #ccc; border-radius: 4px; background: white; }
        QPushButton:hover { background: #F0F4F8; }
    """)

    # ---- 启动主窗口 ----
    splash.showMessage("加载主窗口...", Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignHCenter, QColor("#27AE60"))
    app.processEvents()
    from gui.main_window import MainWindow
    window = MainWindow(agent, mcp_server, config, card_manager=card_manager)
    window.show()
    splash.finish(window)

    # 首次运行引导
    if check_first_run():
        mark_initialized()
        QMessageBox_post = None
        try:
            from PyQt6.QtWidgets import QMessageBox
            QMessageBox.information(
                window, "欢迎使用 AI进化论！🎉",
                "<h2>首次使用指南</h2>"
                "<ol>"
                "<li>在 <b>设置 → LLM</b> 中配置 API Key</li>"
                "<li>确保 Ollama 已启动（本地模型）</li>"
                "<li>开始对话吧！</li>"
                "</ol>"
                "<p>💡 你可以在设置中测试连接是否正常。</p>"
            )
        except Exception:
            pass

    logger.info("AI进化论 启动完成！")
    logger.info(f"  版本: v{VERSION}")
    logger.info(f"  GUI: 主窗口已打开")
    if config.get("mcp.auto_start", True):
        logger.info(f"  MCP: http://{config.get('mcp.host', '127.0.0.1')}:{config.get('mcp.port', 9527)}")

    # 优雅退出
    def cleanup():
        logger.info("正在清理资源...")
        try:
            from skills.builtin.browser import browser_close
            browser_close()
        except Exception:
            pass
        try:
            if mcp_server:
                mcp_server.stop()
        except Exception:
            pass
        logger.info("AI进化论 已退出")

    app.aboutToQuit.connect(cleanup)
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
