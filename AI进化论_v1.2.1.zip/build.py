"""
AI进化论 — PyInstaller 打包脚本
生成 Windows .exe 可执行文件

使用方法:
    python build.py

输出:
    dist/AI进化论.exe
"""

import os
import sys
import subprocess
from pathlib import Path

ROOT = Path(__file__).parent

# 清理旧构建
for d in ["build", "dist"]:
    path = ROOT / d
    if path.exists():
        import shutil
        shutil.rmtree(path)
        print(f"已清理: {d}/")

print("开始打包 AI进化论...")
print(f"项目目录: {ROOT}")

# 构建命令
cmd = [
    sys.executable, "-m", "PyInstaller",
    "--name=AI进化论",
    "--onefile",  # 单文件 exe
    "--windowed",  # 无控制台窗口（Windows GUI 模式）
    "--clean",
    "--noconfirm",
    f"--add-data=config.yaml{os.pathsep}.",

    # 隐藏导入
    "--hidden-import=chromadb",
    "--hidden-import=chromadb.config",
    "--hidden-import=chromadb.utils.embedding_functions",
    "--hidden-import=ollama",
    "--hidden-import=openai",
    "--hidden-import=yaml",
    "--hidden-import=pydantic",
    "--hidden-import=fastapi",
    "--hidden-import=uvicorn",
    "--hidden-import=uvicorn.logging",
    "--hidden-import=playwright",
    "--hidden-import=httpx",
    "--hidden-import=loguru",
    "--hidden-import=duckduckgo_search",
    "--hidden-import=psutil",
    "--hidden-import=pyperclip",

    # 排除不必要的模块减小体积
    "--exclude-module=matplotlib",
    "--exclude-module=pandas",
    "--exclude-module=scipy",
    "--exclude-module=PIL",
    "--exclude-module=tkinter",
    "--exclude-module=test",
    "--exclude-module=tests",

    str(ROOT / "main.py"),
]

print(f"PyInstaller 命令: {' '.join(cmd)}")

os.chdir(str(ROOT))
# 使用 subprocess.run 代替 os.system，支持含空格路径
result = subprocess.run(cmd, cwd=str(ROOT))

print("\n打包完成！")
exe_path = ROOT / "dist" / "AI进化论.exe"
if exe_path.exists():
    size_mb = exe_path.stat().st_size / (1024 * 1024)
    print(f"  输出: {exe_path}")
    print(f"  大小: {size_mb:.1f} MB")
else:
    print("  打包可能失败，请检查上方错误信息")
