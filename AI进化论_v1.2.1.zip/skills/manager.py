"""
AI进化论 — 技能管理器
整合技能注册、执行、导入导出、用户技能加载
"""

import json
import os
import importlib
import sys
import yaml
from pathlib import Path
from typing import Any

from loguru import logger

from skills.registry import SkillRegistry, SkillDef, SkillParameter, SkillCategory
from skills.builtin import file_ops, web_search, code_exec, browser, system_info, self_modify


class SkillManager:
    """技能管理器 — 统一管理所有 Skill"""

    def __init__(self):
        self.registry = SkillRegistry()
        self._user_handlers: dict[str, Any] = {}
        self._register_builtins()
        self._load_user_skills()

    def _register_builtins(self):
        """注册所有内置技能"""
        builtins = [
            SkillDef(
                name="file_read",
                description="读取文件内容。支持指定编码和读取行数。",
                category=SkillCategory.FILE,
                parameters=[
                    SkillParameter("file_path", "string", "文件绝对路径"),
                    SkillParameter("encoding", "string", "文件编码，默认 utf-8", required=False, default="utf-8"),
                    SkillParameter("lines", "number", "读取行数，0=全部", required=False, default=0),
                ],
                handler=file_ops.file_read,
            ),
            SkillDef(
                name="file_write",
                description="写入或追加内容到文件。自动创建父目录。",
                category=SkillCategory.FILE,
                parameters=[
                    SkillParameter("file_path", "string", "文件路径"),
                    SkillParameter("content", "string", "要写入的内容"),
                    SkillParameter("append", "boolean", "是否追加模式", required=False, default=False),
                ],
                handler=file_ops.file_write,
            ),
            SkillDef(
                name="file_list",
                description="列出目录中的文件和子目录。支持通配符和递归。",
                category=SkillCategory.FILE,
                parameters=[
                    SkillParameter("directory", "string", "目录路径"),
                    SkillParameter("pattern", "string", "文件名匹配模式，如 *.py", required=False, default="*"),
                    SkillParameter("recursive", "boolean", "是否递归子目录", required=False, default=False),
                ],
                handler=file_ops.file_list,
            ),
            SkillDef(
                name="file_search",
                description="在文件中搜索关键词（grep 功能）",
                category=SkillCategory.FILE,
                parameters=[
                    SkillParameter("directory", "string", "搜索目录"),
                    SkillParameter("keyword", "string", "搜索关键词"),
                    SkillParameter("file_pattern", "string", "文件匹配模式", required=False, default="*.*"),
                ],
                handler=file_ops.file_search,
            ),
            SkillDef(
                name="file_delete",
                description="删除文件或目录（不可恢复！）",
                category=SkillCategory.FILE,
                parameters=[SkillParameter("file_path", "string", "要删除的文件或目录路径")],
                handler=file_ops.file_delete,
            ),
            SkillDef(
                name="file_move",
                description="移动或重命名文件/目录",
                category=SkillCategory.FILE,
                parameters=[
                    SkillParameter("source", "string", "源路径"),
                    SkillParameter("destination", "string", "目标路径"),
                ],
                handler=file_ops.file_move,
            ),
            # ---- 搜索 ----
            SkillDef(
                name="web_search",
                description="在互联网上搜索信息",
                category=SkillCategory.SEARCH,
                parameters=[
                    SkillParameter("query", "string", "搜索关键词"),
                    SkillParameter("max_results", "number", "最大结果数", required=False, default=10),
                ],
                handler=web_search.web_search,
            ),
            SkillDef(
                name="web_fetch",
                description="抓取并提取网页内容",
                category=SkillCategory.SEARCH,
                parameters=[SkillParameter("url", "string", "网页 URL")],
                handler=web_search.web_fetch,
            ),
            # ---- 编程 ----
            SkillDef(
                name="code_exec",
                description="在沙箱中执行 Python 代码，返回执行结果",
                category=SkillCategory.CODING,
                parameters=[
                    SkillParameter("code", "string", "Python 代码"),
                    SkillParameter("timeout", "number", "超时秒数", required=False, default=30),
                ],
                handler=code_exec.code_exec,
            ),
            # ---- 浏览器 ----
            SkillDef(
                name="browser_open",
                description="打开网页并获取文本内容",
                category=SkillCategory.BROWSER,
                parameters=[
                    SkillParameter("url", "string", "网页 URL"),
                    SkillParameter("headless", "boolean", "是否无头模式", required=False, default=True),
                ],
                handler=browser.browser_open,
            ),
            SkillDef(
                name="browser_screenshot",
                description="对网页截图并保存",
                category=SkillCategory.BROWSER,
                parameters=[
                    SkillParameter("url", "string", "网页 URL"),
                    SkillParameter("file_path", "string", "截图保存路径", required=False, default=""),
                ],
                handler=browser.browser_screenshot,
            ),
            SkillDef(
                name="browser_click",
                description="打开网页并点击指定元素",
                category=SkillCategory.BROWSER,
                parameters=[
                    SkillParameter("url", "string", "网页 URL"),
                    SkillParameter("selector", "string", "CSS 选择器"),
                    SkillParameter("headless", "boolean", "是否无头模式", required=False, default=True),
                ],
                handler=browser.browser_click,
            ),
            SkillDef(
                name="browser_fill",
                description="打开网页并填写表单",
                category=SkillCategory.BROWSER,
                parameters=[
                    SkillParameter("url", "string", "网页 URL"),
                    SkillParameter("selector", "string", "CSS 选择器"),
                    SkillParameter("value", "string", "填入的值"),
                    SkillParameter("headless", "boolean", "是否无头模式", required=False, default=True),
                ],
                handler=browser.browser_fill,
            ),
            # ---- 系统 ----
            SkillDef(
                name="system_info",
                description="获取系统信息（CPU、内存、磁盘）",
                category=SkillCategory.SYSTEM,
                parameters=[],
                handler=system_info.system_info,
            ),
            SkillDef(
                name="process_list",
                description="列出运行中的进程",
                category=SkillCategory.SYSTEM,
                parameters=[
                    SkillParameter("search", "string", "搜索进程名", required=False, default=""),
                    SkillParameter("limit", "number", "返回数量", required=False, default=20),
                ],
                handler=system_info.process_list,
            ),
            SkillDef(
                name="run_command",
                description="执行系统命令（白名单模式，只允许安全的只读命令）",
                category=SkillCategory.SYSTEM,
                parameters=[
                    SkillParameter("command", "string", "要执行的命令"),
                    SkillParameter("timeout", "number", "超时秒数", required=False, default=30),
                ],
                handler=system_info.run_command,
            ),
            SkillDef(
                name="clipboard_write",
                description="写入剪贴板",
                category=SkillCategory.SYSTEM,
                parameters=[SkillParameter("text", "string", "要写入的文本")],
                handler=system_info.clipboard_write,
            ),
            SkillDef(
                name="clipboard_read",
                description="读取剪贴板内容",
                category=SkillCategory.SYSTEM,
                parameters=[],
                handler=system_info.clipboard_read,
            ),
            # ---- 自我修改 ----
            SkillDef(
                name="self_read",
                description="读取本程序自身的源代码文件。用于理解当前代码逻辑。",
                category=SkillCategory.CODING,
                parameters=[
                    SkillParameter("file_path", "string", "文件路径（相对于项目根目录或绝对路径）"),
                    SkillParameter("encoding", "string", "文件编码", required=False, default="utf-8"),
                    SkillParameter("lines", "number", "读取行数（0=全部）", required=False, default=0),
                ],
                handler=self_modify.self_read,
            ),
            SkillDef(
                name="self_write",
                description="写入/覆盖本程序自身的源代码文件。修改前会自动创建备份，修改后会自动检查语法。这是自我进化的核心能力。",
                category=SkillCategory.CODING,
                parameters=[
                    SkillParameter("file_path", "string", "文件路径"),
                    SkillParameter("content", "string", "新文件内容"),
                    SkillParameter("encoding", "string", "文件编码", required=False, default="utf-8"),
                    SkillParameter("create_backup", "boolean", "是否创建备份", required=False, default=True),
                ],
                handler=self_modify.self_write,
            ),
            SkillDef(
                name="self_edit",
                description="精确编辑本程序源代码（字符串替换方式，更安全）。old_string 必须与文件中的内容完全匹配且唯一。",
                category=SkillCategory.CODING,
                parameters=[
                    SkillParameter("file_path", "string", "文件路径"),
                    SkillParameter("old_string", "string", "要替换的原始字符串（必须完全匹配）"),
                    SkillParameter("new_string", "string", "替换后的新字符串"),
                    SkillParameter("encoding", "string", "文件编码", required=False, default="utf-8"),
                    SkillParameter("create_backup", "boolean", "是否创建备份", required=False, default=True),
                ],
                handler=self_modify.self_edit,
            ),
            SkillDef(
                name="self_create",
                description="在本程序中创建新的源代码文件。仅限项目目录内。",
                category=SkillCategory.CODING,
                parameters=[
                    SkillParameter("file_path", "string", "新文件路径"),
                    SkillParameter("content", "string", "文件内容"),
                    SkillParameter("encoding", "string", "文件编码", required=False, default="utf-8"),
                ],
                handler=self_modify.self_create,
            ),
            SkillDef(
                name="self_list",
                description="列出本程序的源代码文件结构，了解项目组成。",
                category=SkillCategory.CODING,
                parameters=[
                    SkillParameter("directory", "string", "目录路径", required=False, default="."),
                    SkillParameter("pattern", "string", "文件匹配模式", required=False, default="*.py"),
                    SkillParameter("recursive", "boolean", "是否递归", required=False, default=True),
                ],
                handler=self_modify.self_list,
            ),
            SkillDef(
                name="self_diff",
                description="查看源代码文件的修改差异（与备份对比）。",
                category=SkillCategory.CODING,
                parameters=[
                    SkillParameter("file_path", "string", "当前文件路径"),
                    SkillParameter("backup_path", "string", "备份文件路径（留空自动查找）", required=False, default=""),
                ],
                handler=self_modify.self_diff,
            ),
            SkillDef(
                name="self_restore",
                description="从备份恢复源代码文件。当修改出错时使用。",
                category=SkillCategory.CODING,
                parameters=[
                    SkillParameter("file_path", "string", "要恢复的文件路径"),
                    SkillParameter("backup_path", "string", "备份文件路径（留空自动查找最近备份）", required=False, default=""),
                ],
                handler=self_modify.self_restore,
            ),
            SkillDef(
                name="self_syntax_check",
                description="对源代码文件执行 Python 语法检查。",
                category=SkillCategory.CODING,
                parameters=[
                    SkillParameter("file_path", "string", "文件路径"),
                ],
                handler=self_modify.self_syntax_check,
            ),
            SkillDef(
                name="self_project_info",
                description="获取本程序的项目结构信息（自我认知），包括所有源代码文件列表和大小。",
                category=SkillCategory.CODING,
                parameters=[],
                handler=self_modify.self_project_info,
            ),
        ]

        for skill_def in builtins:
            self.registry.register(skill_def)
        logger.info(f"已注册 {len(builtins)} 个内置技能")

    def _load_user_skills(self):
        """加载用户自定义技能目录中的 Python 模块"""
        from core.config import config
        user_path = Path(config.get("skills.user_path", "./skills/user"))
        if not user_path.exists():
            return

        for py_file in user_path.glob("*.py"):
            if py_file.name.startswith("_"):
                continue
            try:
                # 动态导入用户技能模块
                module_name = f"skills.user.{py_file.stem}"
                if module_name not in sys.modules:
                    spec = importlib.util.spec_from_file_location(module_name, str(py_file))
                    if spec and spec.loader:
                        module = importlib.util.module_from_spec(spec)
                        sys.modules[module_name] = module
                        spec.loader.exec_module(module)

                        # 查找模块中的技能函数（以 skill_ 开头的函数）
                        for attr_name in dir(module):
                            if attr_name.startswith("skill_") or attr_name in (
                                "web_search", "web_fetch", "file_read", "file_write",
                                "code_exec", "system_info", "browser_open",
                            ):
                                func = getattr(module, attr_name)
                                if callable(func):
                                    # 自动注册
                                    skill_name = f"user_{py_file.stem}_{attr_name}"
                                    self._user_handlers[skill_name] = func
                                    logger.info(f"加载用户技能: {skill_name}")
            except Exception as e:
                logger.warning(f"加载用户技能 {py_file.name} 失败: {e}")

    def execute(self, skill_name: str, args: dict) -> dict:
        """执行技能"""
        # 优先查找用户技能
        if skill_name in self._user_handlers:
            try:
                return self._user_handlers[skill_name](**args)
            except Exception as e:
                return {"error": f"用户技能执行失败: {e}"}

        # 查找注册的技能
        skill = self.registry.get(skill_name)
        if skill is None:
            return {"error": f"技能不存在: {skill_name}"}

        if not skill.enabled:
            return {"error": f"技能已禁用: {skill_name}"}

        if skill.handler is None:
            return {"error": f"技能 {skill_name} 没有可执行的 handler"}

        try:
            result = skill.handler(**args)
            if isinstance(result, dict):
                return result
            return {"result": result}
        except TypeError as e:
            return {"error": f"参数错误: {e}"}
        except Exception as e:
            return {"error": f"执行失败: {e}"}

    def get_skill(self, name: str) -> SkillDef | None:
        return self.registry.get(name)

    def list_all(self) -> list[SkillDef]:
        return self.registry.list_all()

    def list_enabled(self) -> list[SkillDef]:
        return self.registry.list_enabled()

    def set_enabled(self, name: str, enabled: bool):
        self.registry.set_enabled(name, enabled)

    def get_tools_schema(self) -> list[dict]:
        """获取所有启用技能的工具定义（LLM Function Calling 格式）"""
        return [skill.to_tool_schema() for skill in self.list_enabled()]

    def import_skill(self, yaml_path: str) -> dict:
        """从 YAML 文件导入技能定义，并尝试绑定 handler"""
        try:
            with open(yaml_path, "r", encoding="utf-8") as f:
                data = yaml.safe_load(f)

            if not data or "name" not in data:
                return {"error": "YAML 格式错误：缺少 name 字段"}

            # 解析参数
            parameters = []
            for p in data.get("parameters", []):
                parameters.append(SkillParameter(
                    name=p.get("name", ""),
                    type=p.get("type", "string"),
                    description=p.get("description", ""),
                    required=p.get("required", False),
                    default=p.get("default"),
                ))

            # 尝试绑定 handler
            handler = None
            handler_path = data.get("handler")
            if handler_path:
                try:
                    # handler_path 格式: "module.path:function_name"
                    if ":" in handler_path:
                        mod_path, func_name = handler_path.rsplit(":", 1)
                        module = importlib.import_module(mod_path)
                        handler = getattr(module, func_name)
                    else:
                        # 尝试从同目录加载
                        yaml_dir = str(Path(yaml_path).parent)
                        if yaml_dir not in sys.path:
                            sys.path.insert(0, yaml_dir)
                        module = importlib.import_module(handler_path)
                        handler = getattr(module, handler_path.split(".")[-1], None)
                except Exception as e:
                    logger.warning(f"导入技能 handler 失败: {e}")

            skill_def = SkillDef(
                name=data["name"],
                description=data.get("description", ""),
                category=SkillCategory(data.get("category", "other")),
                parameters=parameters,
                handler=handler,
                version=data.get("version", "1.0.0"),
            )

            self.registry.register(skill_def)

            # 如果有 handler，也加入 _user_handlers
            if handler:
                self._user_handlers[data["name"]] = handler

            return {"imported": data["name"], "has_handler": handler is not None}

        except Exception as e:
            return {"error": f"导入失败: {e}"}

    def export_skill(self, skill_name: str, output_dir: str = "./skills/user") -> dict:
        """导出技能为 YAML 文件"""
        skill = self.registry.get(skill_name)
        if not skill:
            return {"error": f"技能不存在: {skill_name}"}

        try:
            data = {
                "name": skill.name,
                "description": skill.description,
                "category": skill.category.value,
                "version": skill.version,
                "parameters": [
                    {
                        "name": p.name,
                        "type": p.type,
                        "description": p.description,
                        "required": p.required,
                        "default": p.default,
                    }
                    for p in skill.parameters
                ],
            }

            Path(output_dir).mkdir(parents=True, exist_ok=True)
            output_path = Path(output_dir) / f"{skill.name}.yaml"
            with open(output_path, "w", encoding="utf-8") as f:
                yaml.dump(data, f, allow_unicode=True, default_flow_style=False)

            return {"exported": str(output_path), "skill": skill.name}
        except Exception as e:
            return {"error": f"导出失败: {e}"}
