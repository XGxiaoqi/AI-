"""
AI进化论 — 内置技能：代码执行（沙箱）
在隔离的临时目录中执行 Python 代码，具备安全限制和超时机制
"""

import sys
import io
import traceback
import tempfile
import os
import signal
import threading
from pathlib import Path
from typing import Any


# 危险模块黑名单
BLOCKED_IMPORTS = {
    "os.system", "os.popen", "os.exec", "os.spawn", "os.kill",
    "subprocess", "shutil.rmtree", "ctypes",
    "socket", "http.server", "xmlrpc",
    "pickle", "shelve", "marshal",
    "importlib", "pkg_resources",
}

# 允许的安全模块
SAFE_MODULES = {
    "math", "json", "re", "datetime", "collections", "itertools",
    "functools", "operator", "string", "copy", "pprint",
    "statistics", "random", "hashlib", "base64", "textwrap",
    "typing", "dataclasses", "enum", "pathlib", "csv",
}


def _safe_import(name, *args, **kwargs):
    """安全的 import 函数，阻止危险模块"""
    root_module = name.split(".")[0]
    if root_module not in SAFE_MODULES and root_module not in ("os", "sys"):
        # 允许 os.path 和 sys 但阻止 os.system 等
        if name not in ("os.path",) and root_module not in ("os", "sys"):
            raise ImportError(f"沙箱限制：禁止导入模块 '{name}'")
    return __import__(name, *args, **kwargs)


def code_exec(code: str, language: str = "python", timeout: int = 30) -> dict[str, Any]:
    """
    在沙箱中执行代码

    Args:
        code: 代码内容
        language: 语言类型（目前支持 python）
        timeout: 超时秒数
    """
    if language != "python":
        return {"error": f"暂不支持语言: {language}，目前仅支持 Python"}

    # 限制代码长度
    if len(code) > 50000:
        return {"error": "代码过长（超过 50000 字符）"}

    # 检查危险模式
    dangerous_patterns = [
        ("__import__", "禁止使用 __import__"),
        ("os.system(", "禁止使用 os.system"),
        ("os.popen(", "禁止使用 os.popen"),
        ("subprocess.", "禁止使用 subprocess"),
        ("shutil.rmtree", "禁止使用 shutil.rmtree"),
        ("ctypes.", "禁止使用 ctypes"),
        ("eval(", "禁止使用 eval"),
        ("exec(", "禁止使用 exec"),  
        ("compile(", "禁止使用 compile"),
        ("open(", None),  # 允许但会重定向路径
    ]
    for pattern, msg in dangerous_patterns:
        if msg and pattern in code:
            return {"error": f"沙箱安全限制：{msg}"}

    old_cwd = os.getcwd()
    tmp_dir = tempfile.mkdtemp(prefix="aijhl_code_")
    stdout_capture = io.StringIO()
    stderr_capture = io.StringIO()
    timed_out = False

    # 结果容器
    result_holder = {"value": None, "error": None}

    def run_code():
        try:
            os.chdir(tmp_dir)

            old_stdout = sys.stdout
            old_stderr = sys.stderr
            sys.stdout = stdout_capture
            sys.stderr = stderr_capture

            # 构建受限的全局环境
            safe_builtins = {
                k: v for k, v in __builtins__.items() if k not in (
                    "exec", "eval", "compile", "__import__", "breakpoint",
                    "exit", "quit",
                )
            }
            safe_builtins["__import__"] = _safe_import
            safe_builtins["print"] = print

            # 提供安全的 open 函数（限制在 tmp_dir 内）
            original_open = open
            def safe_open(file, mode='r', *args, **kwargs):
                if isinstance(file, (str, Path)):
                    resolved = Path(file)
                    if not resolved.is_absolute():
                        file = Path(tmp_dir) / file
                    else:
                        # 不允许访问 tmp_dir 之外的路径写操作
                        if 'w' in str(mode) or 'a' in str(mode):
                            if not str(resolved).startswith(tmp_dir):
                                raise PermissionError(f"沙箱限制：不允许写入 {resolved}")
                return original_open(file, mode, *args, **kwargs)
            safe_builtins["open"] = safe_open

            exec_globals = {
                "__builtins__": safe_builtins,
                "__name__": "__main__",
            }

            try:
                exec(code, exec_globals)
            except SystemExit:
                pass
            except Exception:
                stderr_capture.write(traceback.format_exc())

            sys.stdout = old_stdout
            sys.stderr = old_stderr

        except Exception as e:
            result_holder["error"] = traceback.format_exc()

    # 使用线程 + 超时实现
    thread = threading.Thread(target=run_code, daemon=True)
    thread.start()
    thread.join(timeout=timeout)

    if thread.is_alive():
        timed_out = True
        logger.warning(f"代码执行超时 ({timeout}s)")

    # 恢复工作目录
    os.chdir(old_cwd)

    # 清理临时目录
    try:
        import shutil
        shutil.rmtree(tmp_dir, ignore_errors=True)
    except Exception:
        pass

    if timed_out:
        return {
            "stdout": stdout_capture.getvalue()[:5000],
            "stderr": f"执行超时 ({timeout}s)，可能存在死循环或耗时操作",
            "exit_code": -1,
            "timed_out": True,
        }

    if result_holder["error"]:
        return {"error": result_holder["error"]}

    return {
        "stdout": stdout_capture.getvalue()[:10000],
        "stderr": stderr_capture.getvalue()[:5000],
        "exit_code": 0 if not stderr_capture.getvalue() else 1,
    }
