"""
AI进化论 — 内置技能：文件操作
支持文件读写、搜索、批量操作
"""

import os
import json
import shutil
from pathlib import Path
from typing import Any


def file_read(file_path: str, encoding: str = "utf-8", lines: int = 0) -> dict[str, Any]:
    """读取文件内容"""
    path = Path(file_path)
    if not path.exists():
        return {"error": f"文件不存在: {file_path}"}

    try:
        with open(path, "r", encoding=encoding) as f:
            if lines > 0:
                content = "".join(f.readline() for _ in range(lines))
            else:
                content = f.read()

        return {
            "file_path": str(path.absolute()),
            "size": path.stat().st_size,
            "lines_count": content.count("\n") + (1 if content and not content.endswith("\n") else 0),
            "content": content[:50000],  # 限制 50KB
            "truncated": len(content) > 50000,
        }
    except UnicodeDecodeError:
        return {"error": "文件不是文本格式，或编码不正确"}
    except Exception as e:
        return {"error": str(e)}


def file_write(file_path: str, content: str, encoding: str = "utf-8", append: bool = False) -> dict[str, Any]:
    """写入或追加文件内容"""
    try:
        path = Path(file_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        mode = "a" if append else "w"
        with open(path, mode, encoding=encoding) as f:
            f.write(content)
        return {
            "file_path": str(path.absolute()),
            "size": path.stat().st_size,
            "mode": "append" if append else "write",
        }
    except Exception as e:
        return {"error": str(e)}


def file_list(directory: str, pattern: str = "*", recursive: bool = False) -> dict[str, Any]:
    """列出目录中的文件"""
    path = Path(directory)
    if not path.exists():
        return {"error": f"目录不存在: {directory}"}
    if not path.is_dir():
        return {"error": f"不是目录: {directory}"}

    files = []
    if recursive:
        matched = list(path.rglob(pattern))
    else:
        matched = list(path.glob(pattern))

    for f in matched[:200]:  # 限制 200 个
        if f.is_file():
            files.append({
                "name": f.name,
                "path": str(f.absolute()),
                "size": f.stat().st_size,
                "suffix": f.suffix,
            })
        elif f.is_dir():
            files.append({
                "name": f.name + "/",
                "path": str(f.absolute()),
                "type": "directory",
            })

    return {"directory": str(path.absolute()), "count": len(files), "files": files}


def file_search(directory: str, keyword: str, file_pattern: str = "*.*") -> dict[str, Any]:
    """在文件中搜索关键词（grep 等价功能）"""
    path = Path(directory)
    if not path.exists():
        return {"error": f"目录不存在: {directory}"}

    results = []
    for f in path.rglob(file_pattern):
        if f.is_file() and f.stat().st_size < 1024 * 1024:  # 跳过 >1MB 的文件
            try:
                content = f.read_text(encoding="utf-8", errors="ignore")
                if keyword.lower() in content.lower():
                    lines = content.split("\n")
                    matches = [
                        {"line": i + 1, "text": line.strip()[:200]}
                        for i, line in enumerate(lines)
                        if keyword.lower() in line.lower()
                    ]
                    results.append({
                        "file": str(f.absolute()),
                        "matches": len(matches),
                        "details": matches[:10],  # 每个文件最多 10 条
                    })
                    if len(results) >= 50:
                        break
            except Exception:
                continue

    return {"keyword": keyword, "total_files": len(results), "results": results}


def file_delete(file_path: str) -> dict[str, Any]:
    """删除文件或目录"""
    path = Path(file_path)
    if not path.exists():
        return {"error": f"路径不存在: {file_path}"}

    try:
        if path.is_dir():
            shutil.rmtree(path)
            return {"deleted": str(path.absolute()), "type": "directory"}
        else:
            path.unlink()
            return {"deleted": str(path.absolute()), "type": "file"}
    except Exception as e:
        return {"error": str(e)}


def file_move(source: str, destination: str) -> dict[str, Any]:
    """移动或重命名文件"""
    try:
        src = Path(source)
        dst = Path(destination)
        if not src.exists():
            return {"error": f"源文件不存在: {source}"}
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(src), str(dst))
        return {"source": str(src.absolute()), "destination": str(dst.absolute())}
    except Exception as e:
        return {"error": str(e)}
