"""
AI进化论 — 内置技能：自我修改
允许 AI 读取、修改、创建本程序自身的源代码，实现自我进化能力

安全机制：
1. 仅允许操作项目根目录下的文件（通过 ROOT_DIR 限制）
2. 修改前自动创建备份（.bak 文件）
3. 修改后自动执行语法检查
4. 危险操作黑名单（禁止删除核心启动文件等）
5. 所有操作都有详细日志
6. 通过 config 中的白名单控制允许修改的文件类型
"""

import os
import ast
import shutil
import difflib
import traceback
from pathlib import Path
from typing import Any
from datetime import datetime

from loguru import logger


# 项目根目录（动态检测）
def _get_root_dir() -> Path:
    """获取项目根目录"""
    # 从本文件向上回溯到项目根目录
    current = Path(__file__).resolve()
    # skills/builtin/self_modify.py -> 项目根
    return current.parent.parent.parent


ROOT_DIR = _get_root_dir()


def _load_config():
    """从 config.yaml 读取自我修改配置，与硬编码默认值合并"""
    try:
        from core.config import config
        # 读取允许的扩展名（合并默认值）
        cfg_exts = config.get("self_modify.allowed_extensions", [])
        if cfg_exts:
            _allowed = set(cfg_exts)
        else:
            _allowed = {".py", ".yaml", ".yml", ".json", ".txt", ".md",
                        ".toml", ".cfg", ".ini", ".html", ".css", ".js"}
        # 读取备份路径
        cfg_backup = config.get("self_modify.backup_path", "./data/backups/self_modify")
        if not Path(cfg_backup).is_absolute():
            _backup_dir = ROOT_DIR / cfg_backup
        else:
            _backup_dir = Path(cfg_backup)
        # 读取确认配置
        _confirm_before = config.get("self_modify.confirm_before_modify", True)
        # 是否启用自我修改
        _enabled = config.get("self_modify.enabled", True)
        return _allowed, _backup_dir, _confirm_before, _enabled
    except Exception:
        # config 未加载时回退到硬编码默认值
        _allowed = {".py", ".yaml", ".yml", ".json", ".txt", ".md",
                    ".toml", ".cfg", ".ini", ".html", ".css", ".js"}
        _backup_dir = ROOT_DIR / "data" / "backups" / "self_modify"
        _confirm_before = True
        _enabled = True
        return _allowed, _backup_dir, _confirm_before, _enabled


ALLOWED_EXTENSIONS, BACKUP_DIR, CONFIRM_BEFORE_MODIFY, SELF_MODIFY_ENABLED = _load_config()

# 禁止修改/删除的关键文件（安全底线）
PROTECTED_FILES = {
    "main.py",           # 主入口
    "core/config.py",    # 配置管理
}

# 禁止删除的目录
PROTECTED_DIRS = {
    "core", "llm", "memory", "skills", "gui", "mcp",
}


def _is_protected(relative_path: str) -> bool:
    """检查文件是否在保护名单中"""
    # 标准化路径（统一使用 / 分隔符）
    normalized = relative_path.replace("\\", "/")
    for protected in PROTECTED_FILES:
        if normalized == protected or normalized.endswith("/" + protected):
            return True
    return False


def _ensure_backup_dir():
    """确保备份目录存在"""
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)


def _resolve_path(file_path: str) -> Path:
    """
    解析文件路径，确保在项目根目录内
    支持绝对路径和相对路径（相对于项目根目录）
    """
    path = Path(file_path)

    # 如果是相对路径，相对于项目根目录解析
    if not path.is_absolute():
        path = ROOT_DIR / path

    # 解析为绝对路径
    path = path.resolve()

    # 安全检查：必须在项目根目录内
    try:
        path.relative_to(ROOT_DIR)
    except ValueError:
        raise PermissionError(f"安全限制：不允许访问项目目录外的文件: {file_path}")

    return path


def _check_extension(path: Path) -> bool:
    """检查文件扩展名是否允许"""
    return path.suffix.lower() in ALLOWED_EXTENSIONS


def _create_backup(path: Path) -> str | None:
    """创建备份文件，返回备份路径"""
    if not path.exists():
        return None

    _ensure_backup_dir()

    # 备份文件名：原文件名 + 时间戳
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    relative = path.relative_to(ROOT_DIR)
    backup_name = f"{relative.stem}_{timestamp}{relative.suffix}.bak"
    # 保持目录结构
    backup_path = BACKUP_DIR / relative.parent / backup_name
    backup_path.parent.mkdir(parents=True, exist_ok=True)

    shutil.copy2(path, backup_path)
    logger.info(f"自我修改备份: {path} → {backup_path}")
    return str(backup_path)


def _syntax_check(code: str, filename: str = "<string>") -> tuple[bool, str]:
    """Python 语法检查"""
    try:
        ast.parse(code)
        return True, "语法检查通过"
    except SyntaxError as e:
        return False, f"语法错误: 第{e.lineno}行 - {e.msg}"
    except Exception as e:
        return False, f"检查异常: {str(e)}"


def self_read(file_path: str, encoding: str = "utf-8", lines: int = 0) -> dict[str, Any]:
    """
    读取本程序源代码

    Args:
        file_path: 文件路径（相对于项目根目录或绝对路径）
        encoding: 文件编码
        lines: 读取行数（0=全部）
    """
    try:
        path = _resolve_path(file_path)
    except PermissionError as e:
        return {"error": str(e)}

    if not path.exists():
        return {"error": f"文件不存在: {file_path}"}

    if not path.is_file():
        return {"error": f"不是文件: {file_path}"}

    # 检查文件大小（限制读取大文件）
    size = path.stat().st_size
    if size > 1024 * 1024:  # 1MB
        return {"error": f"文件过大 ({size} 字节)，超过 1MB 限制"}

    try:
        with open(path, "r", encoding=encoding) as f:
            if lines > 0:
                content = "".join(f.readline() for _ in range(lines))
            else:
                content = f.read()

        # 返回相对路径，方便用户理解
        try:
            display_path = str(path.relative_to(ROOT_DIR))
        except ValueError:
            display_path = str(path)

        return {
            "file_path": display_path,
            "absolute_path": str(path),
            "size": size,
            "lines": content.count("\n") + (1 if content and not content.endswith("\n") else 0),
            "content": content,
            "root_dir": str(ROOT_DIR),
        }
    except UnicodeDecodeError:
        return {"error": "文件不是文本格式，或编码不正确"}
    except Exception as e:
        return {"error": f"读取失败: {str(e)}"}


def self_write(file_path: str, content: str, encoding: str = "utf-8", create_backup: bool = True) -> dict[str, Any]:
    """
    写入/修改本程序源代码

    修改流程：
    1. 安全检查（路径、扩展名）
    2. 创建备份（默认开启）
    3. 写入文件
    4. 语法检查（如果是 .py 文件）

    Args:
        file_path: 文件路径
        content: 新内容
        create_backup: 是否创建备份（默认 True）
    """
    try:
        path = _resolve_path(file_path)
    except PermissionError as e:
        return {"error": str(e)}

    # 扩展名检查
    if not _check_extension(path):
        return {"error": f"不支持的文件类型: {path.suffix}。允许的类型: {', '.join(sorted(ALLOWED_EXTENSIONS))}"}

    # 自我修改功能是否启用
    if not SELF_MODIFY_ENABLED:
        return {"error": "自我修改功能已被禁用。请在 config.yaml 中设置 self_modify.enabled: true"}

    # 检查是否为关键保护文件
    try:
        relative = path.relative_to(ROOT_DIR)
        relative_str = str(relative).replace("\\", "/")
    except ValueError:
        relative_str = str(path)

    if _is_protected(relative_str):
        return {"error": f"安全限制：文件 '{relative_str}' 是受保护的核心文件，禁止修改。受保护文件: {', '.join(PROTECTED_FILES)}"}

    logger.warning(f"自我修改写入目标: {relative_str}")

    # 创建备份
    backup_path = None
    if create_backup and path.exists():
        backup_path = _create_backup(path)

    # 写入
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", encoding=encoding) as f:
            f.write(content)
    except Exception as e:
        # 写入失败，尝试恢复备份
        if backup_path and Path(backup_path).exists():
            shutil.copy2(backup_path, path)
            logger.warning(f"写入失败，已从备份恢复: {backup_path}")
        return {"error": f"写入失败: {str(e)}"}

    # Python 语法检查
    syntax_ok = True
    syntax_msg = ""
    if path.suffix == ".py":
        syntax_ok, syntax_msg = _syntax_check(content, str(path))
        if not syntax_ok:
            logger.warning(f"自我修改语法检查未通过: {syntax_msg}")

    result = {
        "file_path": relative_str,
        "size": path.stat().st_size,
        "backup_path": backup_path,
        "syntax_check": syntax_ok,
        "syntax_message": syntax_msg,
    }

    if not syntax_ok:
        result["warning"] = (
            f"⚠️ 语法检查未通过: {syntax_msg}\n"
            f"文件已写入但可能无法正常运行。"
            f"备份文件: {backup_path}\n"
            f"建议使用 self_write 恢复备份或修正语法错误。"
        )

    logger.info(f"自我修改写入: {relative_str} (备份: {backup_path}, 语法: {'✅' if syntax_ok else '❌'})")
    return result


def self_edit(file_path: str, old_string: str, new_string: str, encoding: str = "utf-8", create_backup: bool = True) -> dict[str, Any]:
    """
    精确编辑本程序源代码（字符串替换方式，更安全）

    Args:
        file_path: 文件路径
        old_string: 要替换的原始字符串（必须完全匹配）
        new_string: 替换后的新字符串（空字符串表示删除）
        create_backup: 是否创建备份
    """
    try:
        path = _resolve_path(file_path)
    except PermissionError as e:
        return {"error": str(e)}

    if not path.exists():
        return {"error": f"文件不存在: {file_path}"}

    # 自我修改功能是否启用
    if not SELF_MODIFY_ENABLED:
        return {"error": "自我修改功能已被禁用。请在 config.yaml 中设置 self_modify.enabled: true"}

    # 扩展名检查
    if not _check_extension(path):
        return {"error": f"不支持的文件类型: {path.suffix}。允许的类型: {', '.join(sorted(ALLOWED_EXTENSIONS))}"}

    # 检查是否为关键保护文件
    try:
        relative = path.relative_to(ROOT_DIR)
        relative_str = str(relative).replace("\\", "/")
    except ValueError:
        relative_str = str(path)

    if _is_protected(relative_str):
        return {"error": f"安全限制：文件 '{relative_str}' 是受保护的核心文件，禁止修改。受保护文件: {', '.join(PROTECTED_FILES)}"}

    # 读取当前内容
    try:
        with open(path, "r", encoding=encoding) as f:
            content = f.read()
    except Exception as e:
        return {"error": f"读取失败: {str(e)}"}

    # 检查 old_string 是否存在
    if old_string not in content:
        return {"error": "未找到要替换的内容。请确保 old_string 与文件中的内容完全一致（包括缩进和空格）。"}

    # 检查是否唯一
    count = content.count(old_string)
    if count > 1:
        return {
            "error": f"要替换的内容在文件中出现了 {count} 次，不是唯一的。请提供更多上下文使匹配唯一。",
            "occurrences": count,
        }

    # 生成 diff
    new_content = content.replace(old_string, new_string, 1)
    diff = _generate_diff(content, new_content, str(path))

    # 创建备份
    backup_path = None
    if create_backup:
        backup_path = _create_backup(path)

    # 写入
    try:
        with open(path, "w", encoding=encoding) as f:
            f.write(new_content)
    except Exception as e:
        if backup_path and Path(backup_path).exists():
            shutil.copy2(backup_path, path)
        return {"error": f"写入失败: {str(e)}"}

    # 语法检查
    syntax_ok = True
    syntax_msg = ""
    if path.suffix == ".py":
        syntax_ok, syntax_msg = _syntax_check(new_content, str(path))

    try:
        relative = path.relative_to(ROOT_DIR)
        relative_str = str(relative).replace("\\", "/")
    except ValueError:
        relative_str = str(path)

    result = {
        "file_path": relative_str,
        "replaced": True,
        "diff": diff,
        "backup_path": backup_path,
        "syntax_check": syntax_ok,
        "syntax_message": syntax_msg,
    }

    if not syntax_ok:
        result["warning"] = f"⚠️ 语法检查未通过: {syntax_msg}"

    logger.info(f"自我修改编辑: {relative_str} (备份: {backup_path})")
    return result


def self_create(file_path: str, content: str, encoding: str = "utf-8") -> dict[str, Any]:
    """
    创建新的源代码文件（仅限项目目录内）

    Args:
        file_path: 文件路径
        content: 文件内容
    """
    # 自我修改功能是否启用
    if not SELF_MODIFY_ENABLED:
        return {"error": "自我修改功能已被禁用。请在 config.yaml 中设置 self_modify.enabled: true"}

    try:
        path = _resolve_path(file_path)
    except PermissionError as e:
        return {"error": str(e)}

    if path.exists():
        return {"error": f"文件已存在: {file_path}。如需覆盖，请使用 self_write。"}

    # 扩展名检查
    if not _check_extension(path):
        return {"error": f"不支持的文件类型: {path.suffix}"}

    # 创建
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", encoding=encoding) as f:
            f.write(content)
    except Exception as e:
        return {"error": f"创建失败: {str(e)}"}

    # 语法检查
    syntax_ok = True
    syntax_msg = ""
    if path.suffix == ".py":
        syntax_ok, syntax_msg = _syntax_check(content, str(path))

    try:
        relative = path.relative_to(ROOT_DIR)
        relative_str = str(relative).replace("\\", "/")
    except ValueError:
        relative_str = str(path)

    logger.info(f"自我修改创建: {relative_str}")
    return {
        "file_path": relative_str,
        "created": True,
        "syntax_check": syntax_ok,
        "syntax_message": syntax_msg,
    }


def self_list(directory: str = ".", pattern: str = "*.py", recursive: bool = True) -> dict[str, Any]:
    """
    列出项目源代码文件结构

    Args:
        directory: 目录路径（相对于项目根目录）
        pattern: 文件匹配模式
        recursive: 是否递归
    """
    try:
        path = _resolve_path(directory)
    except PermissionError as e:
        return {"error": str(e)}

    if not path.exists():
        return {"error": f"目录不存在: {directory}"}

    if not path.is_dir():
        return {"error": f"不是目录: {directory}"}

    files = []
    if recursive:
        matched = list(path.rglob(pattern))
    else:
        matched = list(path.glob(pattern))

    for f in sorted(matched):
        if f.is_file():
            # 跳过 __pycache__ 等
            if "__pycache__" in str(f) or ".git" in str(f):
                continue
            try:
                relative = f.relative_to(ROOT_DIR)
                relative_str = str(relative).replace("\\", "/")
            except ValueError:
                relative_str = str(f)

            files.append({
                "path": relative_str,
                "size": f.stat().st_size,
                "suffix": f.suffix,
            })

    return {
        "root_dir": str(ROOT_DIR),
        "directory": directory,
        "pattern": pattern,
        "count": len(files),
        "files": files,
    }


def self_diff(file_path: str, backup_path: str | None = None) -> dict[str, Any]:
    """
    查看文件的修改差异（与备份对比）

    Args:
        file_path: 当前文件路径
        backup_path: 备份文件路径（None 则自动找最近的备份）
    """
    try:
        path = _resolve_path(file_path)
    except PermissionError as e:
        return {"error": str(e)}

    if not path.exists():
        return {"error": f"文件不存在: {file_path}"}

    # 读取当前内容
    try:
        with open(path, "r", encoding="utf-8") as f:
            current = f.read()
    except Exception as e:
        return {"error": f"读取当前文件失败: {str(e)}"}

    # 查找备份
    if backup_path:
        bp = Path(backup_path)
    else:
        # 自动查找最近的备份
        try:
            relative = path.relative_to(ROOT_DIR)
            backup_subdir = BACKUP_DIR / relative.parent
        except ValueError:
            return {"error": "无法确定备份位置"}

        if not backup_subdir.exists():
            return {
                "file_path": file_path,
                "message": "未找到备份文件（没有历史修改记录）",
                "has_diff": False,
            }

        # 找最新的备份
        backups = sorted(backup_subdir.glob(f"{path.stem}_*{path.suffix}.bak"), reverse=True)
        if not backups:
            return {
                "file_path": file_path,
                "message": "未找到备份文件",
                "has_diff": False,
            }
        bp = backups[0]

    if not bp.exists():
        return {"error": f"备份文件不存在: {bp}"}

    # 读取备份内容
    try:
        with open(bp, "r", encoding="utf-8") as f:
            backup_content = f.read()
    except Exception as e:
        return {"error": f"读取备份文件失败: {str(e)}"}

    # 生成 diff
    diff = _generate_diff(backup_content, current, f"{file_path} (备份 vs 当前)")

    return {
        "file_path": file_path,
        "backup_path": str(bp),
        "has_diff": backup_content != current,
        "diff": diff,
    }


def self_restore(file_path: str, backup_path: str | None = None) -> dict[str, Any]:
    """
    从备份恢复文件

    Args:
        file_path: 要恢复的文件路径
        backup_path: 备份文件路径（None 则自动找最近的备份）
    """
    try:
        path = _resolve_path(file_path)
    except PermissionError as e:
        return {"error": str(e)}

    # 查找备份
    if backup_path:
        bp = Path(backup_path)
    else:
        try:
            relative = path.relative_to(ROOT_DIR)
            backup_subdir = BACKUP_DIR / relative.parent
        except ValueError:
            return {"error": "无法确定备份位置"}

        if not backup_subdir.exists():
            return {"error": "未找到备份目录"}

        backups = sorted(backup_subdir.glob(f"{path.stem}_*{path.suffix}.bak"), reverse=True)
        if not backups:
            return {"error": "未找到备份文件"}
        bp = backups[0]

    if not bp.exists():
        return {"error": f"备份文件不存在: {bp}"}

    # 先备份当前版本（以防恢复错误）
    if path.exists():
        _create_backup(path)

    # 恢复
    try:
        shutil.copy2(bp, path)
    except Exception as e:
        return {"error": f"恢复失败: {str(e)}"}

    try:
        relative = path.relative_to(ROOT_DIR)
        relative_str = str(relative).replace("\\", "/")
    except ValueError:
        relative_str = str(path)

    logger.info(f"自我修改恢复: {relative_str} ← {bp}")
    return {
        "file_path": relative_str,
        "restored_from": str(bp),
        "message": f"已从备份恢复: {bp}",
    }


def self_syntax_check(file_path: str) -> dict[str, Any]:
    """
    对源代码文件执行语法检查

    Args:
        file_path: 文件路径
    """
    try:
        path = _resolve_path(file_path)
    except PermissionError as e:
        return {"error": str(e)}

    if not path.exists():
        return {"error": f"文件不存在: {file_path}"}

    if path.suffix != ".py":
        return {"error": "语法检查仅支持 Python 文件"}

    try:
        with open(path, "r", encoding="utf-8") as f:
            content = f.read()
    except Exception as e:
        return {"error": f"读取失败: {str(e)}"}

    ok, msg = _syntax_check(content, str(path))
    return {
        "file_path": file_path,
        "syntax_ok": ok,
        "message": msg,
    }


def self_project_info() -> dict[str, Any]:
    """获取项目结构信息（自我认知）"""
    py_files = []
    total_size = 0

    for f in ROOT_DIR.rglob("*.py"):
        if "__pycache__" in str(f) or ".git" in str(f):
            continue
        try:
            relative = f.relative_to(ROOT_DIR)
            relative_str = str(relative).replace("\\", "/")
            size = f.stat().st_size
            total_size += size
            py_files.append({
                "path": relative_str,
                "size": size,
            })
        except Exception:
            continue

    return {
        "root_dir": str(ROOT_DIR),
        "total_py_files": len(py_files),
        "total_size_bytes": total_size,
        "total_size_human": f"{total_size / 1024:.1f} KB",
        "files": py_files,
        "backup_dir": str(BACKUP_DIR),
        "allowed_extensions": sorted(ALLOWED_EXTENSIONS),
    }


def _generate_diff(old_content: str, new_content: str, filename: str = "") -> str:
    """生成统一格式 diff"""
    old_lines = old_content.splitlines(keepends=True)
    new_lines = new_content.splitlines(keepends=True)

    diff_lines = list(difflib.unified_diff(
        old_lines, new_lines,
        fromfile=f"{filename} (修改前)",
        tofile=f"{filename} (修改后)",
        lineterm="",
    ))

    if not diff_lines:
        return "（无差异）"

    return "\n".join(diff_lines)
