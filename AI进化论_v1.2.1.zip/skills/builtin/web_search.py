"""
AI进化论 — 内置技能：网络搜索
优先使用 duckduckgo-search 库，回退到 HTML 解析
"""

from typing import Any
import httpx


def web_search(query: str, max_results: int = 10) -> dict[str, Any]:
    """搜索网页"""
    # 优先使用 duckduckgo-search 库
    try:
        from duckduckgo_search import DDGS
        with DDGS() as ddgs:
            results = list(ddgs.text(query, max_results=max_results))
            formatted = []
            for r in results:
                formatted.append({
                    "title": r.get("title", ""),
                    "url": r.get("href", ""),
                    "snippet": r.get("body", ""),
                })
            return {"query": query, "count": len(formatted), "results": formatted}
    except ImportError:
        pass
    except Exception as e:
        # 回退到 HTML 解析
        pass

    # 回退：HTML 解析 DuckDuckGo
    return _search_html(query, max_results)


def _search_html(query: str, max_results: int = 10) -> dict[str, Any]:
    """HTML 解析搜索（回退方案）"""
    try:
        with httpx.Client(timeout=15) as client:
            resp = client.get(
                "https://html.duckduckgo.com/html/",
                params={"q": query},
                headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"},
                follow_redirects=True,
            )
            resp.raise_for_status()

            from html.parser import HTMLParser

            class ResultParser(HTMLParser):
                def __init__(self):
                    super().__init__()
                    self.results = []
                    self.current = {}
                    self.in_result = False
                    self.in_snippet = False
                    self.capture_text = ""

                def handle_starttag(self, tag, attrs):
                    attrs_dict = dict(attrs)
                    cls = attrs_dict.get("class", "")
                    href = attrs_dict.get("href", "")
                    if tag == "a" and "result__a" in cls:
                        self.in_result = True
                        self.current = {"url": href}
                        self.capture_text = ""
                    elif tag == "a" and "result__snippet" in cls:
                        self.in_snippet = True
                        self.capture_text = ""

                def handle_data(self, data):
                    if self.in_result:
                        self.capture_text += data
                    elif self.in_snippet:
                        self.capture_text += data

                def handle_endtag(self, tag):
                    if tag == "a" and self.in_result:
                        self.current["title"] = self.capture_text.strip()
                        self.in_result = False
                    elif tag == "a" and self.in_snippet:
                        self.current["snippet"] = self.capture_text.strip()
                        self.in_snippet = False
                        if self.current.get("title") and self.current.get("url"):
                            url = self.current.get("url", "")
                            if url.startswith("/"):
                                # 尝试提取真实 URL
                                try:
                                    from urllib.parse import unquote, urlparse, parse_qs
                                    parsed = urlparse(url)
                                    params = parse_qs(parsed.query)
                                    if "uddg" in params:
                                        url = unquote(params["uddg"][0])
                                    else:
                                        url = "https://duckduckgo.com" + url
                                except Exception:
                                    url = "https://duckduckgo.com" + url
                            self.results.append({
                                "title": self.current.get("title", ""),
                                "url": url,
                                "snippet": self.current.get("snippet", ""),
                            })
                            self.current = {}
                            if len(self.results) >= max_results:
                                raise StopIteration

            parser = ResultParser()
            try:
                parser.feed(resp.text)
            except StopIteration:
                pass

            return {"query": query, "count": len(parser.results), "results": parser.results[:max_results]}

    except Exception as e:
        return {"error": str(e), "query": query}


def web_fetch(url: str, max_length: int = 10000) -> dict[str, Any]:
    """抓取网页内容"""
    try:
        with httpx.Client(timeout=20, follow_redirects=True) as client:
            resp = client.get(
                url,
                headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"},
            )
            resp.raise_for_status()

            content_type = resp.headers.get("content-type", "")
            if "text/html" in content_type:
                import re
                text = re.sub(r"<script[^>]*>.*?</script>", "", resp.text, flags=re.DOTALL)
                text = re.sub(r"<style[^>]*>.*?</style>", "", text, flags=re.DOTALL)
                text = re.sub(r"<[^>]+>", " ", text)
                text = re.sub(r"\s+", " ", text).strip()
                return {
                    "url": str(resp.url),
                    "status": resp.status_code,
                    "content": text[:max_length],
                    "truncated": len(text) > max_length,
                }
            else:
                return {
                    "url": str(resp.url),
                    "status": resp.status_code,
                    "content_type": content_type,
                    "content": resp.text[:5000],
                }
    except Exception as e:
        return {"error": str(e), "url": url}
