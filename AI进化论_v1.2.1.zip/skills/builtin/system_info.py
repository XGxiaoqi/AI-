"""
AI进化论 — 内置技能：系统信息与操作
获取系统状态、进程管理、剪贴板等
"""

import platform
import os
import subprocess
import shlex
from typing import Any
from pathlib import Path


# 安全命令白名单（只允许这些命令前缀）
SAFE_COMMAND_PREFIXES = [
    "dir", "ls", "type", "cat", "head", "tail",
    "find", "where", "which", "echo",
    "pip list", "pip show", "python --version", "python -c",
    "git status", "git log", "git diff", "git branch", "git remote",
    "node --version", "npm list",
    "systeminfo", "tasklist", "ipconfig", "ping", "netstat",
    "whoami", "hostname", "date", "time",
    "chcp", "set",
]

# 严格禁止的命令模式
BLOCKED_PATTERNS = [
    "rm ", "del ", "rmdir", "format", "shutdown", "restart",
    "mkfs", "dd if=", "> ", ">> ",
    "curl", "wget", "powershell -e", "cmd /c",
    "net user", "net localgroup", "reg ",
    "taskkill", "kill ",
]


def system_info() -> dict[str, Any]:
    """获取系统基本信息"""
    try:
        import psutil
        cpu_percent = psutil.cpu_percent(interval=1)
        memory = psutil.virtual_memory()
        disk_path = "C:\\" if os.name == "nt" else "/"
        disk = psutil.disk_usage(disk_path)

        return {
            "platform": platform.platform(),
            "python": platform.python_version(),
            "cpu": {
                "model": platform.processor(),
                "cores": os.cpu_count(),
                "usage_percent": cpu_percent,
            },
            "memory": {
                "total_gb": round(memory.total / (1024**3), 1),
                "available_gb": round(memory.available / (1024**3), 1),
                "usage_percent": memory.percent,
            },
            "disk": {
                "total_gb": round(disk.total / (1024**3), 1),
                "free_gb": round(disk.free / (1024**3), 1),
                "usage_percent": disk.percent,
            },
        }
    except ImportError:
        return {
            "platform": platform.platform(),
            "python": platform.python_version(),
            "warning": "psutil 未安装，无法获取详细系统信息",
        }


def process_list(search: str = "", limit: int = 20) -> dict[str, Any]:
    """列出运行中的进程"""
    try:
        import psutil

        processes = []
        for proc in psutil.process_iter(["pid", "name", "cpu_percent", "memory_percent"]):
            try:
                info = proc.info
                name = info["name"] or ""
                if search and search.lower() not in name.lower():
                    continue
                processes.append({
                    "pid": info["pid"],
                    "name": name,
                    "cpu_percent": round(info["cpu_percent"] or 0, 1),
                    "memory_percent": round(info["memory_percent"] or 0, 1),
                })
                if len(processes) >= limit:
                    break
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue

        processes.sort(key=lambda x: x["cpu_percent"], reverse=True)
        return {"search": search, "count": len(processes), "processes": processes}
    except ImportError:
        return {"error": "psutil 未安装"}


def run_command(command: str, timeout: int = 30, cwd: str = ".") -> dict[str, Any]:
    """
    执行系统命令（白名单模式，只允许安全的只读命令）
    """
    cmd_stripped = command.strip()

    # 检查危险模式
    cmd_lower = cmd_stripped.lower()
    for pattern in BLOCKED_PATTERNS:
        if pattern.lower() in cmd_lower:
            return {"error": f"安全限制：禁止执行此命令（包含被阻止的模式）"}

    # 检查是否在白名单内
    is_safe = False
    for prefix in SAFE_COMMAND_PREFIXES:
        if cmd_lower.startswith(prefix.lower()):
            is_safe = True
            break

    if not is_safe:
        return {
            "error": f"安全限制：命令不在白名单中。允许的命令前缀: {', '.join(SAFE_COMMAND_PREFIXES[:10])}...",
            "hint": "如需执行更多命令，请在设置中启用高级模式",
        }

    try:
        # Windows 使用 shell=True 但不再拼接用户输入
        # 使用 shlex 分割参数（Linux/Mac）
        if os.name == "nt":
            result = subprocess.run(
                cmd_stripped,
                shell=True,
                capture_output=True,
                text=True,
                timeout=timeout,
                cwd=cwd,
            )
        else:
            args = shlex.split(cmd_stripped)
            result = subprocess.run(
                args,
                capture_output=True,
                text=True,
                timeout=timeout,
                cwd=cwd,
            )

        return {
            "command": cmd_stripped,
            "exit_code": result.returncode,
            "stdout": result.stdout[:10000],
            "stderr": result.stderr[:5000],
        }
    except subprocess.TimeoutExpired:
        return {"error": f"命令超时 ({timeout}s): {cmd_stripped}"}
    except FileNotFoundError:
        return {"error": f"命令未找到: {cmd_stripped.split()[0]}"}
    except Exception as e:
        return {"error": str(e)}


def clipboard_write(text: str) -> dict[str, Any]:
    """写入剪贴板"""
    try:
        import pyperclip
        pyperclip.copy(text)
        return {"success": True, "length": len(text)}
    except ImportError:
        # 回退方案：使用 Windows 原生方式
        if os.name == "nt":
            try:
                import subprocess
                process = subprocess.Popen(
                    ["clip"],
                    stdin=subprocess.PIPE,
                    text=True,
                )
                process.communicate(text, timeout=5)
                return {"success": True, "length": len(text)}
            except Exception:
                pass
        return {"error": "剪贴板写入失败，请安装 pyperclip"}
    except Exception as e:
        return {"error": str(e)}


def clipboard_read() -> dict[str, Any]:
    """读取剪贴板"""
    try:
        import pyperclip
        text = pyperclip.paste()
        return {"content": text, "length": len(text)}
    except ImportError:
        return {"error": "pyperclip 未安装"}
    except Exception as e:
        return {"error": str(e)}
