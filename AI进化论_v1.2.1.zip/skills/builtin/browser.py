"""
AI进化论 — 内置技能：浏览器自动化（Playwright）
支持打开网页、截图、点击、填表单等操作
使用单例浏览器实例提升性能
"""

from typing import Any
from loguru import logger


# 全局浏览器实例（复用）
_browser_instance = None
_playwright_instance = None


def _get_browser(headless: bool = True):
    """获取或创建浏览器实例（复用）"""
    global _browser_instance, _playwright_instance
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        raise ImportError("Playwright 未安装。请运行: pip install playwright && playwright install chromium")

    if _browser_instance is None or not _browser_instance.is_connected():
        if _playwright_instance is None:
            _playwright_instance = sync_playwright().start()
        try:
            _browser_instance = _playwright_instance.chromium.launch(
                headless=headless,
                args=["--no-sandbox", "--disable-dev-shm-usage"],
            )
        except Exception:
            # 浏览器可能已关闭，重新启动
            _playwright_instance = sync_playwright().start()
            _browser_instance = _playwright_instance.chromium.launch(
                headless=headless,
                args=["--no-sandbox", "--disable-dev-shm-usage"],
            )

    return _browser_instance


def browser_open(url: str, headless: bool = True) -> dict[str, Any]:
    """打开网页并获取内容"""
    try:
        browser = _get_browser(headless)
        page = browser.new_page()
        try:
            page.goto(url, timeout=30000, wait_until="domcontentloaded")
            # 等待主要内容加载
            page.wait_for_timeout(1000)

            title = page.title()
            text_content = page.inner_text("body")[:15000]

            return {
                "url": url,
                "title": title,
                "text_content": text_content,
                "truncated": len(text_content) >= 15000,
            }
        finally:
            page.close()
    except ImportError:
        return {"error": "Playwright 未安装。请运行: playwright install chromium"}
    except Exception as e:
        return {"error": str(e), "url": url}


def browser_screenshot(url: str, file_path: str = "") -> dict[str, Any]:
    """对网页截图"""
    try:
        import os
        browser = _get_browser(headless=True)
        page = browser.new_page(viewport={"width": 1280, "height": 800})
        try:
            page.goto(url, timeout=30000, wait_until="domcontentloaded")
            page.wait_for_timeout(1500)  # 等待页面渲染

            if not file_path:
                file_path = f"./data/screenshot_{abs(hash(url)) % 0xFFFF}.png"
            os.makedirs(os.path.dirname(file_path) or ".", exist_ok=True)
            page.screenshot(path=file_path, full_page=False)

            return {"url": url, "screenshot": os.path.abspath(file_path)}
        finally:
            page.close()
    except ImportError:
        return {"error": "Playwright 未安装。请运行: playwright install chromium"}
    except Exception as e:
        return {"error": str(e), "url": url}


def browser_click(url: str, selector: str, headless: bool = True) -> dict[str, Any]:
    """打开网页并点击指定元素"""
    try:
        browser = _get_browser(headless)
        page = browser.new_page()
        try:
            page.goto(url, timeout=30000, wait_until="domcontentloaded")
            page.click(selector, timeout=5000)
            page.wait_for_timeout(2000)

            title = page.title()
            url_after = page.url
            text = page.inner_text("body")[:10000]

            return {
                "url_before": url,
                "url_after": url_after,
                "title": title,
                "content": text,
            }
        finally:
            page.close()
    except ImportError:
        return {"error": "Playwright 未安装。请运行: playwright install chromium"}
    except Exception as e:
        return {"error": str(e)}


def browser_fill(url: str, selector: str, value: str, headless: bool = True) -> dict[str, Any]:
    """打开网页并填写表单"""
    try:
        browser = _get_browser(headless)
        page = browser.new_page()
        try:
            page.goto(url, timeout=30000, wait_until="domcontentloaded")
            page.fill(selector, value, timeout=5000)
            page.wait_for_timeout(500)

            return {"url": url, "selector": selector, "value": value, "success": True}
        finally:
            page.close()
    except ImportError:
        return {"error": "Playwright 未安装。请运行: playwright install chromium"}
    except Exception as e:
        return {"error": str(e)}


def browser_close():
    """关闭浏览器实例（释放资源）"""
    global _browser_instance, _playwright_instance
    try:
        if _browser_instance and _browser_instance.is_connected():
            _browser_instance.close()
        if _playwright_instance:
            _playwright_instance.stop()
    except Exception:
        pass
    finally:
        _browser_instance = None
        _playwright_instance = None
