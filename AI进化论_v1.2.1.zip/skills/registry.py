"""
AI进化论 — 技能注册表
定义 Skill 的标准格式和注册机制
"""

from dataclasses import dataclass, field
from typing import Any, Callable
from enum import Enum


class SkillCategory(str, Enum):
    FILE = "文件操作"
    SEARCH = "网络搜索"
    CODING = "编程"
    BROWSER = "浏览器"
    SYSTEM = "系统"
    CUSTOM = "自定义"


@dataclass
class SkillParameter:
    """技能参数定义"""
    name: str
    type: str  # string / number / boolean / object / array
    description: str
    required: bool = True
    default: Any = None


@dataclass
class SkillDef:
    """
    技能定义 — 每个 Skill 的核心描述
    兼容 OpenAI Function Calling 的 tools 格式
    """

    name: str  # 唯一名称
    description: str  # 功能描述
    category: SkillCategory = SkillCategory.CUSTOM
    version: str = "1.0.0"
    author: str = ""
    parameters: list[SkillParameter] = field(default_factory=list)
    enabled: bool = True
    handler: Callable | None = None  # 实际执行函数

    def to_tool_schema(self) -> dict:
        """转为 OpenAI Function Calling 工具格式"""
        properties = {}
        required_list = []

        for param in self.parameters:
            properties[param.name] = {
                "type": param.type,
                "description": param.description,
            }
            if param.required:
                required_list.append(param.name)

        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": {
                    "type": "object",
                    "properties": properties,
                    "required": required_list,
                },
            },
        }

    def validate_args(self, args: dict) -> tuple[bool, str]:
        """验证参数"""
        for param in self.parameters:
            if param.required and param.name not in args:
                return False, f"缺少必要参数: {param.name}"
        return True, ""


class SkillRegistry:
    """技能注册表 — 管理所有已注册的技能"""

    def __init__(self):
        self._skills: dict[str, SkillDef] = {}

    def register(self, skill: SkillDef) -> None:
        """注册一个技能"""
        if skill.name in self._skills:
            raise ValueError(f"技能 {skill.name} 已存在")
        self._skills[skill.name] = skill

    def unregister(self, name: str) -> bool:
        """注销技能"""
        if name in self._skills:
            del self._skills[name]
            return True
        return False

    def get(self, name: str) -> SkillDef | None:
        return self._skills.get(name)

    def list_all(self) -> list[SkillDef]:
        return list(self._skills.values())

    def list_enabled(self) -> list[SkillDef]:
        return [s for s in self._skills.values() if s.enabled]

    def list_by_category(self, category: SkillCategory) -> list[SkillDef]:
        return [s for s in self._skills.values() if s.category == category]

    def get_tools_schema(self) -> list[dict]:
        """获取所有已启用技能的工具 schema（供 LLM 调用）"""
        return [s.to_tool_schema() for s in self.list_enabled()]

    def set_enabled(self, name: str, enabled: bool) -> bool:
        skill = self._skills.get(name)
        if skill:
            skill.enabled = enabled
            return True
        return False

    def execute(self, name: str, args: dict) -> Any:
        """执行一个技能"""
        skill = self._skills.get(name)
        if not skill:
            return {"error": f"技能不存在: {name}"}
        if not skill.enabled:
            return {"error": f"技能已禁用: {name}"}
        if not skill.handler:
            return {"error": f"技能无执行函数: {name}"}

        valid, msg = skill.validate_args(args)
        if not valid:
            return {"error": msg}

        try:
            return skill.handler(**args)
        except Exception as e:
            return {"error": f"技能执行失败: {str(e)}"}
