"""
AI进化论 — 设置对话框
支持 LLM 测试连接、Ollama 模型选择、记忆库配置
"""

from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QTabWidget, QWidget,
    QLabel, QLineEdit, QPushButton, QComboBox, QCheckBox,
    QSpinBox, QFormLayout, QGroupBox, QMessageBox, QTextEdit,
)
from PyQt6.QtCore import Qt, pyqtSignal, QThread
from PyQt6.QtGui import QFont

from core.config import config


class TestConnectionWorker(QThread):
    """测试连接的工作线程"""
    finished = pyqtSignal(bool, str)  # success, message

    def __init__(self, provider, **kwargs):
        super().__init__()
        self.provider = provider
        self.kwargs = kwargs

    def run(self):
        try:
            if self.provider == "ollama":
                import httpx
                base_url = self.kwargs.get("base_url", "http://localhost:11434")
                with httpx.Client(timeout=5) as client:
                    resp = client.get(f"{base_url}/api/tags")
                    if resp.status_code == 200:
                        models = [m["name"] for m in resp.json().get("models", [])]
                        return self.finished.emit(True, f"连接成功！可用模型: {', '.join(models[:5])}")
                    return self.finished.emit(False, f"连接失败: HTTP {resp.status_code}")
            elif self.provider in ("deepseek", "aliyun_bailian"):
                from openai import OpenAI
                api_key = self.kwargs.get("api_key", "")
                base_url = self.kwargs.get("base_url", "")
                if not api_key:
                    return self.finished.emit(False, "API Key 为空")
                client = OpenAI(api_key=api_key, base_url=base_url)
                models = client.models.list()
                model_names = [m.id for m in models.data[:5]]
                return self.finished.emit(True, f"连接成功！可用模型: {', '.join(model_names)}")
            else:
                return self.finished.emit(False, f"未知 Provider: {self.provider}")
        except Exception as e:
            return self.finished.emit(False, f"连接失败: {str(e)}")


class SettingsDialog(QDialog):
    """设置对话框"""

    config_changed = pyqtSignal()

    def __init__(self, parent=None, agent=None):
        super().__init__(parent)
        self.agent = agent
        self.setWindowTitle("AI进化论 — 设置")
        self.setMinimumSize(600, 500)
        self._init_ui()
        self._load_config()

    def _init_ui(self):
        layout = QVBoxLayout(self)

        tabs = QTabWidget()

        # ==== LLM 设置 ====
        llm_tab = QWidget()
        llm_layout = QVBoxLayout(llm_tab)

        # 本地 Ollama
        local_group = QGroupBox("本地 Ollama")
        local_form = QFormLayout()
        self._ollama_enabled = QCheckBox("启用")
        local_form.addRow("状态:", self._ollama_enabled)
        self._ollama_url = QLineEdit()
        local_form.addRow("服务地址:", self._ollama_url)
        self._ollama_model = QComboBox()
        self._ollama_model.setEditable(True)
        local_form.addRow("默认模型:", self._ollama_model)

        ollama_test_btn = QPushButton("🔍 测试连接")
        ollama_test_btn.clicked.connect(self._test_ollama)
        local_form.addRow("", ollama_test_btn)

        ollama_refresh_btn = QPushButton("🔄 刷新模型列表")
        ollama_refresh_btn.clicked.connect(self._refresh_ollama_models)
        local_form.addRow("", ollama_refresh_btn)

        local_group.setLayout(local_form)
        llm_layout.addWidget(local_group)

        # 云端 API
        cloud_group = QGroupBox("云端 API")
        cloud_form = QFormLayout()

        self._ds_enabled = QCheckBox("启用 DeepSeek")
        self._ds_key = QLineEdit()
        self._ds_key.setEchoMode(QLineEdit.EchoMode.Password)
        self._ds_url = QLineEdit()

        self._ali_enabled = QCheckBox("启用 阿里百炼")
        self._ali_key = QLineEdit()
        self._ali_key.setEchoMode(QLineEdit.EchoMode.Password)
        self._ali_url = QLineEdit()

        cloud_form.addRow(self._ds_enabled)
        cloud_form.addRow("API Key:", self._ds_key)
        cloud_form.addRow("Base URL:", self._ds_url)

        ds_test_btn = QPushButton("🔍 测试 DeepSeek 连接")
        ds_test_btn.clicked.connect(self._test_deepseek)
        cloud_form.addRow("", ds_test_btn)

        cloud_form.addRow(self._ali_enabled)
        cloud_form.addRow("API Key:", self._ali_key)
        cloud_form.addRow("Base URL:", self._ali_url)

        ali_test_btn = QPushButton("🔍 测试阿里百炼连接")
        ali_test_btn.clicked.connect(self._test_aliyun)
        cloud_form.addRow("", ali_test_btn)

        cloud_group.setLayout(cloud_form)
        llm_layout.addWidget(cloud_group)
        llm_layout.addStretch()

        # ==== 记忆库设置 ====
        memory_tab = QWidget()
        memory_form = QFormLayout(memory_tab)
        self._sqlite_path = QLineEdit()
        memory_form.addRow("SQLite 路径:", self._sqlite_path)
        self._chroma_path = QLineEdit()
        memory_form.addRow("ChromaDB 路径:", self._chroma_path)
        self._search_top_k = QSpinBox()
        self._search_top_k.setRange(1, 50)
        memory_form.addRow("搜索返回数量:", self._search_top_k)
        self._hybrid_vec_weight = QSpinBox()
        self._hybrid_vec_weight.setRange(0, 100)
        self._hybrid_vec_weight.setSuffix("%")
        memory_form.addRow("向量搜索权重:", self._hybrid_vec_weight)

        # ==== MCP 设置 ====
        mcp_tab = QWidget()
        mcp_layout = QFormLayout(mcp_tab)
        self._mcp_enabled = QCheckBox("自动启动 MCP 服务")
        mcp_layout.addRow(self._mcp_enabled)
        self._mcp_host = QLineEdit()
        mcp_layout.addRow("监听地址:", self._mcp_host)
        self._mcp_port = QSpinBox()
        self._mcp_port.setRange(1024, 65535)
        mcp_layout.addRow("端口:", self._mcp_port)

        # ==== 系统 ====
        sys_tab = QWidget()
        sys_layout = QFormLayout(sys_tab)
        self._max_history = QSpinBox()
        self._max_history.setRange(5, 100)
        sys_layout.addRow("最大对话轮数:", self._max_history)
        self._max_tool_rounds = QSpinBox()
        self._max_tool_rounds.setRange(1, 30)
        sys_layout.addRow("最大工具调用轮数:", self._max_tool_rounds)
        self._log_level = QComboBox()
        self._log_level.addItems(["DEBUG", "INFO", "WARNING", "ERROR"])
        sys_layout.addRow("日志级别:", self._log_level)

        tabs.addTab(llm_tab, "🤖 LLM")
        tabs.addTab(memory_tab, "🧠 记忆库")
        tabs.addTab(mcp_tab, "🔌 MCP")
        tabs.addTab(sys_tab, "⚙️ 系统")

        layout.addWidget(tabs)

        # 按钮
        btn_layout = QHBoxLayout()
        btn_layout.addStretch()
        save_btn = QPushButton("💾 保存")
        save_btn.setStyleSheet("QPushButton { background: #4A90D9; color: white; padding: 8px 20px; border-radius: 4px; }")
        save_btn.clicked.connect(self._save)
        btn_layout.addWidget(save_btn)
        cancel_btn = QPushButton("取消")
        cancel_btn.clicked.connect(self.reject)
        btn_layout.addWidget(cancel_btn)
        layout.addLayout(btn_layout)

    def _load_config(self):
        """加载当前配置到 UI"""
        self._ollama_enabled.setChecked(config.get("llm.local.enabled", True))
        self._ollama_url.setText(config.get("llm.local.base_url", "http://localhost:11434"))
        self._ollama_model.setCurrentText(config.get("llm.local.default_model", "qwen3-coder:latest"))

        self._ds_enabled.setChecked(bool(config.get("llm.cloud.providers.deepseek.api_key", "")))
        self._ds_key.setText(config.get("llm.cloud.providers.deepseek.api_key", ""))
        self._ds_url.setText(config.get("llm.cloud.providers.deepseek.base_url", "https://api.deepseek.com"))

        self._ali_enabled.setChecked(bool(config.get("llm.cloud.providers.aliyun_bailian.api_key", "")))
        self._ali_key.setText(config.get("llm.cloud.providers.aliyun_bailian.api_key", ""))
        self._ali_url.setText(config.get("llm.cloud.providers.aliyun_bailian.base_url", "https://dashscope.aliyuncs.com/compatible-mode/v1"))

        self._sqlite_path.setText(config.get("memory.sqlite_path", "./data/memory.db"))
        self._chroma_path.setText(config.get("memory.chroma_path", "./data/chroma"))
        self._search_top_k.setValue(config.get("memory.search_top_k", 10))
        hybrid = config.get("memory.hybrid_weight", [0.7, 0.3])
        self._hybrid_vec_weight.setValue(int(hybrid[0] * 100))

        self._mcp_enabled.setChecked(config.get("mcp.auto_start", True))
        self._mcp_host.setText(config.get("mcp.host", "127.0.0.1"))
        self._mcp_port.setValue(config.get("mcp.port", 9527))
        self._max_history.setValue(config.get("system.max_history_turns", 20))
        self._max_tool_rounds.setValue(config.get("system.max_tool_rounds", 8))
        self._log_level.setCurrentText(config.get("system.log_level", "INFO"))

    def _save(self):
        """保存配置"""
        config.set("llm.local.enabled", self._ollama_enabled.isChecked())
        config.set("llm.local.base_url", self._ollama_url.text())
        config.set("llm.local.default_model", self._ollama_model.currentText())

        config.set("llm.cloud.providers.deepseek.api_key", self._ds_key.text())
        config.set("llm.cloud.providers.deepseek.base_url", self._ds_url.text())
        config.set("llm.cloud.providers.aliyun_bailian.api_key", self._ali_key.text())
        config.set("llm.cloud.providers.aliyun_bailian.base_url", self._ali_url.text())

        config.set("memory.sqlite_path", self._sqlite_path.text())
        config.set("memory.chroma_path", self._chroma_path.text())
        config.set("memory.search_top_k", self._search_top_k.value())
        vec_w = self._hybrid_vec_weight.value() / 100
        config.set("memory.hybrid_weight", [vec_w, 1 - vec_w])

        config.set("mcp.auto_start", self._mcp_enabled.isChecked())
        config.set("mcp.host", self._mcp_host.text())
        config.set("mcp.port", self._mcp_port.value())
        config.set("system.max_history_turns", self._max_history.value())
        config.set("system.max_tool_rounds", self._max_tool_rounds.value())
        config.set("system.log_level", self._log_level.currentText())

        config.save()

        self.config_changed.emit()
        QMessageBox.information(self, "保存成功", "配置已保存。\n\n⚠️ LLM 后端设置需重启程序后生效。")

    # ==== 测试连接 ====

    def _test_ollama(self):
        self._run_test("ollama", base_url=self._ollama_url.text())

    def _test_deepseek(self):
        self._run_test("deepseek", api_key=self._ds_key.text(), base_url=self._ds_url.text())

    def _test_aliyun(self):
        self._run_test("aliyun_bailian", api_key=self._ali_key.text(), base_url=self._ali_url.text())

    def _run_test(self, provider, **kwargs):
        btn = self.sender()
        if btn:
            btn.setEnabled(False)
            btn.setText("测试中...")

        worker = TestConnectionWorker(provider, **kwargs)
        worker.finished.connect(lambda s, m: self._on_test_result(s, m, btn))
        worker.start()

    def _on_test_result(self, success, message, btn):
        if btn:
            btn.setEnabled(True)
            btn.setText("🔍 测试连接")
        if success:
            QMessageBox.information(self, "连接成功 ✅", message)
        else:
            QMessageBox.warning(self, "连接失败 ❌", message)

    def _refresh_ollama_models(self):
        """从 Ollama 获取模型列表"""
        try:
            import httpx
            base_url = self._ollama_url.text()
            with httpx.Client(timeout=5) as client:
                resp = client.get(f"{base_url}/api/tags")
                if resp.status_code == 200:
                    models = [m["name"] for m in resp.json().get("models", [])]
                    self._ollama_model.clear()
                    self._ollama_model.addItems(models)
                    if models:
                        self._ollama_model.setCurrentIndex(0)
                    QMessageBox.information(self, "刷新成功", f"找到 {len(models)} 个模型")
                else:
                    QMessageBox.warning(self, "刷新失败", f"HTTP {resp.status_code}")
        except Exception as e:
            QMessageBox.warning(self, "刷新失败", str(e))
