"""
AI进化论 — 对话面板
支持 Markdown 渲染、流式输出、会话持久化
"""

from datetime import datetime
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QTextEdit, QPushButton,
    QScrollArea, QLabel, QSplitter, QListWidget, QListWidgetItem,
    QMenu, QApplication,
)
from PyQt6.QtCore import Qt, pyqtSignal, QSize, QThread, pyqtSlot
from PyQt6.QtGui import QFont, QTextCursor, QAction
from PyQt6.QtWebEngineWidgets import QWebEngineView  # 可选


class ChatBubble(QWidget):
    """聊天气泡（支持 Markdown 渲染）"""

    def __init__(self, role: str, content: str, timestamp: str = "", parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 4, 8, 4)

        # 头部：角色 + 时间
        header = QHBoxLayout()
        role_label = QLabel("🧑 你" if role == "user" else "🤖 AI进化论")
        role_label.setStyleSheet(
            "color: #4A90D9; font-weight: bold;" if role == "user"
            else "color: #27AE60; font-weight: bold;"
        )
        header.addWidget(role_label)

        if timestamp:
            time_label = QLabel(timestamp)
            time_label.setStyleSheet("color: #999; font-size: 11px;")
            header.addWidget(time_label)
        header.addStretch()
        layout.addLayout(header)

        # 内容 - 使用 QTextEdit 支持 Markdown
        content_edit = QTextEdit()
        content_edit.setMarkdown(content)
        content_edit.setReadOnly(True)
        content_edit.setStyleSheet("""
            QTextEdit {
                background: #F0F4F8;
                border: none;
                border-radius: 8px;
                padding: 10px;
                margin: 2px 20px 2px 0px;
                font-size: 14px;
            }
        """)

        # 根据内容自动调整高度
        doc = content_edit.document()
        doc.setTextWidth(600)
        height = int(doc.size().height()) + 30
        content_edit.setFixedHeight(min(height, 500))
        content_edit.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)

        layout.addWidget(content_edit)


class ChatPanel(QWidget):
    """对话面板"""

    message_sent = pyqtSignal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._session_list: QListWidget | None = None
        self._chat_area: QVBoxLayout | None = None
        self._input_box: QTextEdit | None = None
        self._scroll: QScrollArea | None = None
        self._sessions: dict[str, dict] = {}  # session_id -> {title, messages}
        self._current_session: str = "default"
        self._sessions["default"] = {"title": "默认对话", "messages": []}
        self._init_ui()

    def _init_ui(self):
        main_layout = QHBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)

        # 左侧：会话列表
        left_panel = QWidget()
        left_panel.setFixedWidth(200)
        left_layout = QVBoxLayout(left_panel)
        left_layout.setContentsMargins(4, 4, 4, 4)

        self._session_list = QListWidget()
        self._session_list.addItem("💬 默认对话")
        self._session_list.setCurrentRow(0)
        self._session_list.setStyleSheet("""
            QListWidget { border: 1px solid #ddd; border-radius: 4px; }
            QListWidget::item:selected { background: #4A90D9; color: white; }
        """)
        self._session_list.currentRowChanged.connect(self._on_session_switch)
        self._session_list.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self._session_list.customContextMenuRequested.connect(self._session_context_menu)
        left_layout.addWidget(QLabel("📋 对话历史"))
        left_layout.addWidget(self._session_list)

        new_btn = QPushButton("+ 新建对话")
        new_btn.setStyleSheet("QPushButton { background: #27AE60; color: white; padding: 6px; border-radius: 4px; }")
        new_btn.clicked.connect(self._new_session)
        left_layout.addWidget(new_btn)

        main_layout.addWidget(left_panel)

        # 右侧：对话区域
        right_panel = QWidget()
        right_layout = QVBoxLayout(right_panel)
        right_layout.setContentsMargins(4, 4, 4, 4)

        # 聊天滚动区
        self._scroll = QScrollArea()
        self._scroll.setWidgetResizable(True)
        self._scroll.setStyleSheet("QScrollArea { border: none; }")

        chat_container = QWidget()
        self._chat_area = QVBoxLayout(chat_container)
        self._chat_area.setAlignment(Qt.AlignmentFlag.AlignTop)
        self._chat_area.addStretch()
        self._scroll.setWidget(chat_container)
        right_layout.addWidget(self._scroll, stretch=1)

        # 输入区
        input_layout = QHBoxLayout()
        self._input_box = QTextEdit()
        self._input_box.setPlaceholderText("输入任务或问题... (Enter 发送，Shift+Enter 换行)")
        self._input_box.setMaximumHeight(120)
        self._input_box.setFont(QFont("Microsoft YaHei", 10))
        self._input_box.setStyleSheet("QTextEdit { border: 1px solid #ccc; border-radius: 6px; padding: 8px; }")

        self._input_box.installEventFilter(self)

        send_btn = QPushButton("发送")
        send_btn.setFixedSize(70, 40)
        send_btn.setStyleSheet(
            "QPushButton { background: #4A90D9; color: white; border-radius: 6px; font-weight: bold; }"
            "QPushButton:hover { background: #357ABD; }"
            "QPushButton:disabled { background: #ccc; }"
        )
        send_btn.clicked.connect(self._send)

        input_layout.addWidget(self._input_box)
        input_layout.addWidget(send_btn)
        right_layout.addLayout(input_layout)

        main_layout.addWidget(right_panel, stretch=1)

    def eventFilter(self, obj, event):
        """Enter 发送，Shift+Enter 换行"""
        from PyQt6.QtCore import QEvent
        if obj == self._input_box and event.type() == QEvent.Type.KeyPress:
            if event.key() == Qt.Key.Key_Return and not event.modifiers() & Qt.KeyboardModifier.ShiftModifier:
                self._send()
                return True
        return super().eventFilter(obj, event)

    def _send(self):
        text = self._input_box.toPlainText().strip()
        if not text:
            return

        self._input_box.clear()
        self.add_message("user", text)
        self.message_sent.emit(text)

    def _new_session(self):
        import uuid
        sid = str(uuid.uuid4())[:8]
        self._sessions[sid] = {"title": f"对话 {sid[:4]}", "messages": []}
        self._session_list.addItem(f"💬 对话 {sid[:4]}")
        self._session_list.setCurrentRow(self._session_list.count() - 1)
        self._current_session = sid
        self.clear_chat()

    def _on_session_switch(self, row):
        """切换会话"""
        if row < 0:
            return
        keys = list(self._sessions.keys())
        if row == 0:
            self._current_session = "default"
        elif row < len(keys):
            self._current_session = keys[row]
        # 重新加载对话
        self._reload_chat()

    def _reload_chat(self):
        """重新加载当前会话的消息"""
        self.clear_chat()
        session_data = self._sessions.get(self._current_session, {})
        for msg in session_data.get("messages", []):
            self._add_bubble(msg["role"], msg["content"], msg.get("timestamp", ""))

    def _session_context_menu(self, pos):
        """会话右键菜单"""
        item = self._session_list.itemAt(pos)
        if not item:
            return
        menu = QMenu()
        delete_action = QAction("删除对话", self)
        delete_action.triggered.connect(lambda: self._delete_session(item))
        menu.addAction(delete_action)
        menu.exec(self._session_list.mapToGlobal(pos))

    def _delete_session(self, item):
        """删除会话"""
        row = self._session_list.row(item)
        if row == 0:
            return  # 不删除默认对话
        keys = list(self._sessions.keys())
        if row < len(keys):
            sid = keys[row]
            self._sessions.pop(sid, None)
        self._session_list.takeItem(row)
        self._session_list.setCurrentRow(0)
        self._current_session = "default"
        self._reload_chat()

    def add_message(self, role: str, content: str):
        """添加消息到聊天区"""
        timestamp = datetime.now().strftime("%H:%M")

        # 保存到会话数据
        if self._current_session in self._sessions:
            self._sessions[self._current_session]["messages"].append({
                "role": role,
                "content": content,
                "timestamp": timestamp,
            })

        self._add_bubble(role, content, timestamp)

    def _add_bubble(self, role: str, content: str, timestamp: str = ""):
        """添加气泡到聊天区"""
        bubble = ChatBubble(role, content, timestamp)
        # 在 stretch 前插入
        self._chat_area.insertWidget(self._chat_area.count() - 1, bubble)
        # 滚动到底部
        from PyQt6.QtCore import QTimer
        QTimer.singleShot(50, self._scroll_to_bottom)

    def update_last_message(self, content: str):
        """更新最后一条消息（用于流式输出追加）"""
        # 找到最后一个 bubble
        for i in range(self._chat_area.count() - 1, -1, -1):
            widget = self._chat_area.itemAt(i).widget()
            if isinstance(widget, ChatBubble):
                # 更新内容
                content_edit = widget.findChild(QTextEdit)
                if content_edit:
                    content_edit.setMarkdown(content)
                    doc = content_edit.document()
                    doc.setTextWidth(600)
                    height = int(doc.size().height()) + 30
                    content_edit.setFixedHeight(min(height, 500))
                break

    def _scroll_to_bottom(self):
        scrollbar = self._scroll.verticalScrollBar()
        scrollbar.setValue(scrollbar.maximum())

    def clear_chat(self):
        """清空聊天区"""
        while self._chat_area.count() > 1:
            item = self._chat_area.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

    @property
    def current_session(self) -> str:
        return self._current_session

    def get_session_messages(self, session_id: str | None = None) -> list[dict]:
        """获取会话消息列表"""
        sid = session_id or self._current_session
        return self._sessions.get(sid, {}).get("messages", [])
