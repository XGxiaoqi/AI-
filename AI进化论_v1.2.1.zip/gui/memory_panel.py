"""
AI进化论 — 记忆管理面板
"""

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLineEdit,
    QTreeWidget, QTreeWidgetItem, QTextEdit, QLabel, QSplitter,
    QComboBox, QSpinBox, QMessageBox, QInputDialog,
)
from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QFont

from memory.manager import MemoryManager
from memory.models import Memory


class MemoryPanel(QWidget):
    """记忆管理面板"""

    def __init__(self, memory_manager: MemoryManager, parent=None):
        super().__init__(parent)
        self.mm = memory_manager
        self._current_memory: Memory | None = None
        self._init_ui()
        self._refresh()

    def _init_ui(self):
        layout = QVBoxLayout(self)

        # 顶部工具栏
        toolbar = QHBoxLayout()

        self._search_box = QLineEdit()
        self._search_box.setPlaceholderText("搜索记忆（语义+关键词）...")
        self._search_box.setStyleSheet("QLineEdit { padding: 6px; border: 1px solid #ccc; border-radius: 4px; }")
        self._search_box.returnPressed.connect(self._search)
        toolbar.addWidget(self._search_box)

        search_btn = QPushButton("🔍 搜索")
        search_btn.clicked.connect(self._search)
        toolbar.addWidget(search_btn)

        self._cat_filter = QComboBox()
        self._cat_filter.addItem("全部分类")
        for cat in self.mm.categories:
            self._cat_filter.addItem(cat)
        self._cat_filter.currentTextChanged.connect(self._refresh)
        toolbar.addWidget(QLabel("分类:"))
        toolbar.addWidget(self._cat_filter)

        self._star_filter = QComboBox()
        self._star_filter.addItems(["全部", "⭐3+", "⭐4+", "⭐5"])
        self._star_filter.currentTextChanged.connect(self._refresh)
        toolbar.addWidget(QLabel("重要程度:"))
        toolbar.addWidget(self._star_filter)

        layout.addLayout(toolbar)

        # 主区域：列表 + 详情
        splitter = QSplitter(Qt.Orientation.Horizontal)

        # 左侧列表
        self._tree = QTreeWidget()
        self._tree.setHeaderLabels(["标题", "分类", "⭐"])
        self._tree.setColumnWidth(0, 200)
        self._tree.setColumnWidth(1, 100)
        self._tree.currentItemChanged.connect(self._on_select)
        splitter.addWidget(self._tree)

        # 右侧详情
        right = QWidget()
        right_layout = QVBoxLayout(right)
        right_layout.setContentsMargins(4, 4, 4, 4)

        detail_header = QHBoxLayout()
        detail_header.addWidget(QLabel("📝 记忆详情"))
        detail_header.addStretch()

        self._importance_spin = QSpinBox()
        self._importance_spin.setRange(1, 5)
        self._importance_spin.setPrefix("⭐ ")
        self._importance_spin.valueChanged.connect(self._on_importance_changed)
        detail_header.addWidget(QLabel("重要程度:"))
        detail_header.addWidget(self._importance_spin)
        right_layout.addLayout(detail_header)

        self._title_edit = QLineEdit()
        self._title_edit.setPlaceholderText("标题")
        right_layout.addWidget(self._title_edit)

        self._content_edit = QTextEdit()
        self._content_edit.setPlaceholderText("内容...")
        right_layout.addWidget(self._content_edit)

        info_layout = QHBoxLayout()
        self._id_label = QLabel("")
        info_layout.addWidget(self._id_label)
        info_layout.addStretch()
        right_layout.addLayout(info_layout)

        btn_layout = QHBoxLayout()
        save_btn = QPushButton("💾 保存")
        save_btn.clicked.connect(self._save)
        btn_layout.addWidget(save_btn)
        delete_btn = QPushButton("🗑 删除")
        delete_btn.setStyleSheet("QPushButton { color: red; }")
        delete_btn.clicked.connect(self._delete)
        btn_layout.addWidget(delete_btn)
        right_layout.addLayout(btn_layout)

        right.setLayout(right_layout)
        splitter.addWidget(right)
        splitter.setSizes([350, 450])

        layout.addWidget(splitter)

        # 底部按钮栏
        bottom = QHBoxLayout()
        add_btn = QPushButton("＋ 新建记忆")
        add_btn.setStyleSheet("QPushButton { background: #27AE60; color: white; padding: 8px; border-radius: 4px; }")
        add_btn.clicked.connect(self._add_memory)
        bottom.addWidget(add_btn)

        cat_btn = QPushButton("📁 管理分类")
        cat_btn.clicked.connect(self._manage_categories)
        bottom.addWidget(cat_btn)

        self._count_label = QLabel("")
        bottom.addStretch()
        bottom.addWidget(self._count_label)
        layout.addLayout(bottom)

    def _refresh(self):
        """刷新列表"""
        self._importance_spin.blockSignals(True)
        try:
            self._tree.clear()
            cat = self._cat_filter.currentText()
            if cat == "全部分类":
                cat = None

            star_text = self._star_filter.currentText()
            min_imp = 0
            if "3" in star_text:
                min_imp = 3
            if "4" in star_text:
                min_imp = 4
            if "5" in star_text:
                min_imp = 5

            memories = self.mm.list_memories(category=cat, min_importance=min_imp, limit=200)

            for mem in memories:
                item = QTreeWidgetItem([mem.title, mem.category, "⭐" * mem.importance])
                item.setData(0, Qt.ItemDataRole.UserRole, mem.id)
                self._tree.addTopLevelItem(item)

            self._count_label.setText(f"共 {len(memories)} 条记忆")
        finally:
            self._importance_spin.blockSignals(False)

    def _search(self):
        query = self._search_box.text().strip()
        if not query:
            self._refresh()
            return

        self._tree.clear()
        results = self.mm.search_hybrid(query, top_k=30)
        for r in results:
            m = r.memory
            stars = "⭐" * m.importance
            score_str = f"{r.score:.2f}"
            item = QTreeWidgetItem([m.title, m.category, f"{stars} ({score_str})"])
            item.setData(0, Qt.ItemDataRole.UserRole, m.id)
            self._tree.addTopLevelItem(item)

        self._count_label.setText(f"搜索 '{query}': {len(results)} 条结果")

    def _on_select(self, current, previous):
        if not current:
            return

        mem_id = current.data(0, Qt.ItemDataRole.UserRole)
        mem = self.mm.get_memory(mem_id)
        if not mem:
            return

        self._current_memory = mem
        self._title_edit.setText(mem.title)
        self._content_edit.setPlainText(mem.content)
        self._importance_spin.setValue(mem.importance)
        self._id_label.setText(f"ID: {mem.id[:12]}... | 使用: {mem.use_count}次 | 标签: {', '.join(mem.tags)}")

    def _on_importance_changed(self, value):
        """重要程度变更（延迟保存）"""
        if not self._current_memory:
            return
        self._current_memory.importance = value
        # 使用定时器延迟保存，避免频繁刷新
        if not hasattr(self, '_importance_timer'):
            from PyQt6.QtCore import QTimer
            self._importance_timer = QTimer()
            self._importance_timer.setSingleShot(True)
            self._importance_timer.timeout.connect(self._save_importance_delayed)
        self._importance_timer.start(800)  # 800ms 后保存

    def _save_importance_delayed(self):
        """延迟保存重要程度"""
        if self._current_memory:
            self.mm.set_importance(self._current_memory.id, self._current_memory.importance)

    def _save(self):
        if not self._current_memory:
            return
        self._current_memory.title = self._title_edit.text()
        self._current_memory.content = self._content_edit.toPlainText()
        self.mm.update_memory(self._current_memory)
        self._refresh()

    def _add_memory(self):
        from datetime import datetime
        mem = self.mm.add_memory(
            title="新记忆",
            content="在此输入内容...",
            category=self._cat_filter.currentText() if self._cat_filter.currentText() != "全部分类" else "其他",
            importance=3,
        )
        self._refresh()
        # 选中新添加的
        for i in range(self._tree.topLevelItemCount()):
            item = self._tree.topLevelItem(i)
            if item.data(0, Qt.ItemDataRole.UserRole) == mem.id:
                self._tree.setCurrentItem(item)
                break

    def _delete(self):
        if not self._current_memory:
            return
        reply = QMessageBox.question(self, "确认删除", f"确定删除记忆「{self._current_memory.title}」？")
        if reply == QMessageBox.StandardButton.Yes:
            self.mm.delete_memory(self._current_memory.id)
            self._current_memory = None
            self._title_edit.clear()
            self._content_edit.clear()
            self._refresh()

    def _manage_categories(self):
        cats = "\n".join(self.mm.categories)
        text, ok = QInputDialog.getMultiLineText(
            self, "管理分类", "每行一个分类名:", cats
        )
        if ok:
            # 简单处理：添加新分类
            for line in text.split("\n"):
                name = line.strip()
                if name and name not in self.mm.categories:
                    self.mm.add_category(name)
            self._refresh()
