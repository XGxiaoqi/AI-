"""
AI进化论 — 角色卡管理面板
支持角色卡的创建、编辑、删除、激活切换、导入导出
"""

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel,
    QTreeWidget, QTreeWidgetItem, QTextEdit, QSplitter,
    QCheckBox, QMessageBox, QLineEdit, QFormLayout, QGroupBox,
    QDialog, QDialogButtonBox, QFileDialog, QComboBox,
    QInputDialog, QScrollArea,
)
from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QFont

from core.character_card import CharacterCard, CharacterCardManager


class CardEditDialog(QDialog):
    """角色卡编辑对话框"""

    def __init__(self, card: CharacterCard | None = None, parent=None):
        super().__init__(parent)
        self.card = card or CharacterCard()
        self.setWindowTitle("编辑角色卡" if card else "新建角色卡")
        self.setMinimumSize(650, 550)
        self._init_ui()

    def _init_ui(self):
        layout = QVBoxLayout(self)

        # 基本信息
        info_group = QGroupBox("基本信息")
        info_form = QFormLayout()

        self._name_edit = QLineEdit(self.card.name)
        self._name_edit.setPlaceholderText("给角色起个名字...")
        info_form.addRow("角色名:", self._name_edit)

        self._avatar_edit = QLineEdit(self.card.avatar)
        self._avatar_edit.setPlaceholderText("输入一个 emoji 作为头像")
        self._avatar_edit.setMaxLength(4)
        info_form.addRow("头像:", self._avatar_edit)

        self._author_edit = QLineEdit(self.card.author)
        info_form.addRow("作者:", self._author_edit)

        self._tags_edit = QLineEdit(",".join(self.card.tags))
        self._tags_edit.setPlaceholderText("用逗号分隔，如：编程,开发,Python")
        info_form.addRow("标签:", self._tags_edit)

        self._desc_edit = QTextEdit()
        self._desc_edit.setPlainText(self.card.description)
        self._desc_edit.setMaximumHeight(60)
        self._desc_edit.setPlaceholderText("简要描述这个角色的定位和特长...")
        info_form.addRow("简介:", self._desc_edit)

        info_group.setLayout(info_form)
        layout.addWidget(info_group)

        # 核心系统提示词
        prompt_group = QGroupBox("核心系统提示词（最高优先级，无任何高于它的提示词）")
        prompt_layout = QVBoxLayout()

        prompt_hint = QLabel(
            "⚠️ 这里的内容将成为 AI 的核心人格定义，拥有最高优先级。\n"
            "它会完全替代默认系统提示词，而非追加。请谨慎编写。"
        )
        prompt_hint.setStyleSheet("color: #E74C3C; font-size: 12px; padding: 4px;")
        prompt_layout.addWidget(prompt_hint)

        self._prompt_edit = QTextEdit()
        self._prompt_edit.setPlainText(self.card.system_prompt)
        self._prompt_edit.setPlaceholderText(
            "编写角色的核心系统提示词...\n\n"
            "示例：\n"
            "你是一位资深的安全专家，专注于网络安全和渗透测试。\n\n"
            "## 你的能力\n"
            "- 代码审计和漏洞分析\n"
            "- ..."
        )
        self._prompt_edit.setStyleSheet(
            "QTextEdit { font-family: 'Consolas', 'Microsoft YaHei'; font-size: 13px; }"
        )
        prompt_layout.addWidget(self._prompt_edit)

        prompt_group.setLayout(prompt_layout)
        layout.addWidget(prompt_group)

        # 开场白
        greet_group = QGroupBox("开场白（激活角色卡后的首次问候）")
        greet_layout = QVBoxLayout()
        self._greeting_edit = QTextEdit()
        self._greeting_edit.setPlainText(self.card.greeting)
        self._greeting_edit.setMaximumHeight(60)
        self._greeting_edit.setPlaceholderText("角色激活后的第一句话...")
        greet_layout.addWidget(self._greeting_edit)
        greet_group.setLayout(greet_layout)
        layout.addWidget(greet_group)

        # 按钮
        btn_box = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        btn_box.accepted.connect(self._on_accept)
        btn_box.rejected.connect(self.reject)
        layout.addWidget(btn_box)

    def _on_accept(self):
        name = self._name_edit.text().strip()
        if not name:
            QMessageBox.warning(self, "提示", "角色名不能为空")
            return
        prompt = self._prompt_edit.toPlainText().strip()
        if not prompt:
            reply = QMessageBox.question(
                self, "确认",
                "系统提示词为空，这意味着 AI 将没有核心人格定义。\n确定要保存吗？",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            )
            if reply == QMessageBox.StandardButton.No:
                return

        self.card.name = name
        self.card.avatar = self._avatar_edit.text().strip() or "🤖"
        self.card.author = self._author_edit.text().strip()
        tags_text = self._tags_edit.text().strip()
        self.card.tags = [t.strip() for t in tags_text.split(",") if t.strip()] if tags_text else []
        self.card.description = self._desc_edit.toPlainText().strip()
        self.card.system_prompt = prompt
        self.card.greeting = self._greeting_edit.toPlainText().strip()
        self.accept()

    def get_card(self) -> CharacterCard:
        return self.card


class CharacterPanel(QWidget):
    """角色卡管理面板"""

    card_activated = pyqtSignal(str)   # card_id，角色卡激活时发射
    card_changed = pyqtSignal()        # 角色卡内容变更时发射

    def __init__(self, card_manager: CharacterCardManager, parent=None):
        super().__init__(parent)
        self.cm = card_manager
        self._init_ui()
        self._refresh()

    def _init_ui(self):
        layout = QVBoxLayout(self)

        # 标题栏
        header = QHBoxLayout()
        header.addWidget(QLabel("🎭 角色卡管理"))

        # 当前激活显示
        self._active_label = QLabel("")
        self._active_label.setStyleSheet(
            "color: #27AE60; font-weight: bold; font-size: 13px; padding: 2px 8px; "
            "background: #E8F8F5; border-radius: 4px;"
        )
        header.addWidget(self._active_label)
        header.addStretch()

        self._count_label = QLabel("")
        header.addWidget(self._count_label)
        layout.addLayout(header)

        # 说明
        hint = QLabel(
            "💡 角色卡是 AI 的核心系统提示词。激活的角色卡提示词拥有最高优先级，\n"
            "   无任何高于它的提示词 — 它完全定义了 AI 的人格和行为准则。"
        )
        hint.setStyleSheet("color: #666; font-size: 12px; padding: 4px 8px; background: #F8F9FA; border-radius: 4px;")
        layout.addWidget(hint)

        splitter = QSplitter(Qt.Orientation.Horizontal)

        # 左侧：角色卡列表
        left_panel = QWidget()
        left_layout = QVBoxLayout(left_panel)
        left_layout.setContentsMargins(0, 0, 0, 0)

        self._card_list = QTreeWidget()
        self._card_list.setHeaderLabels(["角色", "状态"])
        self._card_list.setColumnWidth(0, 200)
        self._card_list.setColumnWidth(1, 80)
        self._card_list.currentItemChanged.connect(self._on_select)
        self._card_list.setStyleSheet("""
            QTreeWidget { border: 1px solid #ddd; border-radius: 4px; }
            QTreeWidget::item:selected { background: #4A90D9; color: white; }
        """)
        left_layout.addWidget(self._card_list)

        # 左侧按钮
        left_btn_layout = QHBoxLayout()
        add_btn = QPushButton("➕ 新建")
        add_btn.setStyleSheet("QPushButton { background: #27AE60; color: white; padding: 5px; border-radius: 4px; }")
        add_btn.clicked.connect(self._add_card)
        left_btn_layout.addWidget(add_btn)

        import_btn = QPushButton("📥 导入")
        import_btn.setStyleSheet("QPushButton { background: #3498DB; color: white; padding: 5px; border-radius: 4px; }")
        import_btn.clicked.connect(self._import_card)
        left_btn_layout.addWidget(import_btn)
        left_layout.addLayout(left_btn_layout)

        splitter.addWidget(left_panel)

        # 右侧：角色卡详情
        right_panel = QWidget()
        right_layout = QVBoxLayout(right_panel)
        right_layout.setContentsMargins(4, 4, 4, 4)

        # 角色信息头
        self._card_header = QLabel("选择角色卡查看详情")
        self._card_header.setStyleSheet("font-size: 16px; font-weight: bold;")
        right_layout.addWidget(self._card_header)

        # 描述
        self._desc_edit = QTextEdit()
        self._desc_edit.setReadOnly(True)
        self._desc_edit.setMaximumHeight(50)
        self._desc_edit.setStyleSheet("QTextEdit { background: #F8F9FA; border: none; border-radius: 4px; padding: 6px; }")
        right_layout.addWidget(self._desc_edit)

        # 系统提示词预览
        prompt_label = QLabel("📜 核心系统提示词：")
        prompt_label.setStyleSheet("font-weight: bold; color: #E74C3C;")
        right_layout.addWidget(prompt_label)

        self._prompt_edit = QTextEdit()
        self._prompt_edit.setReadOnly(True)
        self._prompt_edit.setStyleSheet(
            "QTextEdit { font-family: 'Consolas', 'Microsoft YaHei'; font-size: 13px; "
            "background: #1E1E1E; color: #D4D4D4; border: 1px solid #333; border-radius: 4px; padding: 8px; }"
        )
        right_layout.addWidget(self._prompt_edit)

        # 开场白
        self._greeting_label = QLabel("")
        self._greeting_label.setStyleSheet("color: #888; font-style: italic; padding: 4px;")
        right_layout.addWidget(self._greeting_label)

        # 操作按钮
        btn_layout = QHBoxLayout()

        self._activate_btn = QPushButton("👑 激活此角色卡")
        self._activate_btn.setStyleSheet(
            "QPushButton { background: #E67E22; color: white; padding: 8px 16px; "
            "border-radius: 4px; font-weight: bold; }"
        )
        self._activate_btn.clicked.connect(self._activate_card)
        btn_layout.addWidget(self._activate_btn)

        edit_btn = QPushButton("✏️ 编辑")
        edit_btn.setStyleSheet("QPushButton { padding: 8px 12px; }")
        edit_btn.clicked.connect(self._edit_card)
        btn_layout.addWidget(edit_btn)

        export_btn = QPushButton("📤 导出")
        export_btn.setStyleSheet("QPushButton { padding: 8px 12px; }")
        export_btn.clicked.connect(self._export_card)
        btn_layout.addWidget(export_btn)

        self._delete_btn = QPushButton("🗑️ 删除")
        self._delete_btn.setStyleSheet("QPushButton { background: #E74C3C; color: white; padding: 8px 12px; border-radius: 4px; }")
        self._delete_btn.clicked.connect(self._delete_card)
        btn_layout.addWidget(self._delete_btn)

        btn_layout.addStretch()
        right_layout.addLayout(btn_layout)

        splitter.addWidget(right_panel)
        splitter.setSizes([280, 520])

        layout.addWidget(splitter)

    def _refresh(self):
        """刷新角色卡列表"""
        self._card_list.clear()
        cards = self.cm.list_cards()
        active_id = self.cm.get_active_card().id if self.cm.get_active_card() else ""

        for card in cards:
            status = "👑 激活" if card.is_active else ("✅ 启用" if card.enabled else "⛔ 禁用")
            item = QTreeWidgetItem([f"{card.avatar} {card.name}", status])
            item.setData(0, Qt.ItemDataRole.UserRole, card.id)

            if card.is_active:
                font = item.font(0)
                font.setBold(True)
                item.setFont(0, font)
                for col in range(2):
                    item.setForeground(col, Qt.GlobalColor.darkGreen)

            self._card_list.addTopLevelItem(item)

        # 更新计数和激活状态
        self._count_label.setText(f"共 {len(cards)} 个角色卡")
        active = self.cm.get_active_card()
        if active:
            self._active_label.setText(f"当前激活: {active.avatar} {active.name}")

    def _on_select(self, current, previous):
        """选中角色卡时显示详情"""
        if not current or not current.data(0, Qt.ItemDataRole.UserRole):
            self._card_header.setText("选择角色卡查看详情")
            self._desc_edit.clear()
            self._prompt_edit.clear()
            self._greeting_label.clear()
            return

        card_id = current.data(0, Qt.ItemDataRole.UserRole)
        card = self.cm.get_card(card_id)
        if not card:
            return

        self._card_header.setText(f"{card.avatar} {card.name}  v{card.version}")
        self._desc_edit.setPlainText(card.description or "无描述")
        self._prompt_edit.setPlainText(card.system_prompt or "（空）")
        self._greeting_label.setText(f'💬 开场白: "{card.greeting}"' if card.greeting else "无开场白")

        # 按钮状态
        is_preset = card_id.startswith("preset_")
        self._delete_btn.setEnabled(not is_preset)
        self._activate_btn.setEnabled(not card.is_active)

        if is_preset:
            self._delete_btn.setToolTip("预置角色卡不可删除")
        else:
            self._delete_btn.setToolTip("")

    def _add_card(self):
        """新建角色卡"""
        dialog = CardEditDialog(parent=self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            card = dialog.get_card()
            self.cm.add_card(card)
            self._refresh()
            self.card_changed.emit()

    def _edit_card(self):
        """编辑角色卡"""
        current = self._card_list.currentItem()
        if not current:
            return
        card_id = current.data(0, Qt.ItemDataRole.UserRole)
        card = self.cm.get_card(card_id)
        if not card:
            return

        dialog = CardEditDialog(card=card, parent=self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            updated_card = dialog.get_card()
            self.cm.update_card(updated_card)
            self._refresh()
            self.card_changed.emit()

    def _activate_card(self):
        """激活角色卡"""
        current = self._card_list.currentItem()
        if not current:
            return
        card_id = current.data(0, Qt.ItemDataRole.UserRole)
        card = self.cm.get_card(card_id)
        if not card:
            return

        reply = QMessageBox.question(
            self, "确认激活",
            f"确定要激活角色卡「{card.avatar} {card.name}」吗？\n\n"
            f"激活后，该角色卡的核心系统提示词将成为 AI 的最高优先级指令，\n"
            f"无任何高于它的提示词，将完全替代当前系统提示词。",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        )
        if reply == QMessageBox.StandardButton.Yes:
            if self.cm.activate(card_id):
                self._refresh()
                self.card_activated.emit(card_id)
                self.card_changed.emit()

                # 如果有开场白，提示用户
                if card.greeting:
                    QMessageBox.information(
                        self, f"{card.avatar} {card.name}",
                        card.greeting,
                    )

    def _delete_card(self):
        """删除角色卡"""
        current = self._card_list.currentItem()
        if not current:
            return
        card_id = current.data(0, Qt.ItemDataRole.UserRole)
        card = self.cm.get_card(card_id)
        if not card:
            return

        if card_id.startswith("preset_"):
            QMessageBox.warning(self, "提示", "预置角色卡不可删除")
            return

        reply = QMessageBox.question(
            self, "确认删除",
            f"确定要删除角色卡「{card.avatar} {card.name}」吗？\n此操作不可恢复。",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
        )
        if reply == QMessageBox.StandardButton.Yes:
            self.cm.delete_card(card_id)
            self._refresh()
            self.card_changed.emit()

    def _export_card(self):
        """导出角色卡"""
        current = self._card_list.currentItem()
        if not current:
            return
        card_id = current.data(0, Qt.ItemDataRole.UserRole)
        card = self.cm.get_card(card_id)
        if not card:
            return

        path, _ = QFileDialog.getSaveFileName(
            self, "导出角色卡",
            f"{card.name}.yaml",
            "YAML文件 (*.yaml *.yml)",
        )
        if path:
            if self.cm.export_card(card_id, path):
                QMessageBox.information(self, "导出成功", f"角色卡已导出到:\n{path}")
            else:
                QMessageBox.warning(self, "导出失败", "导出角色卡时出错")

    def _import_card(self):
        """导入角色卡"""
        path, _ = QFileDialog.getOpenFileName(
            self, "导入角色卡", "", "YAML文件 (*.yaml *.yml)"
        )
        if path:
            card = self.cm.import_card(path)
            if card:
                QMessageBox.information(
                    self, "导入成功",
                    f"角色卡「{card.avatar} {card.name}」已导入\n"
                    f"你可以在列表中找到并激活它。",
                )
                self._refresh()
                self.card_changed.emit()
            else:
                QMessageBox.warning(self, "导入失败", "角色卡导入失败，请检查文件格式")
