"""
AI进化论 — 主窗口
整合对话、记忆、技能、MCP 日志四大面板
"""

import sys
import threading

from PyQt6.QtWidgets import (
    QMainWindow, QTabWidget, QMenuBar, QMenu, QStatusBar,
    QMessageBox, QApplication, QSystemTrayIcon, QTextEdit,
)
from PyQt6.QtCore import Qt, QSize, pyqtSignal, QObject, QThread, pyqtSlot
from PyQt6.QtGui import QAction, QIcon

from loguru import logger

from gui.chat_panel import ChatPanel
from gui.memory_panel import MemoryPanel
from gui.skill_panel import SkillPanel
from gui.settings_dialog import SettingsDialog
from gui.tray_icon import TrayIcon
from gui.character_panel import CharacterPanel


class AgentSignals(QObject):
    """线程安全的信号桥接（后台线程 → 主线程 UI 更新）"""
    response_ready = pyqtSignal(str)  # 完整回复
    token_received = pyqtSignal(str)  # 流式 token
    tool_called = pyqtSignal(str, str)  # 工具名, 参数摘要
    thinking_status = pyqtSignal(str)  # 思考状态
    error_occurred = pyqtSignal(str)  # 错误信息
    agent_finished = pyqtSignal()  # Agent 完成


class AgentWorker(QThread):
    """Agent 后台工作线程"""
    def __init__(self, agent, message, session_id, stream=True):
        super().__init__()
        self.agent = agent
        self.message = message
        self.session_id = session_id
        self.stream = stream
        self.signals = AgentSignals()
        self._is_running = True

    def run(self):
        try:
            if self.stream:
                # 流式输出
                full_content = ""
                gen = self.agent.chat(self.message, session_id=self.session_id, stream=True)
                for event in gen:
                    if not self._is_running:
                        break
                    if event.get("type") == "token":
                        full_content += event["content"]
                        self.signals.token_received.emit(full_content)
                    elif event.get("type") == "tool_call":
                        tools = event.get("tools", [])
                        self.signals.thinking_status.emit(f"🔧 调用工具: {', '.join(tools)}")
                    elif event.get("type") == "done":
                        self.signals.response_ready.emit(event.get("content", full_content))
                    elif event.get("type") == "error":
                        self.signals.error_occurred.emit(event.get("content", "未知错误"))
            else:
                # 同步输出
                response = self.agent.chat(self.message, session_id=self.session_id, stream=False)
                self.signals.response_ready.emit(response)
        except Exception as e:
            logger.error(f"Agent 执行出错: {e}")
            self.signals.error_occurred.emit(str(e))
        finally:
            self.signals.agent_finished.emit()

    def stop(self):
        self._is_running = False


class MainWindow(QMainWindow):
    """AI进化论 主窗口"""

    def __init__(self, agent, mcp_server, config, card_manager=None):
        super().__init__()
        self.agent = agent
        self.mcp_server = mcp_server
        self.config = config
        self.card_manager = card_manager

        self._current_worker: AgentWorker | None = None

        self.setWindowTitle("AI进化论")
        self.setMinimumSize(1000, 650)
        self.resize(1100, 700)

        # 居中显示
        screen = QApplication.primaryScreen().geometry()
        self.move(
            (screen.width() - self.width()) // 2,
            (screen.height() - self.height()) // 2,
        )

        self._init_ui()
        self._init_tray()
        self._init_mcp()

        logger.info("主窗口初始化完成")

    def _init_ui(self):
        """初始化界面"""
        # 菜单栏
        menubar = self.menuBar()

        file_menu = menubar.addMenu("文件")
        settings_action = QAction("⚙️ 设置", self)
        settings_action.triggered.connect(self._open_settings)
        file_menu.addAction(settings_action)
        file_menu.addSeparator()

        export_action = QAction("📤 导出对话", self)
        export_action.triggered.connect(self._export_conversation)
        file_menu.addAction(export_action)
        file_menu.addSeparator()

        quit_action = QAction("退出", self)
        quit_action.triggered.connect(self._quit)
        file_menu.addAction(quit_action)

        view_menu = menubar.addMenu("视图")
        dark_action = QAction("🌙 深色主题", self)
        dark_action.setCheckable(True)
        dark_action.triggered.connect(self._toggle_dark_theme)
        view_menu.addAction(dark_action)

        help_menu = menubar.addMenu("帮助")
        about_action = QAction("关于", self)
        about_action.triggered.connect(self._show_about)
        help_menu.addAction(about_action)

        # 主标签页
        self._tabs = QTabWidget()
        self.setCentralWidget(self._tabs)

        # 对话面板
        self._chat_panel = ChatPanel()
        self._chat_panel.message_sent.connect(self._on_user_message)
        self._tabs.addTab(self._chat_panel, "💬 对话")

        # 记忆面板
        self._memory_panel = MemoryPanel(self.agent.memory)
        self._tabs.addTab(self._memory_panel, "🧠 记忆库")

        # 技能面板
        self._skill_panel = SkillPanel(self.agent.skills)
        self._tabs.addTab(self._skill_panel, "🔧 技能库")

        # 角色卡面板
        if self.card_manager:
            self._character_panel = CharacterPanel(self.card_manager)
            self._character_panel.card_activated.connect(self._on_card_activated)
            self._character_panel.card_changed.connect(self._on_card_changed)
            self._tabs.addTab(self._character_panel, "🎭 角色卡")
        else:
            self._character_panel = None

        # MCP 日志面板
        mcp_widget = QTextEdit()
        mcp_widget.setReadOnly(True)
        mcp_widget.setPlaceholderText("MCP 服务日志将在此显示...")
        self._mcp_log = mcp_widget
        self._tabs.addTab(mcp_widget, "🔌 MCP 日志")

        # 状态栏
        self._status = QStatusBar()
        self.setStatusBar(self._status)
        self._update_status()

    def _init_tray(self):
        """初始化系统托盘"""
        if not QSystemTrayIcon.isSystemTrayAvailable():
            return
        self._tray = TrayIcon(self)
        self._tray.show_window.connect(self._show_window)
        self._tray.quit_app.connect(self._quit)
        self._tray.show()

    def _init_mcp(self):
        """初始化 MCP 服务"""
        if self.config.get("mcp.auto_start", True):
            self.mcp_server.inject_dependencies(
                self.agent.skills, self.agent.memory,
            )
            self.mcp_server.start_in_thread()
            self._status.showMessage("MCP 服务已启动 → http://127.0.0.1:9527", 5000)

    def _on_user_message(self, text: str):
        """处理用户消息（线程安全）"""
        if self._current_worker and self._current_worker.isRunning():
            QMessageBox.information(self, "提示", "Agent 正在处理中，请等待完成")
            return

        self._status.showMessage("🤔 思考中...")

        # 创建后台工作线程
        self._current_worker = AgentWorker(
            self.agent, text, self._chat_panel.current_session, stream=True
        )
        # 连接信号到主线程的 UI 更新
        self._current_worker.signals.token_received.connect(self._on_token_received)
        self._current_worker.signals.response_ready.connect(self._on_response_ready)
        self._current_worker.signals.thinking_status.connect(self._on_thinking_status)
        self._current_worker.signals.error_occurred.connect(self._on_error)
        self._current_worker.signals.agent_finished.connect(self._on_agent_finished)
        self._current_worker.start()

    @pyqtSlot(str)
    def _on_token_received(self, content: str):
        """流式 token 更新（主线程）"""
        self._chat_panel.update_last_message(content)

    @pyqtSlot(str)
    def _on_response_ready(self, response: str):
        """完整回复就绪（主线程）"""
        self._chat_panel.update_last_message(response)

    @pyqtSlot(str)
    def _on_thinking_status(self, status: str):
        """思考状态更新（主线程）"""
        self._status.showMessage(status)

    @pyqtSlot(str)
    def _on_error(self, error: str):
        """错误处理（主线程）"""
        self._chat_panel.add_message("assistant", f"❌ 出错了：{error}")
        self._status.showMessage("❌ 执行失败")

    @pyqtSlot()
    def _on_agent_finished(self):
        """Agent 完成（主线程）"""
        self._status.showMessage("✅ 就绪")
        self._memory_panel._refresh()
        self._update_status()
        self._current_worker = None

    def _update_status(self):
        """更新状态栏"""
        try:
            status = self.agent.get_status()
            local = "✓" if status["llm"]["local"]["available"] else "✗"
            cloud = "✓" if status["llm"]["cloud"]["available"] else "✗"
            
            # 角色卡信息
            card_info = ""
            if self.card_manager:
                active_card = self.card_manager.get_active_card()
                if active_card:
                    card_info = f" | 角色: {active_card.avatar} {active_card.name}"
            
            self._status.showMessage(
                f"本地: {local} | 云端: {cloud} | "
                f"记忆: {status['memory']['total']}条 | "
                f"技能: {status['skills_enabled']}/{status['skills']}{card_info} | "
                f"MCP: :9527"
            )
        except Exception:
            self._status.showMessage("AI进化论")

    def _open_settings(self):
        dialog = SettingsDialog(self, self.agent)
        dialog.config_changed.connect(self._on_config_changed)
        dialog.exec()
        self._update_status()

    def _on_config_changed(self):
        """配置变更回调"""
        self._update_status()

    def _on_card_activated(self, card_id: str):
        """角色卡激活回调 — 更新对话面板显示和状态栏"""
        if self.card_manager:
            card = self.card_manager.get_active_card()
            if card:
                self._status.showMessage(f"🎭 角色卡已切换: {card.avatar} {card.name}", 5000)
                # 如果有开场白，添加到对话
                if card.greeting and self._chat_panel:
                    self._chat_panel.add_message("assistant", card.greeting)

    def _on_card_changed(self):
        """角色卡内容变更回调"""
        self._update_status()

    def _toggle_dark_theme(self, checked):
        """切换深色/浅色主题"""
        if checked:
            self.setStyleSheet("""
                QMainWindow { background: #1E1E1E; }
                QTabWidget::pane { border: 1px solid #444; background: #2D2D2D; }
                QTabBar::tab {
                    padding: 8px 16px;
                    margin-right: 2px;
                    background: #3C3C3C;
                    color: #CCC;
                    border-top-left-radius: 4px;
                    border-top-right-radius: 4px;
                }
                QTabBar::tab:selected { background: #2D2D2D; color: #FFF; border-bottom: 2px solid #4A90D9; }
                QTextEdit { background: #2D2D2D; color: #DDD; border: 1px solid #555; }
                QLineEdit { background: #2D2D2D; color: #DDD; border: 1px solid #555; }
                QTreeWidget { background: #2D2D2D; color: #DDD; border: 1px solid #555; }
                QLabel { color: #DDD; }
                QPushButton { padding: 6px 12px; border: 1px solid #555; border-radius: 4px; background: #3C3C3C; color: #DDD; }
                QPushButton:hover { background: #4A4A4A; }
                QMenuBar { background: #2D2D2D; color: #DDD; }
                QMenuBar::item:selected { background: #4A90D9; }
                QMenu { background: #2D2D2D; color: #DDD; }
                QMenu::item:selected { background: #4A90D9; }
                QStatusBar { background: #2D2D2D; color: #AAA; }
                QSpinBox, QComboBox { background: #2D2D2D; color: #DDD; border: 1px solid #555; }
                QGroupBox { color: #DDD; border: 1px solid #555; }
            """)
        else:
            self.setStyleSheet("")

    def _export_conversation(self):
        """导出对话"""
        from PyQt6.QtWidgets import QFileDialog
        path, _ = QFileDialog.getSaveFileName(
            self, "导出对话", "", "Markdown (*.md);;JSON (*.json)"
        )
        if not path:
            return

        messages = self._chat_panel.get_session_messages()
        if path.endswith(".json"):
            import json
            with open(path, "w", encoding="utf-8") as f:
                json.dump(messages, f, ensure_ascii=False, indent=2)
        else:
            with open(path, "w", encoding="utf-8") as f:
                for msg in messages:
                    role = "你" if msg["role"] == "user" else "AI"
                    f.write(f"### {role} ({msg.get('timestamp', '')})\n\n")
                    f.write(f"{msg['content']}\n\n---\n\n")

        self._status.showMessage(f"对话已导出: {path}", 3000)

    def _show_about(self):
        from core.config import VERSION
        QMessageBox.about(
            self, "关于 AI进化论",
            f"<h2>AI进化论 v{VERSION}</h2>"
            "<p>本地 AI Agent 框架，运行于 Windows</p>"
            "<p><b>核心模块：</b>记忆库 · 技能库 · MCP 服务</p>"
            "<p><b>LLM 后端：</b>Ollama 本地 + DeepSeek + 阿里百炼</p>"
            "<hr>"
            "<p>参考 OpenClaw/龙虾 架构设计</p>"
        )

    def _show_window(self):
        self.show()
        self.raise_()
        self.activateWindow()

    def _quit(self):
        if hasattr(self, '_tray'):
            self._tray.hide()
        # 停止后台线程
        if self._current_worker and self._current_worker.isRunning():
            self._current_worker.stop()
            self._current_worker.wait(3000)
        # 清理资源
        try:
            if hasattr(self, 'mcp_server') and self.mcp_server:
                self.mcp_server.stop()
        except Exception:
            pass
        try:
            from skills.builtin.browser import browser_close
            browser_close()
        except Exception:
            pass
        QApplication.quit()
