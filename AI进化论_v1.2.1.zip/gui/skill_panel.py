"""
AI进化论 — 技能管理面板
"""

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel,
    QTreeWidget, QTreeWidgetItem, QTextEdit, QSplitter,
    QCheckBox, QMessageBox,
)
from PyQt6.QtCore import Qt

from skills.manager import SkillManager


class SkillPanel(QWidget):
    """技能管理面板"""

    def __init__(self, skill_manager: SkillManager, parent=None):
        super().__init__(parent)
        self.sm = skill_manager
        self._init_ui()
        self._refresh()

    def _init_ui(self):
        layout = QVBoxLayout(self)

        # 标题栏
        header = QHBoxLayout()
        header.addWidget(QLabel("🔧 技能库管理"))
        header.addStretch()
        self._count_label = QLabel("")
        header.addWidget(self._count_label)
        layout.addLayout(header)

        splitter = QSplitter(Qt.Orientation.Horizontal)

        # 左侧技能列表
        self._tree = QTreeWidget()
        self._tree.setHeaderLabels(["名称", "分类", "状态"])
        self._tree.setColumnWidth(0, 180)
        self._tree.setColumnWidth(1, 100)
        self._tree.currentItemChanged.connect(self._on_select)
        splitter.addWidget(self._tree)

        # 右侧详情
        right = QWidget()
        right_layout = QVBoxLayout(right)
        right_layout.setContentsMargins(4, 4, 4, 4)

        self._name_label = QLabel("选择技能查看详情")
        self._name_label.setStyleSheet("font-size: 14px; font-weight: bold;")
        right_layout.addWidget(self._name_label)

        self._desc_edit = QTextEdit()
        self._desc_edit.setReadOnly(True)
        self._desc_edit.setMaximumHeight(100)
        right_layout.addWidget(self._desc_edit)

        # 参数说明
        self._params_label = QLabel("参数：")
        right_layout.addWidget(self._params_label)

        self._params_text = QTextEdit()
        self._params_text.setReadOnly(True)
        right_layout.addWidget(self._params_text)

        # 启用/禁用
        self._enabled_check = QCheckBox("启用此技能")
        self._enabled_check.toggled.connect(self._toggle_skill)
        right_layout.addWidget(self._enabled_check)

        right_layout.addStretch()

        import_btn = QPushButton("📥 导入技能 (YAML)")
        import_btn.clicked.connect(self._import_skill)
        right_layout.addWidget(import_btn)

        export_btn = QPushButton("📤 导出技能")
        export_btn.clicked.connect(self._export_skill)
        right_layout.addWidget(export_btn)

        splitter.addWidget(right)
        splitter.setSizes([350, 450])

        layout.addWidget(splitter)

    def _refresh(self):
        self._tree.clear()
        skills = self.sm.list_all()

        # 按分类分组
        categories: dict[str, list] = {}
        for s in skills:
            cat = s.category.value
            if cat not in categories:
                categories[cat] = []
            categories[cat].append(s)

        for cat_name, cat_skills in categories.items():
            cat_item = QTreeWidgetItem([cat_name, f"{len(cat_skills)}个", ""])
            cat_item.setFlags(cat_item.flags() & ~Qt.ItemFlag.ItemIsSelectable)
            for s in cat_skills:
                status = "✅ 启用" if s.enabled else "⛔ 禁用"
                item = QTreeWidgetItem([s.name, s.category.value, status])
                item.setData(0, Qt.ItemDataRole.UserRole, s.name)
                cat_item.addChild(item)
            self._tree.addTopLevelItem(cat_item)

        self._tree.expandAll()
        self._count_label.setText(f"共 {len(skills)} 个技能 | 启用 {len(self.sm.list_enabled())} 个")

    def _on_select(self, current, previous):
        if not current or not current.data(0, Qt.ItemDataRole.UserRole):
            self._name_label.setText("选择技能查看详情")
            self._desc_edit.clear()
            self._params_text.clear()
            return

        name = current.data(0, Qt.ItemDataRole.UserRole)
        skill = self.sm.get_skill(name)
        if not skill:
            return

        self._name_label.setText(f"{skill.name} v{skill.version}")
        self._desc_edit.setPlainText(skill.description)
        self._enabled_check.setChecked(skill.enabled)

        params_text = ""
        for p in skill.parameters:
            req = "（必填）" if p.required else "（可选）"
            params_text += f"  • {p.name} ({p.type}) {req}\n    {p.description}\n"
        self._params_text.setPlainText(params_text)

    def _toggle_skill(self, checked):
        current = self._tree.currentItem()
        if current:
            name = current.data(0, Qt.ItemDataRole.UserRole)
            if name:
                self.sm.set_enabled(name, checked)
                self._refresh()

    def _import_skill(self):
        from PyQt6.QtWidgets import QFileDialog
        path, _ = QFileDialog.getOpenFileName(
            self, "导入技能", "", "YAML文件 (*.yaml *.yml)"
        )
        if path:
            result = self.sm.import_skill(path)
            if "error" in result:
                QMessageBox.warning(self, "导入失败", result["error"])
            else:
                QMessageBox.information(self, "导入成功", f"技能 '{result['imported']}' 已导入")
                self._refresh()

    def _export_skill(self):
        current = self._tree.currentItem()
        if not current:
            return
        name = current.data(0, Qt.ItemDataRole.UserRole)
        if not name:
            return

        from PyQt6.QtWidgets import QFileDialog
        path = QFileDialog.getExistingDirectory(self, "选择导出目录")
        if path:
            result = self.sm.export_skill(name, path)
            if "error" in result:
                QMessageBox.warning(self, "导出失败", result["error"])
            else:
                QMessageBox.information(self, "导出成功", f"已导出到: {result['exported']}")
