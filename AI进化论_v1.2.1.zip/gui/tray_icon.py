"""
AI进化论 — 系统托盘图标
"""

from PyQt6.QtWidgets import QSystemTrayIcon, QMenu
from PyQt6.QtGui import QIcon, QAction
from PyQt6.QtCore import pyqtSignal


class TrayIcon(QSystemTrayIcon):
    """系统托盘"""

    show_window = pyqtSignal()
    quit_app = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)

        # 使用默认图标
        self.setIcon(parent.style().standardIcon(
            parent.style().StandardPixmap.SP_ComputerIcon
        ) if parent else QIcon())
        self.setToolTip("AI进化论")

        # 右键菜单
        menu = QMenu()
        show_action = QAction("显示主窗口")
        show_action.triggered.connect(self.show_window.emit)
        menu.addAction(show_action)

        menu.addSeparator()

        quit_action = QAction("退出")
        quit_action.triggered.connect(self.quit_app.emit)
        menu.addAction(quit_action)

        self.setContextMenu(menu)
        self.activated.connect(self._on_activated)

    def _on_activated(self, reason):
        if reason == QSystemTrayIcon.ActivationReason.DoubleClick:
            self.show_window.emit()
