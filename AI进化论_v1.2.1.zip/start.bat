@echo off
chcp 65001 >nul
title AI进化论

echo ==========================================
echo   AI进化论 v1.1.0
echo   本地 AI Agent 框架
echo ==========================================
echo.

:: 检查 Python 版本
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [错误] 未找到 Python，请先安装 Python 3.11+
    echo [下载] https://www.python.org/downloads/
    pause
    exit /b 1
)

:: 检查 Python 版本 >= 3.11
for /f "tokens=2 delims= " %%v in ('python --version 2^>^&1') do set PYVER=%%v
echo [信息] Python %PYVER%

:: 检查虚拟环境（可选）
if exist "venv\Scripts\activate.bat" (
    echo [信息] 激活虚拟环境...
    call venv\Scripts\activate.bat
) else (
    echo [提示] 建议创建虚拟环境: python -m venv venv
)

:: 安装依赖（检查 PyQt6 作为标志）
python -c "import PyQt6" >nul 2>&1
if %errorlevel% neq 0 (
    echo [信息] 首次运行，正在安装依赖...
    pip install -r requirements.txt
    if %errorlevel% neq 0 (
        echo [错误] 依赖安装失败
        pause
        exit /b 1
    )
    echo [信息] 依赖安装完成！
)

:: 检查 Ollama
echo [信息] 检查 Ollama 服务...
python -c "import httpx; httpx.Client(timeout=3).get('http://localhost:11434/api/tags')" >nul 2>&1
if %errorlevel% neq 0 (
    echo [警告] Ollama 未运行。本地模型不可用，将仅使用云端 API。
    echo [提示] 如需本地模型，请启动 Ollama: ollama serve
)

:: 创建数据目录
if not exist "data" mkdir data
if not exist "data\logs" mkdir data\logs
if not exist "data\sessions" mkdir data\sessions

echo.
echo [启动] AI进化论...
python main.py

if %errorlevel% neq 0 (
    echo.
    echo [错误] 程序异常退出，请查看日志: data\logs\
)

pause
