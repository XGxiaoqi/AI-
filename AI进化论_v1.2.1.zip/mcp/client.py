"""
AI进化论 — MCP 客户端
连接外部 MCP 服务器（如 Augment、Claude Desktop 的 MCP）
"""

import json
import httpx
from typing import Any
from loguru import logger


class MCPClient:
    """MCP 客户端 — 连接外部 MCP 服务"""

    def __init__(self, server_url: str):
        self.server_url = server_url.rstrip("/")
        self._tools: list[dict] | None = None
        self._initialized = False

    def connect(self) -> bool:
        """连接并初始化 MCP 服务"""
        try:
            resp = self._request("initialize", {
                "protocolVersion": "2024-11-05",
                "clientInfo": {"name": "AI进化论", "version": "1.0.0"},
            })
            if resp and "serverInfo" in resp:
                self._initialized = True
                logger.info(f"MCP 连接成功: {self.server_url} -> {resp['serverInfo']['name']}")
                return True
        except Exception as e:
            logger.error(f"MCP 连接失败: {e}")
        return False

    def list_tools(self) -> list[dict]:
        """列出远程工具"""
        if not self._initialized:
            if not self.connect():
                return []

        resp = self._request("tools/list")
        self._tools = resp.get("tools", []) if resp else []
        return self._tools

    def call_tool(self, name: str, arguments: dict) -> dict[str, Any]:
        """调用远程工具"""
        if not self._initialized:
            if not self.connect():
                return {"error": "MCP 未连接"}

        return self._request("tools/call", {"name": name, "arguments": arguments})

    def list_resources(self) -> list[dict]:
        """列出远程资源"""
        resp = self._request("resources/list")
        return resp.get("resources", []) if resp else []

    def read_resource(self, uri: str) -> dict:
        """读取远程资源"""
        return self._request("resources/read", {"uri": uri})

    def _request(self, method: str, params: dict | None = None) -> dict:
        """发送 JSON-RPC 请求"""
        payload = {
            "jsonrpc": "2.0",
            "id": 1,
            "method": method,
            "params": params or {},
        }
        try:
            with httpx.Client(timeout=30) as client:
                resp = client.post(
                    f"{self.server_url}/mcp",
                    json=payload,
                    headers={"Content-Type": "application/json"},
                )
                resp.raise_for_status()
                data = resp.json()
                if "error" in data:
                    logger.error(f"MCP 错误: {data['error']}")
                    return {}
                return data.get("result", {})
        except Exception as e:
            logger.error(f"MCP 请求失败 [{method}]: {e}")
            return {}
