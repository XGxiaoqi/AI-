"""
AI进化论 — MCP 标准协议服务端
基于 FastAPI 实现 MCP (Model Context Protocol) JSON-RPC 接口

MCP 协议参考: https://spec.modelcontextprotocol.io/
核心方法:
  - initialize: 初始化连接
  - tools/list: 列出可用工具
  - tools/call: 调用工具
  - resources/list: 列出资源（记忆库）
  - resources/read: 读取资源
"""

import json
from typing import Any

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from loguru import logger


class MCPServer:
    """MCP 服务端 — 实现标准 MCP JSON-RPC 协议"""

    def __init__(
        self,
        host: str = "127.0.0.1",
        port: int = 9527,
        auto_start: bool = True,
    ):
        self.host = host
        self.port = port
        self.auto_start = auto_start
        self.app = FastAPI(title="AI进化论 MCP Server", version="1.0.0")
        self._server_name = "AI进化论"
        self._server_version = "1.0.0"

        # 外部依赖（由 Agent Core 注入）
        self.skill_manager = None
        self.memory_manager = None

        # 注册路由
        self._setup_routes()

    def inject_dependencies(self, skill_manager, memory_manager):
        """注入技能管理器和记忆管理器"""
        self.skill_manager = skill_manager
        self.memory_manager = memory_manager

    def _setup_routes(self):
        """设置 MCP 路由"""

        @self.app.post("/mcp")
        async def mcp_endpoint(request: Request):
            """MCP JSON-RPC 统一入口"""
            try:
                body = await request.json()
            except Exception:
                return JSONResponse(
                    self._jsonrpc_error(None, -32700, "解析错误"),
                    status_code=400,
                )

            method = body.get("method", "")
            params = body.get("params", {})
            req_id = body.get("id")

            logger.debug(f"MCP 请求: {method}")

            if method == "initialize":
                result = self._handle_initialize(params)
            elif method == "tools/list":
                result = self._handle_tools_list()
            elif method == "tools/call":
                result = self._handle_tools_call(params)
            elif method == "resources/list":
                result = self._handle_resources_list()
            elif method == "resources/read":
                result = self._handle_resources_read(params)
            elif method == "ping":
                result = self._handle_ping()
            else:
                return JSONResponse(
                    self._jsonrpc_error(req_id, -32601, f"方法不存在: {method}"),
                )

            if "error" in result:
                return JSONResponse(result)
            return JSONResponse(self._jsonrpc_result(req_id, result))

        @self.app.get("/health")
        async def health():
            return {"status": "ok", "server": self._server_name}

    # ====== MCP 方法处理 ======

    def _handle_initialize(self, params: dict) -> dict:
        return {
            "protocolVersion": "2024-11-05",
            "serverInfo": {
                "name": self._server_name,
                "version": self._server_version,
            },
            "capabilities": {
                "tools": {},
                "resources": {},
            },
        }

    def _handle_ping(self) -> dict:
        return {"pong": True}

    def _handle_tools_list(self) -> dict:
        tools = []
        if self.skill_manager:
            for skill in self.skill_manager.list_enabled():
                schema = skill.to_tool_schema()
                tools.append({
                    "name": skill.name,
                    "description": skill.description,
                    "inputSchema": schema["function"]["parameters"],
                })

        # 添加记忆库工具
        tools.extend([
            {
                "name": "memory_search",
                "description": "搜索记忆库，支持语义和关键词混合检索",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "query": {"type": "string", "description": "搜索查询"},
                        "top_k": {"type": "integer", "description": "返回数量", "default": 5},
                        "category": {"type": "string", "description": "按分类筛选（可选）"},
                    },
                    "required": ["query"],
                },
            },
            {
                "name": "memory_add",
                "description": "添加一条新记忆",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "title": {"type": "string", "description": "记忆标题"},
                        "content": {"type": "string", "description": "记忆内容"},
                        "category": {"type": "string", "description": "分类", "default": "其他"},
                        "importance": {"type": "integer", "description": "重要程度 1-5", "default": 3},
                        "tags": {"type": "string", "description": "标签（逗号分隔）"},
                    },
                    "required": ["title", "content"],
                },
            },
            {
                "name": "memory_list",
                "description": "列出记忆库中的记忆",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "category": {"type": "string", "description": "按分类筛选"},
                        "min_importance": {"type": "integer", "description": "最低重要程度"},
                        "limit": {"type": "integer", "description": "返回数量", "default": 20},
                    },
                },
            },
        ])

        return {"tools": tools}

    def _handle_tools_call(self, params: dict) -> dict:
        tool_name = params.get("name", "")
        arguments = params.get("arguments", {})

        # 记忆库工具
        if tool_name == "memory_search" and self.memory_manager:
            results = self.memory_manager.search_hybrid(
                query=arguments.get("query", ""),
                top_k=arguments.get("top_k", 5),
                category=arguments.get("category"),
            )
            return {
                "content": [{
                    "type": "text",
                    "text": json.dumps([{
                        "title": r.memory.title,
                        "content": r.memory.content[:500],
                        "category": r.memory.category,
                        "importance": r.memory.importance,
                        "score": r.score,
                    } for r in results], ensure_ascii=False),
                }]
            }

        if tool_name == "memory_add" and self.memory_manager:
            tags = arguments.get("tags", "").split(",") if arguments.get("tags") else []
            mem = self.memory_manager.add_memory(
                title=arguments.get("title", ""),
                content=arguments.get("content", ""),
                category=arguments.get("category", "其他"),
                importance=arguments.get("importance", 3),
                tags=tags,
            )
            return {
                "content": [{
                    "type": "text",
                    "text": json.dumps({"id": mem.id, "title": mem.title, "status": "created"}, ensure_ascii=False),
                }]
            }

        if tool_name == "memory_list" and self.memory_manager:
            memories = self.memory_manager.list_memories(
                category=arguments.get("category"),
                min_importance=arguments.get("min_importance", 0),
                limit=arguments.get("limit", 20),
            )
            return {
                "content": [{
                    "type": "text",
                    "text": json.dumps([{
                        "id": m.id,
                        "title": m.title,
                        "category": m.category,
                        "importance": m.importance,
                        "snippet": m.snippet(100),
                    } for m in memories], ensure_ascii=False),
                }]
            }

        # 技能库工具
        if self.skill_manager:
            result = self.skill_manager.execute(tool_name, arguments)
            return {
                "content": [{
                    "type": "text",
                    "text": json.dumps(result, ensure_ascii=False, default=str),
                }]
            }

        return {
            "content": [{
                "type": "text",
                "text": json.dumps({"error": f"未知工具: {tool_name}"}),
            }]
        }

    def _handle_resources_list(self) -> dict:
        resources = []
        if self.memory_manager:
            resources.append({
                "uri": "memory://all",
                "name": "记忆库",
                "description": f"共 {self.memory_manager.total_count} 条记忆",
                "mimeType": "application/json",
            })
            for cat, count in self.memory_manager.count_by_category().items():
                if count > 0:
                    resources.append({
                        "uri": f"memory://category/{cat}",
                        "name": f"分类: {cat}",
                        "description": f"{count} 条记忆",
                    })
        return {"resources": resources}

    def _handle_resources_read(self, params: dict) -> dict:
        uri = params.get("uri", "")
        if uri == "memory://all" and self.memory_manager:
            memories = self.memory_manager.list_memories(limit=100)
            return {
                "contents": [{
                    "uri": uri,
                    "mimeType": "application/json",
                    "text": json.dumps([{
                        "id": m.id, "title": m.title, "category": m.category,
                        "importance": m.importance, "snippet": m.snippet(200),
                    } for m in memories], ensure_ascii=False),
                }]
            }
        return {"contents": []}

    # ====== JSON-RPC 格式 ======

    def _jsonrpc_result(self, req_id, result: dict) -> dict:
        return {"jsonrpc": "2.0", "id": req_id, "result": result}

    def _jsonrpc_error(self, req_id, code: int, message: str) -> dict:
        return {
            "jsonrpc": "2.0",
            "id": req_id,
            "error": {"code": code, "message": message},
        }

    # ====== 启动/停止 ======

    def start(self):
        """启动 MCP 服务"""
        import uvicorn
        logger.info(f"MCP 服务启动: http://{self.host}:{self.port}")
        logger.info(f"  MCP 端点: http://{self.host}:{self.port}/mcp")
        uvicorn.run(self.app, host=self.host, port=self.port, log_level="warning")

    def start_in_thread(self):
        """在后台线程启动"""
        import threading
        import uvicorn

        # 保存 uvicorn server 引用以便停止
        self._uvicorn_server = None
        self._should_exit = False

        def run():
            config = uvicorn.Config(
                self.app,
                host=self.host,
                port=self.port,
                log_level="warning",
            )
            self._uvicorn_server = uvicorn.Server(config)
            self._uvicorn_server.run()

        thread = threading.Thread(target=run, daemon=True, name="MCP-Server")
        thread.start()
        logger.info(f"MCP 服务已后台启动: http://{self.host}:{self.port}")
        return thread

    def stop(self):
        """停止 MCP 服务"""
        if hasattr(self, '_uvicorn_server') and self._uvicorn_server:
            self._uvicorn_server.should_exit = True
            logger.info("MCP 服务已停止")
