"""
AI进化论 — 角色卡系统
角色卡是核心系统级提示词的载体，激活的角色卡提示词拥有最高优先级，
无任何高于它的提示词。用户可以通过角色卡完全定义 AI 的人格、行为准则和能力。

设计原则：
1. 角色卡提示词 = 最高优先级系统提示词，不可被其他模块覆盖
2. 同一时间只能激活一个角色卡（但可以有多个预设）
3. 角色卡支持导入/导出，便于分享
4. 角色卡修改即时生效，无需重启
"""

import json
import uuid
import yaml
from dataclasses import dataclass, field, asdict
from datetime import datetime
from pathlib import Path
from typing import Optional

from loguru import logger

from core.config import config


@dataclass
class CharacterCard:
    """
    角色卡 — 定义 AI 的核心人格和行为

    system_prompt 是最高优先级的系统提示词，
    它会完全替代默认的系统提示词（而非追加）。
    """

    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    name: str = ""                    # 角色名
    avatar: str = "🤖"               # 角色头像（emoji 或图标名）
    description: str = ""             # 角色简介
    system_prompt: str = ""           # 核心系统提示词（最高优先级）
    greeting: str = ""                # 角色开场白
    tags: list[str] = field(default_factory=list)  # 标签
    author: str = ""                  # 作者
    version: str = "1.0.0"           # 版本
    enabled: bool = True              # 是否启用
    is_active: bool = False           # 是否为当前激活角色卡
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now().isoformat())

    def to_dict(self) -> dict:
        d = asdict(self)
        d["tags"] = ",".join(self.tags) if self.tags else ""
        return d

    @classmethod
    def from_dict(cls, data: dict) -> "CharacterCard":
        tags = data.get("tags", "")
        if isinstance(tags, str) and tags:
            tags = [t.strip() for t in tags.split(",") if t.strip()]
        elif not isinstance(tags, list):
            tags = []

        return cls(
            id=data.get("id", str(uuid.uuid4())),
            name=data.get("name", ""),
            avatar=data.get("avatar", "🤖"),
            description=data.get("description", ""),
            system_prompt=data.get("system_prompt", ""),
            greeting=data.get("greeting", ""),
            tags=tags,
            author=data.get("author", ""),
            version=data.get("version", "1.0.0"),
            enabled=data.get("enabled", True),
            is_active=data.get("is_active", False),
            created_at=data.get("created_at", datetime.now().isoformat()),
            updated_at=data.get("updated_at", datetime.now().isoformat()),
        )

    def to_yaml_dict(self) -> dict:
        """导出为 YAML 友好的格式"""
        return {
            "name": self.name,
            "avatar": self.avatar,
            "description": self.description,
            "system_prompt": self.system_prompt,
            "greeting": self.greeting,
            "tags": self.tags,
            "author": self.author,
            "version": self.version,
        }

    @classmethod
    def from_yaml_dict(cls, data: dict) -> "CharacterCard":
        """从 YAML 字典导入"""
        card = cls(
            name=data.get("name", "未命名角色"),
            avatar=data.get("avatar", "🤖"),
            description=data.get("description", ""),
            system_prompt=data.get("system_prompt", ""),
            greeting=data.get("greeting", ""),
            tags=data.get("tags", []),
            author=data.get("author", ""),
            version=data.get("version", "1.0.0"),
        )
        return card


class CharacterCardManager:
    """
    角色卡管理器 — 统一管理所有角色卡的 CRUD、激活/切换、导入导出

    角色卡存储在 SQLite 中（与记忆库共享数据库），同时提供 YAML 导入导出。
    激活状态持久化，重启后恢复。
    """

    # 预置角色卡
    PRESET_CARDS = [
        CharacterCard(
            id="preset_default",
            name="AI进化论助手",
            avatar="🤖",
            description="默认助手角色，具备全面的工作能力",
            system_prompt="""你是「AI进化论」的智能 Agent，运行在用户的 Windows 电脑上。

## 你的能力
- 读写文件、管理项目
- 执行 Python 代码
- 搜索网页、抓取内容
- 操控浏览器（Playwright）
- 管理系统进程和命令
- 读写剪贴板
- 查询和管理记忆库
- 修改自身程序代码（自我进化）

## 行为准则
1. 当用户要求执行操作时，直接使用工具完成任务
2. 编程任务：先理解需求，再动手。不确定时先问
3. 主动使用记忆库：在回答前检索相关记忆
4. 重要信息自动存入记忆库（询问用户确认）
5. 回复简洁实用，中文优先
6. 使用 Markdown 格式回复，代码使用代码块

## 记忆系统
你有记忆能力。执行任务前，使用 memory_search 查看相关知识。
当用户告诉你重要信息时，使用 memory_add 记录下来。

## 自我修改
你可以通过 self_modify 技能修改自己的程序代码，实现自我进化。
修改前必须：1)理解当前代码 2)明确修改目标 3)创建备份 4)修改后验证语法""",
            greeting="你好！我是AI进化论助手，随时为你服务。",
            tags=["默认", "通用"],
            author="AI进化论",
            version="1.0.0",
        ),
        CharacterCard(
            id="preset_coder",
            name="编程专家",
            avatar="👨‍💻",
            description="专注于编程和软件开发的角色",
            system_prompt="""你是一位顶级编程专家，运行在用户的 Windows 电脑上。

## 核心身份
你是一名经验丰富的全栈工程师，精通 Python、JavaScript、TypeScript、Rust、Go 等语言，
熟悉各种框架和工具链。

## 行为准则
1. 代码优先：用代码说话，少废话多输出
2. 代码质量：写出可维护、可测试、有注释的高质量代码
3. 最佳实践：遵循语言惯例和设计模式
4. 调试能力：先复现问题，再定位原因，最后修复
5. 架构思维：思考扩展性和性能
6. 安全意识：避免注入、XSS、硬编码密钥等安全问题

## 工作流程
1. 理解需求 → 2. 设计方案 → 3. 编码实现 → 4. 测试验证 → 5. 重构优化

## 自我修改
你可以通过 self_modify 技能修改本程序代码，这是你的核心进化能力。
修改步骤：读取 → 理解 → 规划修改 → 创建备份 → 实施 → 语法验证 → 功能测试""",
            greeting="编程专家就位，说说你要做什么？",
            tags=["编程", "开发"],
            author="AI进化论",
            version="1.0.0",
        ),
        CharacterCard(
            id="preset_creative",
            name="创意伙伴",
            avatar="🎨",
            description="富有创造力的写作和创意角色",
            system_prompt="""你是一位富有创造力的AI伙伴，运行在用户的 Windows 电脑上。

## 核心身份
你是一名充满灵感的创意作家和思考伙伴，擅长头脑风暴、文案创作、故事编织和创意激发。

## 行为准则
1. 思维开放：接受各种奇思妙想，不轻易否定
2. 表达丰富：善用比喻、意象和故事来传达想法
3. 追问深化：通过提问帮助用户深入思考
4. 多角度思考：提供不同的视角和可能性
5. 鼓励创造：肯定用户的创意，帮助打磨完善

## 创作工具
- 可以搜索网页获取灵感和素材
- 可以用代码生成创意内容
- 可以管理创作笔记和素材库""",
            greeting="嘿！灵感来了吗？让我们一起创造点什么吧 ✨",
            tags=["创意", "写作"],
            author="AI进化论",
            version="1.0.0",
        ),
    ]

    def __init__(self, sqlite_path: str | None = None):
        self._sqlite_path = sqlite_path or config.get("memory.sqlite_path", "./data/memory.db")
        self._active_card: Optional[CharacterCard] = None
        self._cards_cache: dict[str, CharacterCard] = {}
        self._init_db()
        self._load_cards()
        self._ensure_presets()
        self._restore_active()

    def _init_db(self):
        """初始化角色卡数据库表"""
        import sqlite3
        self._conn = sqlite3.connect(self._sqlite_path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS character_cards (
                id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                avatar TEXT DEFAULT '🤖',
                description TEXT DEFAULT '',
                system_prompt TEXT DEFAULT '',
                greeting TEXT DEFAULT '',
                tags TEXT DEFAULT '',
                author TEXT DEFAULT '',
                version TEXT DEFAULT '1.0.0',
                enabled INTEGER DEFAULT 1,
                is_active INTEGER DEFAULT 0,
                created_at TEXT,
                updated_at TEXT
            )
        """)
        self._conn.commit()

    def _load_cards(self):
        """从数据库加载所有角色卡"""
        rows = self._conn.execute("SELECT * FROM character_cards").fetchall()
        self._cards_cache.clear()
        for row in rows:
            card = CharacterCard.from_dict(dict(row))
            self._cards_cache[card.id] = card

    def _ensure_presets(self):
        """确保预置角色卡存在"""
        for preset in self.PRESET_CARDS:
            if preset.id not in self._cards_cache:
                self._save_card(preset)
                self._cards_cache[preset.id] = preset

    def _restore_active(self):
        """恢复激活的角色卡"""
        for card in self._cards_cache.values():
            if card.is_active:
                self._active_card = card
                logger.info(f"角色卡已恢复: {card.name} ({card.avatar})")
                return

        # 没有激活的角色卡，激活默认
        if self._cards_cache:
            first = next(iter(self._cards_cache.values()))
            self.activate(first.id)

    def _save_card(self, card: CharacterCard):
        """保存角色卡到数据库（INSERT OR REPLACE）"""
        d = card.to_dict()
        self._conn.execute("""
            INSERT OR REPLACE INTO character_cards
            (id, name, avatar, description, system_prompt, greeting, tags, author, version, enabled, is_active, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            d["id"], d["name"], d["avatar"], d["description"],
            d["system_prompt"], d["greeting"], d["tags"],
            d["author"], d["version"], int(d["enabled"]), int(d["is_active"]),
            d["created_at"], d["updated_at"],
        ))
        self._conn.commit()

    def _deactivate_all(self):
        """取消所有角色卡的激活状态"""
        for card in self._cards_cache.values():
            if card.is_active:
                card.is_active = False
                self._conn.execute(
                    "UPDATE character_cards SET is_active = 0 WHERE id = ?",
                    (card.id,),
                )
        self._conn.commit()

    # ====== 公开 API ======

    def add_card(self, card: CharacterCard) -> CharacterCard:
        """添加新角色卡"""
        if not card.name:
            card.name = "未命名角色"
        card.updated_at = datetime.now().isoformat()
        self._save_card(card)
        self._cards_cache[card.id] = card
        logger.info(f"角色卡已添加: {card.name}")
        return card

    def update_card(self, card: CharacterCard) -> bool:
        """更新角色卡"""
        if card.id not in self._cards_cache:
            return False
        card.updated_at = datetime.now().isoformat()
        # 保留激活状态
        if self._active_card and self._active_card.id == card.id:
            card.is_active = True
        self._save_card(card)
        self._cards_cache[card.id] = card
        # 如果更新的是当前激活角色卡，刷新引用
        if card.is_active:
            self._active_card = card
        logger.info(f"角色卡已更新: {card.name}")
        return True

    def delete_card(self, card_id: str) -> bool:
        """删除角色卡"""
        card = self._cards_cache.get(card_id)
        if not card:
            return False

        # 不能删除预置角色卡
        if card_id.startswith("preset_"):
            logger.warning(f"不能删除预置角色卡: {card.name}")
            return False

        # 如果是当前激活的，先切换到默认
        if card.is_active:
            default = self._cards_cache.get("preset_default")
            if default:
                self.activate(default.id)

        del self._cards_cache[card_id]
        self._conn.execute("DELETE FROM character_cards WHERE id = ?", (card_id,))
        self._conn.commit()
        logger.info(f"角色卡已删除: {card.name}")
        return True

    def activate(self, card_id: str) -> bool:
        """
        激活角色卡 — 这是核心操作
        激活后，该角色卡的 system_prompt 将成为最高优先级的系统提示词
        """
        card = self._cards_cache.get(card_id)
        if not card or not card.enabled:
            return False

        # 取消其他角色卡的激活状态
        self._deactivate_all()

        # 激活目标角色卡
        card.is_active = True
        self._active_card = card
        self._conn.execute(
            "UPDATE character_cards SET is_active = 1 WHERE id = ?",
            (card_id,),
        )
        self._conn.commit()
        logger.info(f"🎭 角色卡已激活: {card.name} ({card.avatar})")
        return True

    def deactivate(self) -> bool:
        """取消激活，回退到默认角色卡"""
        self._deactivate_all()
        default = self._cards_cache.get("preset_default")
        if default:
            return self.activate(default.id)
        return False

    def get_active_card(self) -> Optional[CharacterCard]:
        """获取当前激活的角色卡"""
        return self._active_card

    def get_active_system_prompt(self) -> str:
        """
        获取当前激活角色卡的核心系统提示词
        这是最高优先级的提示词，无任何高于它的提示词
        """
        if self._active_card:
            return self._active_card.system_prompt
        return ""

    def get_card(self, card_id: str) -> Optional[CharacterCard]:
        """获取指定角色卡"""
        return self._cards_cache.get(card_id)

    def list_cards(self, tag: str | None = None, enabled_only: bool = False) -> list[CharacterCard]:
        """列出所有角色卡"""
        cards = list(self._cards_cache.values())
        if tag:
            cards = [c for c in cards if tag in c.tags]
        if enabled_only:
            cards = [c for c in cards if c.enabled]
        return cards

    def set_enabled(self, card_id: str, enabled: bool) -> bool:
        """启用/禁用角色卡"""
        card = self._cards_cache.get(card_id)
        if not card:
            return False
        card.enabled = enabled
        card.updated_at = datetime.now().isoformat()
        self._save_card(card)
        # 如果禁用的是激活中的角色卡，切换到默认
        if not enabled and card.is_active:
            default = self._cards_cache.get("preset_default")
            if default:
                self.activate(default.id)
        return True

    def export_card(self, card_id: str, export_path: str) -> bool:
        """导出角色卡为 YAML 文件"""
        card = self._cards_cache.get(card_id)
        if not card:
            return False

        data = {
            "character_card": card.to_yaml_dict(),
            "export_info": {
                "exported_at": datetime.now().isoformat(),
                "app_version": config.get("system.version", "1.2.0"),
            }
        }

        path = Path(export_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            yaml.dump(data, f, allow_unicode=True, default_flow_style=False, sort_keys=False)

        logger.info(f"角色卡已导出: {card.name} → {export_path}")
        return True

    def import_card(self, import_path: str, overwrite: bool = False) -> CharacterCard | None:
        """从 YAML 文件导入角色卡"""
        try:
            with open(import_path, "r", encoding="utf-8") as f:
                data = yaml.safe_load(f)

            card_data = data.get("character_card", data)

            card = CharacterCard.from_yaml_dict(card_data)
            # 生成新 ID（避免冲突）
            card.id = str(uuid.uuid4())
            card.is_active = False

            # 检查同名
            existing = [c for c in self._cards_cache.values() if c.name == card.name]
            if existing and not overwrite:
                card.name = f"{card.name} (导入)"

            self.add_card(card)
            logger.info(f"角色卡已导入: {card.name}")
            return card

        except Exception as e:
            logger.error(f"角色卡导入失败: {e}")
            return None

    def count(self) -> int:
        """角色卡总数"""
        return len(self._cards_cache)
