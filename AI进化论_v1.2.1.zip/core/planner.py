"""
AI进化论 — 任务规划器
使用 LLM 将用户任务智能拆解为可执行的步骤
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any
from loguru import logger


class StepStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    DONE = "done"
    FAILED = "failed"


@dataclass
class PlanStep:
    """计划中的单步骤"""
    id: int
    title: str
    description: str = ""
    tool_name: str = ""
    tool_args: dict = field(default_factory=dict)
    status: StepStatus = StepStatus.PENDING
    result: Any = None
    error: str = ""


@dataclass
class TaskPlan:
    """任务计划"""
    task_id: str
    goal: str
    steps: list[PlanStep] = field(default_factory=list)
    current_step: int = 0

    @property
    def is_complete(self) -> bool:
        return all(s.status == StepStatus.DONE for s in self.steps)

    @property
    def has_failed(self) -> bool:
        return any(s.status == StepStatus.FAILED for s in self.steps)

    def get_current_step(self) -> PlanStep | None:
        if 0 <= self.current_step < len(self.steps):
            return self.steps[self.current_step]
        return None

    def advance(self):
        """完成当前步骤并前进"""
        current = self.get_current_step()
        if current and current.status == StepStatus.RUNNING:
            current.status = StepStatus.DONE
        self.current_step += 1

    def mark_failed(self, error: str = ""):
        current = self.get_current_step()
        if current:
            current.status = StepStatus.FAILED
            current.error = error

    def progress(self) -> str:
        done = sum(1 for s in self.steps if s.status == StepStatus.DONE)
        return f"{done}/{len(self.steps)}"

    def summary(self) -> str:
        """生成计划摘要"""
        lines = [f"📋 任务: {self.goal}", f"进度: {self.progress()}"]
        for s in self.steps:
            icon = {"pending": "⬜", "running": "🔄", "done": "✅", "failed": "❌"}.get(s.status.value, "⬜")
            lines.append(f"  {icon} Step {s.id}: {s.title}")
            if s.error:
                lines.append(f"     错误: {s.error}")
        return "\n".join(lines)


class Planner:
    """
    智能任务规划器
    - 简单任务：直接执行（不拆分）
    - 复杂任务：使用 LLM 拆解为步骤序列
    """

    # 无需拆分的简单意图关键词
    SIMPLE_INTENTS = {
        "你好", "hello", "hi", "谢谢", "thanks", "帮助", "help",
        "状态", "status", "什么", "什么是", "解释", "说明",
    }

    def should_plan(self, user_message: str) -> bool:
        """判断是否需要规划（任务是否复杂到需要拆分）"""
        msg = user_message.strip().lower()
        # 极短消息不需要规划
        if len(msg) < 10:
            return False
        # 简单问候/提问不需要规划
        for intent in self.SIMPLE_INTENTS:
            if intent in msg:
                return False
        # 包含多步骤关键词时需要规划
        multi_step_keywords = ["然后", "接着", "之后", "同时", "分别", "批量", "所有", "多个", "一步步", "步骤"]
        for kw in multi_step_keywords:
            if kw in msg:
                return True
        # 长消息（>100字）倾向于需要规划
        return len(msg) > 100

    def plan_with_llm(self, task_id: str, goal: str, llm_router, available_tools: list[str]) -> TaskPlan | None:
        """使用 LLM 生成任务计划"""
        prompt = f"""请将以下任务拆解为可执行的步骤序列。

任务目标: {goal}

可用工具: {', '.join(available_tools)}

请以 JSON 格式输出步骤列表，每个步骤包含:
- title: 步骤标题
- description: 步骤描述
- tool_name: 需要使用的工具名（如果不需要工具则为空字符串）
- tool_args: 工具参数（如果不需要则为空对象）

只输出 JSON 数组，不要其他内容。示例:
[
  {{"title": "搜索信息", "description": "搜索相关资料", "tool_name": "web_search", "tool_args": {{"query": "..."}}}},
  {{"title": "总结结果", "description": "整理搜索结果", "tool_name": "", "tool_args": {{}}}}
]"""

        try:
            import json
            response = llm_router.route(
                messages=[
                    {"role": "system", "content": "你是任务规划助手，只输出 JSON。"},
                    {"role": "user", "content": prompt},
                ],
                stream=False,
            )
            content = response.get("content", "")
            # 尝试提取 JSON
            start = content.find("[")
            end = content.rfind("]") + 1
            if start >= 0 and end > start:
                steps_data = json.loads(content[start:end])
                steps = []
                for i, s in enumerate(steps_data):
                    steps.append(PlanStep(
                        id=i + 1,
                        title=s.get("title", f"步骤{i+1}"),
                        description=s.get("description", ""),
                        tool_name=s.get("tool_name", ""),
                        tool_args=s.get("tool_args", {}),
                    ))
                return TaskPlan(task_id=task_id, goal=goal, steps=steps)
        except Exception as e:
            logger.warning(f"LLM 规划失败，回退到直接执行: {e}")

        return None

    def plan(self, task_id: str, goal: str, task_type: str = "general") -> TaskPlan:
        """根据任务类型生成默认计划（fallback）"""
        steps = []

        if task_type == "code_review":
            steps = [
                PlanStep(1, "读取代码", "读取目标文件", tool_name="file_read"),
                PlanStep(2, "分析代码", "检查代码质量、安全性、性能"),
                PlanStep(3, "生成报告", "输出审查结果和改进建议"),
            ]
        elif task_type == "file_process":
            steps = [
                PlanStep(1, "定位文件", "搜索或列出目标文件", tool_name="file_list"),
                PlanStep(2, "处理文件", "读写或转换文件", tool_name="file_read"),
                PlanStep(3, "验证结果", "检查处理后文件是否正确"),
            ]
        elif task_type == "research":
            steps = [
                PlanStep(1, "搜索信息", "网络搜索关键词", tool_name="web_search"),
                PlanStep(2, "深入阅读", "抓取关键网页内容", tool_name="web_fetch"),
                PlanStep(3, "整理总结", "汇总形成结构化答案"),
            ]
        else:
            steps = [PlanStep(1, "执行任务", goal)]

        return TaskPlan(task_id=task_id, goal=goal, steps=steps)
