"""
AI进化论 — Agent 核心引擎
实现完整的 Agent 主循环：感知 → 检索记忆 → 规划 → 执行工具 → 生成回复
"""

import json
import uuid
from typing import Any, Callable, Generator

from loguru import logger

from llm.router import LLMRouter
from memory.manager import MemoryManager
from skills.manager import SkillManager
from core.context_manager import ContextManager
from core.tool_executor import ToolExecutor
from core.planner import Planner
from core.config import config


class Agent:
    """
    AI进化论 Agent 核心引擎

    执行流程:
    1. 接收用户消息
    2. 检索相关记忆
    3. 任务规划（可选，复杂任务时启用）
    4. 构建上下文（含系统提示 + 记忆 + 工具定义 + 对话历史）
    5. 发送给 LLM
    6. 如果有 tool_calls → 执行 → 结果回填 → 重复步骤 5
    7. 生成最终回复
    """

    def __init__(
        self,
        llm_router: LLMRouter,
        memory_manager: MemoryManager,
        skill_manager: SkillManager,
        context_manager: ContextManager,
    ):
        self.llm = llm_router
        self.memory = memory_manager
        self.skills = skill_manager
        self.context = context_manager
        self.executor = ToolExecutor(skill_manager, memory_manager)
        self.planner = Planner()

        self.max_tool_rounds = config.get("system.max_tool_rounds", 8)

        # 回调
        self.on_token: Callable[[str], None] | None = None
        self.on_tool_call: Callable[[str, dict], None] | None = None
        self.on_thinking: Callable[[str], None] | None = None

    def chat(
        self,
        user_message: str,
        session_id: str | None = None,
        stream: bool = False,
    ) -> str | Generator:
        """
        用户对话入口

        Args:
            user_message: 用户消息
            session_id: 会话 ID（None 则自动创建）
            stream: 是否流式输出

        Returns:
            非流式返回完整回复文本，流式返回生成器
        """
        session_id = session_id or str(uuid.uuid4())
        display_msg = user_message[:100] + ("..." if len(user_message) > 100 else "")
        logger.info(f"💬 [{session_id[:8]}] 用户: {display_msg}")

        # 1. 注入记忆上下文
        memory_ctx = self.context.get_memory_context(user_message)
        if memory_ctx:
            user_message = f"{memory_ctx}\n\n[用户问题]\n{user_message}"

        # 2. 添加用户消息到上下文
        self.context.add_message(session_id, "user", user_message)

        if stream:
            return self._chat_stream(session_id)
        return self._chat_sync(session_id)

    def _chat_sync(self, session_id: str) -> str:
        """同步对话循环（支持工具调用）"""
        tools = self.skills.get_tools_schema()
        tools.extend(self._memory_tools_schema())

        messages = self.context.get_messages(session_id)
        executed_tools = []

        round_count = 0
        while round_count < self.max_tool_rounds:
            round_count += 1

            # 调用 LLM
            try:
                response = self.llm.route(messages=messages, tools=tools, stream=False)
            except Exception as e:
                logger.error(f"LLM 请求失败: {e}")
                error_msg = f"LLM 请求出错：{str(e)}"
                self.context.add_message(session_id, "assistant", error_msg)
                if self.on_thinking:
                    self.on_thinking(f"❌ {error_msg}")
                return error_msg

            # 检查 tool_calls
            tool_calls = response.get("tool_calls")
            if tool_calls:
                logger.info(f"🔧 工具调用轮次 {round_count}: {len(tool_calls)} 个工具")
                tool_names = [tc.get("function", {}).get("name", "?") for tc in tool_calls]
                executed_tools.extend(tool_names)

                if self.on_tool_call:
                    for tc in tool_calls:
                        func_info = tc.get("function", {})
                        self.on_tool_call(func_info.get("name", ""), func_info)

                if self.on_thinking:
                    self.on_thinking(f"🔧 正在调用工具: {', '.join(tool_names)}")

                # 构建 assistant 消息
                self.context.add_assistant_with_tool_calls(
                    session_id, response.get("content", ""), tool_calls,
                )
                # 执行工具
                try:
                    self.executor.execute_all(tool_calls, self.context, session_id)
                except Exception as e:
                    logger.error(f"工具执行失败: {e}")
                # 追加到 messages
                messages = self.context.get_messages(session_id)
                continue

            # 无工具调用：最终回复
            final_content = response.get("content", "")
            self.context.add_message(session_id, "assistant", final_content)
            return final_content

        # 达到最大轮数
        logger.warning(f"达到最大工具调用轮数 {self.max_tool_rounds}")
        summary = f"（已执行 {round_count} 轮工具调用，涉及: {', '.join(executed_tools[-5:])}。任务可能未完全完成，请尝试简化需求后重试。）"
        self.context.add_message(session_id, "assistant", summary)
        return summary

    def _chat_stream(self, session_id: str) -> Generator:
        """流式对话循环（支持工具调用）"""
        tools = self.skills.get_tools_schema()
        tools.extend(self._memory_tools_schema())

        round_count = 0
        executed_tools = []

        while round_count < self.max_tool_rounds:
            round_count += 1
            messages = self.context.get_messages(session_id)

            # 流式调用 LLM
            try:
                stream = self.llm.route(messages=messages, tools=tools, stream=True)
            except Exception as e:
                logger.error(f"LLM 流式请求失败: {e}")
                yield {"type": "error", "content": str(e)}
                return

            full_content = ""
            tool_calls_buffer = []
            current_tool_call = None

            for chunk in stream:
                content = chunk.get("content", "")
                tc_data = chunk.get("tool_calls")
                done = chunk.get("done", False)

                # 处理文本 token
                if content:
                    full_content += content
                    if self.on_token:
                        self.on_token(content)
                    yield {"type": "token", "content": content}

                # 处理流式 tool_calls
                if tc_data:
                    if isinstance(tc_data, list):
                        for tc in tc_data:
                            if tc.get("id"):
                                # 新的 tool_call 开始
                                if current_tool_call:
                                    tool_calls_buffer.append(current_tool_call)
                                current_tool_call = {
                                    "id": tc.get("id", ""),
                                    "type": tc.get("type", "function"),
                                    "function": tc.get("function", {}),
                                }
                            elif current_tool_call and tc.get("function"):
                                # 追加参数片段
                                func = tc.get("function", {})
                                if "arguments" in func and "arguments" in current_tool_call.get("function", {}):
                                    current_tool_call["function"]["arguments"] += func.get("arguments", "")
                                elif "name" in func:
                                    current_tool_call["function"]["name"] = func["name"]
                    elif isinstance(tc_data, dict):
                        if tc_data.get("id"):
                            if current_tool_call:
                                tool_calls_buffer.append(current_tool_call)
                            current_tool_call = {
                                "id": tc_data.get("id", ""),
                                "type": tc_data.get("type", "function"),
                                "function": tc_data.get("function", {}),
                            }
                        elif current_tool_call and tc_data.get("function"):
                            func = tc_data.get("function", {})
                            if "arguments" in func:
                                cur_args = current_tool_call.get("function", {}).get("arguments", "")
                                current_tool_call["function"]["arguments"] = cur_args + func.get("arguments", "")

                if done:
                    break

            # 收集最后一个 tool_call
            if current_tool_call:
                tool_calls_buffer.append(current_tool_call)

            # 有工具调用 → 执行后继续循环
            if tool_calls_buffer:
                tool_names = [tc.get("function", {}).get("name", "?") for tc in tool_calls_buffer]
                executed_tools.extend(tool_names)
                logger.info(f"🔧 流式工具调用轮次 {round_count}: {tool_names}")

                if self.on_tool_call:
                    for tc in tool_calls_buffer:
                        self.on_tool_call(tc.get("function", {}).get("name", ""), tc.get("function", {}))

                yield {"type": "tool_call", "tools": tool_names}

                # 记录 assistant 消息
                self.context.add_assistant_with_tool_calls(session_id, full_content, tool_calls_buffer)
                # 执行工具
                try:
                    self.executor.execute_all(tool_calls_buffer, self.context, session_id)
                except Exception as e:
                    logger.error(f"工具执行失败: {e}")
                continue

            # 无工具调用 → 最终回复
            self.context.add_message(session_id, "assistant", full_content)
            yield {"type": "done", "content": full_content}
            return

        # 达到最大轮数
        logger.warning(f"流式模式达到最大工具调用轮数 {self.max_tool_rounds}")
        summary = f"（已执行 {round_count} 轮工具调用，涉及: {', '.join(executed_tools[-5:])}。任务可能未完全完成。）"
        yield {"type": "done", "content": summary}

    def _memory_tools_schema(self) -> list[dict]:
        """记忆库工具定义"""
        return [
            {
                "type": "function",
                "function": {
                    "name": "memory_search",
                    "description": "搜索记忆库。执行任务前先用此工具查找相关记忆。",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "query": {"type": "string", "description": "搜索查询"},
                            "top_k": {"type": "integer", "description": "返回数量，默认 5"},
                            "category": {"type": "string", "description": "按分类筛选（可选）"},
                        },
                        "required": ["query"],
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "memory_add",
                    "description": "添加一条新记忆。当用户告诉你重要信息时使用。",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "title": {"type": "string", "description": "记忆标题"},
                            "content": {"type": "string", "description": "记忆内容"},
                            "category": {"type": "string", "description": "分类，默认'其他'"},
                            "importance": {"type": "integer", "description": "重要程度 1-5，默认 3"},
                            "tags": {"type": "string", "description": "标签（逗号分隔）"},
                        },
                        "required": ["title", "content"],
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "memory_list",
                    "description": "列出记忆库中的记忆，支持按分类和重要程度筛选。",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "category": {"type": "string", "description": "按分类筛选"},
                            "min_importance": {"type": "integer", "description": "最低重要程度"},
                            "limit": {"type": "integer", "description": "返回数量，默认 20"},
                        },
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "memory_set_importance",
                    "description": "设置记忆的重要程度（1-5星）。",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "id": {"type": "string", "description": "记忆 ID"},
                            "importance": {"type": "integer", "description": "重要程度 1-5"},
                        },
                        "required": ["id", "importance"],
                    },
                },
            },
        ]

    def get_status(self) -> dict:
        """获取 Agent 状态"""
        llm_status = self.llm.get_status()
        mem_stats = self.memory.get_stats()
        return {
            "llm": llm_status,
            "memory": mem_stats,
            "skills": len(self.skills.list_all()),
            "skills_enabled": len(self.skills.list_enabled()),
            "max_tool_rounds": self.max_tool_rounds,
        }
