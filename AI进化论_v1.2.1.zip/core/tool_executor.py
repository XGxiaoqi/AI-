"""
AI进化论 — 工具调用执行器
解析 LLM 返回的 tool_calls，执行对应的技能或内置操作
"""

import json
import threading
from typing import Any

from loguru import logger

from skills.manager import SkillManager
from memory.manager import MemoryManager


class ToolExecutor:
    """工具调用执行器"""

    # 单个工具执行超时（秒）
    TOOL_TIMEOUT = 60
    # 工具结果最大字符数
    MAX_RESULT_LENGTH = 10000

    def __init__(self, skill_manager: SkillManager, memory_manager: MemoryManager):
        self.skill_manager = skill_manager
        self.memory_manager = memory_manager

    def execute(self, tool_name: str, tool_args: dict) -> str:
        """
        执行单个工具调用，返回 JSON 字符串结果

        优先匹配记忆库操作，然后匹配技能库
        """
        logger.info(f"🔧 执行工具: {tool_name}({json.dumps(tool_args, ensure_ascii=False)[:200]})")

        try:
            # 1. 记忆库操作
            if tool_name == "memory_search":
                result = self._exec_memory_search(tool_args)
            elif tool_name == "memory_add":
                result = self._exec_memory_add(tool_args)
            elif tool_name == "memory_list":
                result = self._exec_memory_list(tool_args)
            elif tool_name == "memory_set_importance":
                result = self._exec_memory_set_importance(tool_args)
            else:
                # 2. 技能库
                result = self.skill_manager.execute(tool_name, tool_args)

            # 统一格式化为 JSON 字符串
            if isinstance(result, dict):
                result_str = json.dumps(result, ensure_ascii=False, default=str)
            else:
                result_str = str(result)

            # 限制结果长度
            if len(result_str) > self.MAX_RESULT_LENGTH:
                result_str = result_str[:self.MAX_RESULT_LENGTH] + f"\n...（结果已截断，原始长度 {len(result_str)} 字符）"

            return result_str

        except Exception as e:
            logger.error(f"工具执行异常 [{tool_name}]: {e}")
            return json.dumps({"error": f"工具执行失败: {str(e)}"}, ensure_ascii=False)

    def execute_all(self, tool_calls: list[dict], context, session_id: str) -> list[dict]:
        """
        执行一组工具调用，返回 tool 消息列表
        每个 tool_call 格式: {"id": "call_xxx", "function": {"name": "...", "arguments": "{...}"}}
        """
        results = []
        for tc in tool_calls:
            func_info = tc.get("function", {})
            func_name = func_info.get("name", "")
            func_args_str = func_info.get("arguments", "{}")

            # 解析参数
            try:
                func_args = json.loads(func_args_str) if isinstance(func_args_str, str) else func_args_str
            except json.JSONDecodeError as e:
                func_args = {}
                logger.warning(f"工具参数解析失败 [{func_name}]: {e}")

            # 执行（带超时保护）
            result_str = self._execute_with_timeout(func_name, func_args)

            # 构建 tool 消息
            results.append({
                "role": "tool",
                "tool_call_id": tc.get("id", ""),
                "name": func_name,
                "content": result_str,
            })

            # 加入上下文
            context.add_tool_result(session_id, tc.get("id", ""), func_name, result_str)

        return results

    def _execute_with_timeout(self, tool_name: str, tool_args: dict) -> str:
        """带超时的工具执行"""
        result_holder = [None]
        error_holder = [None]

        def target():
            try:
                result_holder[0] = self.execute(tool_name, tool_args)
            except Exception as e:
                error_holder[0] = e

        thread = threading.Thread(target=target, daemon=True)
        thread.start()
        thread.join(timeout=self.TOOL_TIMEOUT)

        if thread.is_alive():
            logger.warning(f"工具执行超时 [{tool_name}]: {self.TOOL_TIMEOUT}s")
            return json.dumps({"error": f"工具执行超时 ({self.TOOL_TIMEOUT}s)"}, ensure_ascii=False)

        if error_holder[0]:
            return json.dumps({"error": str(error_holder[0])}, ensure_ascii=False)

        return result_holder[0] or json.dumps({"error": "工具返回空结果"}, ensure_ascii=False)

    # ====== 记忆库工具 ======

    def _exec_memory_search(self, args: dict) -> str:
        query = args.get("query", "")
        top_k = args.get("top_k", 5)
        category = args.get("category")
        results = self.memory_manager.search_hybrid(query=query, top_k=top_k, category=category)
        if not results:
            return json.dumps({"message": "未找到相关记忆"}, ensure_ascii=False)
        return json.dumps([{
            "id": r.memory.id,
            "title": r.memory.title,
            "category": r.memory.category,
            "importance": r.memory.importance,
            "score": round(r.score, 3),
            "snippet": r.memory.snippet(300),
        } for r in results], ensure_ascii=False)

    def _exec_memory_add(self, args: dict) -> str:
        tags = args.get("tags", "").split(",") if args.get("tags") else []
        tags = [t.strip() for t in tags if t.strip()]
        mem = self.memory_manager.add_memory(
            title=args.get("title", ""),
            content=args.get("content", ""),
            category=args.get("category", "其他"),
            importance=int(args.get("importance", 3)),
            tags=tags,
        )
        return json.dumps({"id": mem.id, "title": mem.title, "status": "已记录"}, ensure_ascii=False)

    def _exec_memory_list(self, args: dict) -> str:
        memories = self.memory_manager.list_memories(
            category=args.get("category"),
            min_importance=int(args.get("min_importance", 0)),
            limit=int(args.get("limit", 20)),
        )
        return json.dumps([{
            "id": m.id, "title": m.title, "category": m.category,
            "importance": m.importance, "snippet": m.snippet(100),
        } for m in memories], ensure_ascii=False)

    def _exec_memory_set_importance(self, args: dict) -> str:
        memory_id = args.get("id", "")
        importance = int(args.get("importance", 3))
        ok = self.memory_manager.set_importance(memory_id, importance)
        return json.dumps({"id": memory_id, "importance": importance, "success": ok}, ensure_ascii=False)
