# AI进化论 — 配置管理模块
import os
import shutil
import yaml
from pathlib import Path
from typing import Any, Dict

VERSION = "1.2.1"

class Config:
    """全局配置管理器（单例）"""

    _instance: "Config | None" = None

    def __new__(cls, config_path: str | None = None):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._loaded = False
            cls._instance._data = {}
            cls._instance._config_path = ""
        return cls._instance

    def load(self, config_path: str = "./config.yaml") -> "Config":
        """加载配置文件"""
        if self._loaded:
            return self

        path = Path(config_path)
        if not path.exists():
            raise FileNotFoundError(f"配置文件不存在: {config_path}")

        with open(path, "r", encoding="utf-8") as f:
            self._data = yaml.safe_load(f) or {}

        # 确保版本信息
        if "system" not in self._data:
            self._data["system"] = {}
        self._data["system"]["version"] = VERSION

        # 确保数据目录存在
        data_path = Path(self.get("system.data_path", "./data"))
        data_path.mkdir(parents=True, exist_ok=True)
        (data_path / "logs").mkdir(parents=True, exist_ok=True)
        (data_path / "sessions").mkdir(parents=True, exist_ok=True)

        self._config_path = str(path)
        self._loaded = True
        return self

    def reload(self) -> "Config":
        """热加载配置文件"""
        if self._config_path:
            self._loaded = False
            self.load(self._config_path)
        return self

    def get(self, key: str, default: Any = None) -> Any:
        """获取配置值，支持点号分隔的嵌套键"""
        keys = key.split(".")
        value = self._data
        for k in keys:
            if isinstance(value, dict):
                if k not in value:  # 使用 'not in' 代替 'is None' 检查，修复 falsy 值 bug
                    return default
                value = value[k]
            else:
                return default
        return value

    def set(self, key: str, value: Any) -> None:
        """设置配置值"""
        keys = key.split(".")
        data = self._data
        for k in keys[:-1]:
            if k not in data or not isinstance(data[k], dict):
                data[k] = {}
            data = data[k]
        data[keys[-1]] = value

    def save(self, config_path: str = "") -> None:
        """保存配置到文件（自动备份）"""
        path = config_path or self._config_path or "./config.yaml"
        # 备份旧配置
        if os.path.exists(path):
            backup = path + ".bak"
            try:
                shutil.copy2(path, backup)
            except Exception:
                pass
        try:
            with open(path, "w", encoding="utf-8") as f:
                yaml.dump(self._data, f, allow_unicode=True, default_flow_style=False)
        except Exception as e:
            # 保存失败，恢复备份
            if os.path.exists(path + ".bak"):
                shutil.copy2(path + ".bak", path)
            raise

    @property
    def data(self) -> Dict[str, Any]:
        return self._data

    @property
    def version(self) -> str:
        return VERSION


# 全局配置实例
config = Config()
