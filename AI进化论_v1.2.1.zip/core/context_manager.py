"""
AI进化论 — 上下文管理器
管理对话历史、记忆注入、Token 预算控制
"""

import json
from typing import Any
from pathlib import Path
from loguru import logger

from memory.manager import MemoryManager


class ContextManager:
    """
    上下文管理器
    - 维护对话历史
    - 自动注入相关记忆
    - Token 预算控制
    - 会话持久化
    - 角色卡系统集成：激活的角色卡系统提示词作为最高优先级
    """

    # 大致的 token 估算：中文1字≈1.5 token，英文1词≈1 token
    TOKEN_RATIO_ZH = 1.5
    TOKEN_RATIO_EN = 0.25

    # 默认系统提示词（当无角色卡激活时使用）
    DEFAULT_SYSTEM_PROMPT = """你是「AI进化论」的智能 Agent，运行在用户的 Windows 电脑上。

## 你的能力
- 读写文件、管理项目
- 执行 Python 代码
- 搜索网页、抓取内容
- 操控浏览器（Playwright）
- 管理系统进程和命令
- 读写剪贴板
- 查询和管理记忆库
- 修改自身程序代码（自我进化）

## 行为准则
1. 当用户要求执行操作时，直接使用工具完成任务
2. 编程任务：先理解需求，再动手。不确定时先问
3. 主动使用记忆库：在回答前检索相关记忆
4. 重要信息自动存入记忆库（询问用户确认）
5. 回复简洁实用，中文优先
6. 使用 Markdown 格式回复，代码使用代码块

## 记忆系统
你有记忆能力。执行任务前，使用 memory_search 查看相关知识。
当用户告诉你重要信息时，使用 memory_add 记录下来。

## 自我修改
你可以通过 self_modify 技能修改自己的程序代码，实现自我进化。
修改前必须：1)理解当前代码 2)明确修改目标 3)创建备份 4)修改后验证语法"""

    def __init__(self, memory_manager: MemoryManager, max_history: int = 20, max_tokens: int = 30000):
        self.memory_manager = memory_manager
        self.max_history = max_history
        self.max_tokens = max_tokens  # 上下文 token 预算
        self._conversations: dict[str, list[dict]] = {}
        self._card_manager = None  # 角色卡管理器引用（延迟注入）

    def get_or_create_session(self, session_id: str) -> list[dict]:
        if session_id not in self._conversations:
            self._conversations[session_id] = []
        return self._conversations[session_id]

    def add_message(self, session_id: str, role: str, content: str, name: str | None = None):
        """添加一条消息到对话历史"""
        session = self.get_or_create_session(session_id)
        msg = {"role": role, "content": content}
        if name:
            msg["name"] = name
        session.append(msg)
        self._trim_context(session_id)

    def add_tool_result(self, session_id: str, tool_call_id: str, tool_name: str, result: str):
        """添加工具调用结果"""
        session = self.get_or_create_session(session_id)
        # 限制工具结果的长度，防止上下文溢出
        max_result_len = 8000
        if len(result) > max_result_len:
            result = result[:max_result_len] + f"\n...（结果已截断，原始长度 {len(result)} 字符）"
        session.append({
            "role": "tool",
            "tool_call_id": tool_call_id,
            "name": tool_name,
            "content": result,
        })

    def add_assistant_with_tool_calls(self, session_id: str, content: str, tool_calls: list[dict]):
        """添加包含工具调用的 assistant 消息"""
        session = self.get_or_create_session(session_id)
        session.append({
            "role": "assistant",
            "content": content,
            "tool_calls": tool_calls,
        })

    def get_messages(self, session_id: str, include_system: bool = True) -> list[dict]:
        """获取完整消息列表（含系统提示），确保 tool 消息链完整"""
        messages = []

        if include_system:
            messages.append(self._build_system_prompt())

        session = self.get_or_create_session(session_id)

        # 确保不会在 tool_calls 和对应的 tool 消息之间截断
        # 找到安全的截断点
        safe_messages = self._find_safe_messages(session)
        messages.extend(safe_messages)

        return messages

    def _find_safe_messages(self, session: list[dict]) -> list[dict]:
        """找到不截断 tool 消息链的最长消息序列"""
        if not session:
            return session

        # 从后往前找到第一个 tool_calls 消息链的起始位置
        # 确保每个 assistant(tool_calls) 后面都有对应的 tool 消息
        tool_call_ids_in_session = set()
        for msg in session:
            if msg.get("role") == "tool":
                tool_call_ids_in_session.add(msg.get("tool_call_id"))

        # 检查是否有未完成的 tool 消息链
        result = list(session)
        for i, msg in enumerate(result):
            if msg.get("role") == "assistant" and msg.get("tool_calls"):
                call_ids = {tc.get("id") for tc in msg["tool_calls"]}
                # 检查这些 call 是否都有对应的 tool 消息
                has_all_results = call_ids.issubset(tool_call_ids_in_session)
                if not has_all_results:
                    # 截断掉这个不完整的 tool_call 链
                    result = result[:i]
                    break

        return result

    def set_card_manager(self, card_manager):
        """注入角色卡管理器（延迟注入，避免循环依赖）"""
        self._card_manager = card_manager

    def _build_system_prompt(self) -> dict:
        """
        构建系统提示
        
        优先级规则：
        1. 角色卡系统提示词 = 最高优先级（无任何高于它的提示词）
        2. 如果无激活角色卡，使用默认系统提示词
        """
        # 最高优先级：角色卡系统提示词
        if self._card_manager:
            active_card = self._card_manager.get_active_card()
            if active_card and active_card.system_prompt:
                logger.debug(f"使用角色卡系统提示词: {active_card.name}")
                return {
                    "role": "system",
                    "content": active_card.system_prompt,
                }

        # 回退到默认系统提示词
        return {
            "role": "system",
            "content": self.DEFAULT_SYSTEM_PROMPT,
        }

    def _trim_context(self, session_id: str):
        """裁剪对话历史，基于 Token 预算和轮数双重限制"""
        session = self._conversations.get(session_id, [])
        if not session:
            return

        # 检查 token 预算
        total_tokens = self._estimate_tokens(session)

        if total_tokens <= self.max_tokens and len(session) <= self.max_history * 4:
            return

        # 需要裁剪：保留最近的对话，但确保 tool 消息链完整
        # 从前面开始删除，直到满足预算
        keep = list(session)

        while keep and (self._estimate_tokens(keep) > self.max_tokens or len(keep) > self.max_history * 4):
            # 找到第一个可以安全删除的消息
            # 不能删除 tool 消息链的中间部分
            if len(keep) < 2:
                break

            first = keep[0]
            # 如果第一条是 assistant 且有 tool_calls，要连同后面的 tool 消息一起删
            if first.get("role") == "assistant" and first.get("tool_calls"):
                call_ids = {tc.get("id") for tc in first["tool_calls"]}
                # 删除 assistant 消息和所有对应的 tool 消息
                keep.pop(0)
                while keep and keep[0].get("tool_call_id") in call_ids:
                    keep.pop(0)
            else:
                keep.pop(0)

        self._conversations[session_id] = keep
        logger.debug(f"对话历史已裁剪至 {len(keep)} 条消息（估计 {self._estimate_tokens(keep)} tokens）")

    def _estimate_tokens(self, messages: list[dict]) -> int:
        """估算消息列表的 token 数"""
        total = 0
        for msg in messages:
            content = msg.get("content", "")
            if not content:
                continue
            # 粗略估算：中文和英文分别计算
            zh_chars = sum(1 for c in content if '\u4e00' <= c <= '\u9fff')
            en_chars = len(content) - zh_chars
            total += int(zh_chars * self.TOKEN_RATIO_ZH + en_chars * self.TOKEN_RATIO_EN)
        return total

    def get_memory_context(self, query: str) -> str:
        """获取与查询相关的记忆上下文"""
        return self.memory_manager.get_context_memories(query, top_k=5)

    def clear_session(self, session_id: str):
        """清除对话历史"""
        self._conversations.pop(session_id, None)

    def get_stats(self, session_id: str | None = None) -> dict:
        """获取上下文统计"""
        if session_id:
            session = self._conversations.get(session_id, [])
        else:
            # 全部会话统计
            session = []
            for msgs in self._conversations.values():
                session.extend(msgs)

        total_chars = sum(len(m.get("content", "")) for m in session)
        return {
            "message_count": len(session),
            "total_chars": total_chars,
            "estimated_tokens": self._estimate_tokens(session),
            "session_count": len(self._conversations),
        }

    # ====== 会话持久化 ======

    def save_session(self, session_id: str, file_path: str) -> bool:
        """保存会话到文件"""
        session = self._conversations.get(session_id, [])
        if not session:
            return False
        try:
            Path(file_path).parent.mkdir(parents=True, exist_ok=True)
            with open(file_path, "w", encoding="utf-8") as f:
                json.dump({"session_id": session_id, "messages": session}, f, ensure_ascii=False, indent=2)
            return True
        except Exception as e:
            logger.error(f"保存会话失败: {e}")
            return False

    def load_session(self, file_path: str) -> str | None:
        """从文件加载会话，返回 session_id"""
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            session_id = data.get("session_id", "loaded")
            self._conversations[session_id] = data.get("messages", [])
            return session_id
        except Exception as e:
            logger.error(f"加载会话失败: {e}")
            return None
