"""
AI进化论 — 记忆管理器
整合 SQLite（结构化）+ ChromaDB（向量），提供统一的记忆 API
"""

from typing import Optional
from datetime import datetime

from loguru import logger

from memory.models import Memory, MemorySearchResult
from memory.sqlite_store import SQLiteStore
from memory.vector_store import VectorStore
from core.config import config


class MemoryManager:
    """记忆管理器 — 记忆库的统一入口"""

    def __init__(self):
        sqlite_path = config.get("memory.sqlite_path", "./data/memory.db")
        chroma_path = config.get("memory.chroma_path", "./data/chroma")

        self.sqlite = SQLiteStore(sqlite_path)
        self.vector = VectorStore(chroma_path)

        # 初始化默认分类
        for cat in config.get("memory.default_categories", []):
            self.sqlite.add_category(cat)

        self._hybrid_weight = config.get("memory.hybrid_weight", [0.7, 0.3])
        logger.info(f"记忆管理器初始化完成: SQL={self.sqlite.count()}条, Vector={self.vector.count()}条")

    # ====== 记忆 CRUD ======

    def add_memory(
        self,
        title: str,
        content: str,
        category: str = "其他",
        importance: int = 3,
        tags: list[str] | None = None,
    ) -> Memory:
        """添加一条新记忆"""
        memory = Memory(
            title=title,
            content=content,
            category=category,
            importance=max(1, min(5, importance)),
            tags=tags or [],
        )
        self.sqlite.add(memory)
        self.vector.add(memory)
        logger.info(f"记忆已添加: [{memory.category}] {memory.title} ⭐{memory.importance}")
        return memory

    def update_memory(self, memory: Memory) -> bool:
        """更新记忆"""
        success = self.sqlite.update(memory)
        if success:
            self.vector.update(memory)
            logger.info(f"记忆已更新: {memory.id}")
        return success

    def delete_memory(self, memory_id: str) -> bool:
        """删除记忆"""
        success = self.sqlite.delete(memory_id)
        if success:
            self.vector.delete(memory_id)
            logger.info(f"记忆已删除: {memory_id}")
        return success

    def get_memory(self, memory_id: str) -> Optional[Memory]:
        """获取单条记忆"""
        return self.sqlite.get(memory_id)

    def list_memories(
        self,
        category: str | None = None,
        min_importance: int = 0,
        tag: str | None = None,
        search_text: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list[Memory]:
        """列出记忆（结构化筛选）"""
        return self.sqlite.list_all(
            category=category,
            min_importance=min_importance,
            tag=tag,
            search_text=search_text,
            limit=limit,
            offset=offset,
        )

    def set_importance(self, memory_id: str, importance: int) -> bool:
        """手动设置记忆重要程度"""
        mem = self.sqlite.get(memory_id)
        if mem:
            mem.importance = max(1, min(5, importance))
            return self.update_memory(mem)
        return False

    def set_category(self, memory_id: str, category: str) -> bool:
        """修改记忆分类"""
        mem = self.sqlite.get(memory_id)
        if mem:
            mem.category = category
            return self.update_memory(mem)
        return False

    # ====== 语义检索 ======

    def search_semantic(
        self,
        query: str,
        top_k: int = 10,
        category: str | None = None,
    ) -> list[MemorySearchResult]:
        """语义搜索（仅向量）"""
        return self.vector.search(query, top_k=top_k, category=category)

    def search_keyword(self, query: str, limit: int = 20) -> list[MemorySearchResult]:
        """关键词搜索（SQLite LIKE）"""
        results = self.sqlite.list_all(search_text=query, limit=limit)
        return [MemorySearchResult(memory=m, score=1.0, source="keyword") for m in results]

    def search_hybrid(
        self,
        query: str,
        top_k: int = 10,
        category: str | None = None,
    ) -> list[MemorySearchResult]:
        """
        混合检索：结合向量语义 + 关键词匹配
        对结果去重合并，按综合分数排序
        """
        w_vec, w_key = self._hybrid_weight

        # 向量搜索
        vec_results = self.vector.search(query, top_k=top_k * 2, category=category)
        # 关键词搜索
        key_results = self.search_keyword(query, limit=top_k * 2)

        # 合并去重，计算综合分数
        memory_map: dict[str, MemorySearchResult] = {}
        for r in vec_results:
            memory_map[r.memory.id] = MemorySearchResult(
                memory=r.memory, score=r.score * w_vec, source="hybrid",
            )
        for r in key_results:
            if r.memory.id in memory_map:
                memory_map[r.memory.id].score += r.score * w_key
                # 用 SQLite 中的完整数据覆盖
                sqlite_mem = self.sqlite.get(r.memory.id)
                if sqlite_mem:
                    memory_map[r.memory.id].memory = sqlite_mem
            else:
                memory_map[r.memory.id] = MemorySearchResult(
                    memory=r.memory, score=r.score * w_key, source="hybrid",
                )

        # 排序取 top_k
        sorted_results = sorted(memory_map.values(), key=lambda x: x.score, reverse=True)
        results = sorted_results[:top_k]

        # 记录使用计数
        for r in results:
            self.sqlite.increment_use(r.memory.id)

        return results

    # ====== AI 上下文注入 ======

    def get_context_memories(
        self,
        query: str,
        top_k: int = 5,
        min_importance: int = 0,
    ) -> str:
        """
        获取与查询相关的记忆，格式化为可注入 LLM 上下文的文本
        """
        results = self.search_hybrid(query, top_k=top_k)
        if not results:
            return ""

        # 按重要程度过滤
        if min_importance > 0:
            results = [r for r in results if r.memory.importance >= min_importance]

        if not results:
            return ""

        lines = ["[相关记忆]"]
        for i, r in enumerate(results[:top_k], 1):
            m = r.memory
            stars = "⭐" * m.importance
            lines.append(f"{i}. [{m.category}] {m.title} {stars}")
            lines.append(f"   {m.snippet(200)}")
        return "\n".join(lines)

    # ====== 分类与标签 ======

    @property
    def categories(self) -> list[str]:
        return self.sqlite.list_categories()

    def add_category(self, name: str) -> bool:
        return self.sqlite.add_category(name)

    def remove_category(self, name: str) -> bool:
        return self.sqlite.delete_category(name)

    @property
    def tags(self) -> list[str]:
        return self.sqlite.list_tags()

    def add_tag(self, name: str) -> bool:
        return self.sqlite.add_tag(name)

    def remove_tag(self, name: str) -> bool:
        return self.sqlite.delete_tag(name)

    # ====== 统计 ======

    @property
    def total_count(self) -> int:
        return self.sqlite.count()

    def count_by_category(self) -> dict[str, int]:
        counts = {}
        for cat in self.categories:
            counts[cat] = self.sqlite.count(category=cat)
        return counts

    def get_stats(self) -> dict:
        """获取记忆库统计信息"""
        return {
            "total": self.total_count,
            "by_category": self.count_by_category(),
            "vector_count": self.vector.count(),
        }
