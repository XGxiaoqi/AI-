"""
AI进化论 — ChromaDB 向量存储
提供语义检索能力
"""

import os
from typing import Optional

import chromadb
from chromadb.config import Settings
from loguru import logger

from memory.models import Memory, MemorySearchResult


class VectorStore:
    """ChromaDB 向量存储，支持语义搜索"""

    def __init__(self, persist_path: str = "./data/chroma"):
        os.makedirs(persist_path, exist_ok=True)
        self._client = chromadb.PersistentClient(
            path=persist_path,
            settings=Settings(anonymized_telemetry=False),
        )
        self._collection = self._client.get_or_create_collection(
            name="memories",
            metadata={"hnsw:space": "cosine"},
        )
        logger.debug(f"ChromaDB 初始化完成，现有 {self._collection.count()} 条记忆")

    def add(self, memory: Memory) -> None:
        """将记忆加入向量索引"""
        self._collection.add(
            ids=[memory.id],
            documents=[memory.content],
            metadatas=[{
                "title": memory.title,
                "category": memory.category,
                "importance": memory.importance,
                "tags": ",".join(memory.tags),
                "use_count": memory.use_count,
            }],
        )

    def update(self, memory: Memory) -> None:
        """更新向量索引中的记忆"""
        self._collection.update(
            ids=[memory.id],
            documents=[memory.content],
            metadatas=[{
                "title": memory.title,
                "category": memory.category,
                "importance": memory.importance,
                "tags": ",".join(memory.tags),
                "use_count": memory.use_count,
            }],
        )

    def delete(self, memory_id: str) -> None:
        """从向量索引中删除"""
        self._collection.delete(ids=[memory_id])

    def search(
        self,
        query: str,
        top_k: int = 10,
        category: str | None = None,
    ) -> list[MemorySearchResult]:
        """语义搜索"""
        where_filter = None
        if category:
            where_filter = {"category": category}

        try:
            results = self._collection.query(
                query_texts=[query],
                n_results=top_k,
                where=where_filter,
            )
        except Exception as e:
            logger.warning(f"向量搜索失败: {e}")
            return []

        search_results = []
        if results and results["ids"] and results["ids"][0]:
            for i, mem_id in enumerate(results["ids"][0]):
                distance = results["distances"][0][i] if results.get("distances") else 0
                # 余弦距离转相似度
                score = 1.0 - float(distance) if distance else 0.0
                metadata = results["metadatas"][0][i] if results.get("metadatas") else {}
                document = results["documents"][0][i] if results.get("documents") else ""

                memory = Memory(
                    id=mem_id,
                    title=metadata.get("title", ""),
                    content=document,
                    category=metadata.get("category", "其他"),
                    importance=int(metadata.get("importance", 3)),
                    tags=(metadata.get("tags", "").split(",") if metadata.get("tags") else []),
                    use_count=int(metadata.get("use_count", 0)),
                )
                search_results.append(MemorySearchResult(
                    memory=memory,
                    score=round(score, 4),
                    source="vector",
                ))

        return search_results

    def count(self) -> int:
        """向量索引中的记忆数"""
        return self._collection.count()

    def clear(self) -> None:
        """清空向量索引"""
        self._client.delete_collection("memories")
        self._collection = self._client.create_collection(
            name="memories",
            metadata={"hnsw:space": "cosine"},
        )
