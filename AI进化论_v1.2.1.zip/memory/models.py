"""
AI进化论 — 记忆数据模型
"""

from dataclasses import dataclass, field, asdict
from datetime import datetime
from typing import Optional
import uuid


@dataclass
class Memory:
    """单条记忆"""

    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    title: str = ""  # 记忆标题
    content: str = ""  # 记忆内容
    category: str = "其他"  # 分类
    importance: int = 3  # 重要程度 1-5（手动标注）
    tags: list[str] = field(default_factory=list)  # 标签
    created_at: str = field(default_factory=lambda: datetime.now().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.now().isoformat())
    use_count: int = 0  # 被检索次数（自动统计）

    def to_dict(self) -> dict:
        d = asdict(self)
        d["tags"] = ",".join(self.tags) if self.tags else ""
        return d

    @classmethod
    def from_dict(cls, data: dict) -> "Memory":
        tags = data.get("tags", "")
        if isinstance(tags, str) and tags:
            tags = [t.strip() for t in tags.split(",") if t.strip()]
        elif not isinstance(tags, list):
            tags = []

        return cls(
            id=data.get("id", str(uuid.uuid4())),
            title=data.get("title", ""),
            content=data.get("content", ""),
            category=data.get("category", "其他"),
            importance=int(data.get("importance", 3)),
            tags=tags,
            created_at=data.get("created_at", datetime.now().isoformat()),
            updated_at=data.get("updated_at", datetime.now().isoformat()),
            use_count=int(data.get("use_count", 0)),
        )

    def snippet(self, max_len: int = 100) -> str:
        """生成内容摘要"""
        if len(self.content) <= max_len:
            return self.content
        return self.content[:max_len] + "..."


@dataclass
class MemorySearchResult:
    """记忆搜索结果"""

    memory: Memory
    score: float  # 相似度分数 0-1
    source: str  # 来源: "vector" / "keyword" / "hybrid"
