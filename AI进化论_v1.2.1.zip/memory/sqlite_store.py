"""
AI进化论 — SQLite 结构化存储
管理记忆的分类、标签、重要程度等结构化属性
"""

import sqlite3
import os
from datetime import datetime
from typing import Optional

from loguru import logger

from memory.models import Memory


class SQLiteStore:
    """SQLite 存储，管理记忆的结构化属性"""

    def __init__(self, db_path: str = "./data/memory.db"):
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        self.db_path = db_path
        self._init_db()

    def _get_conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")
        return conn

    def _init_db(self):
        """初始化数据库表"""
        with self._get_conn() as conn:
            conn.executescript("""
                CREATE TABLE IF NOT EXISTS memories (
                    id TEXT PRIMARY KEY,
                    title TEXT NOT NULL DEFAULT '',
                    content TEXT NOT NULL DEFAULT '',
                    category TEXT NOT NULL DEFAULT '其他',
                    importance INTEGER NOT NULL DEFAULT 3 CHECK(importance >= 1 AND importance <= 5),
                    tags TEXT DEFAULT '',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    use_count INTEGER DEFAULT 0
                );

                CREATE INDEX IF NOT EXISTS idx_category ON memories(category);
                CREATE INDEX IF NOT EXISTS idx_importance ON memories(importance);
                CREATE INDEX IF NOT EXISTS idx_updated ON memories(updated_at);
                CREATE INDEX IF NOT EXISTS idx_tags ON memories(tags);

                CREATE TABLE IF NOT EXISTS categories (
                    name TEXT PRIMARY KEY,
                    created_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS tags (
                    name TEXT PRIMARY KEY,
                    created_at TEXT NOT NULL
                );
            """)

    # ---------- CRUD ----------

    def add(self, memory: Memory) -> str:
        """添加记忆，返回 id"""
        with self._get_conn() as conn:
            conn.execute(
                """INSERT INTO memories (id, title, content, category, importance, tags, created_at, updated_at, use_count)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    memory.id, memory.title, memory.content,
                    memory.category, memory.importance,
                    ",".join(memory.tags), memory.created_at,
                    memory.updated_at, memory.use_count,
                ),
            )
        logger.debug(f"记忆已添加: {memory.id} - {memory.title}")
        return memory.id

    def update(self, memory: Memory) -> bool:
        """更新记忆"""
        memory.updated_at = datetime.now().isoformat()
        with self._get_conn() as conn:
            cursor = conn.execute(
                """UPDATE memories SET title=?, content=?, category=?, importance=?,
                   tags=?, updated_at=?, use_count=? WHERE id=?""",
                (
                    memory.title, memory.content, memory.category,
                    memory.importance, ",".join(memory.tags),
                    memory.updated_at, memory.use_count, memory.id,
                ),
            )
            return cursor.rowcount > 0

    def delete(self, memory_id: str) -> bool:
        """删除记忆"""
        with self._get_conn() as conn:
            cursor = conn.execute("DELETE FROM memories WHERE id=?", (memory_id,))
            return cursor.rowcount > 0

    def get(self, memory_id: str) -> Optional[Memory]:
        """按 ID 获取记忆"""
        with self._get_conn() as conn:
            row = conn.execute("SELECT * FROM memories WHERE id=?", (memory_id,)).fetchone()
            if row:
                return Memory.from_dict(dict(row))
            return None

    def list_all(
        self,
        category: str | None = None,
        min_importance: int = 0,
        tag: str | None = None,
        search_text: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list[Memory]:
        """列出记忆，支持筛选"""
        conditions = []
        params: list = []

        if category:
            conditions.append("category = ?")
            params.append(category)
        if min_importance > 0:
            conditions.append("importance >= ?")
            params.append(min_importance)
        if tag:
            conditions.append("tags LIKE ?")
            params.append(f"%{tag}%")
        if search_text:
            conditions.append("(title LIKE ? OR content LIKE ?)")
            params.extend([f"%{search_text}%", f"%{search_text}%"])

        where = ("WHERE " + " AND ".join(conditions)) if conditions else ""
        query = f"SELECT * FROM memories {where} ORDER BY updated_at DESC LIMIT ? OFFSET ?"
        params.extend([limit, offset])

        with self._get_conn() as conn:
            rows = conn.execute(query, params).fetchall()
            return [Memory.from_dict(dict(r)) for r in rows]

    def count(self, category: str | None = None) -> int:
        """统计记忆数量"""
        with self._get_conn() as conn:
            if category:
                row = conn.execute(
                    "SELECT COUNT(*) as cnt FROM memories WHERE category=?", (category,)
                ).fetchone()
            else:
                row = conn.execute("SELECT COUNT(*) as cnt FROM memories").fetchone()
            return row["cnt"] if row else 0

    def increment_use(self, memory_id: str):
        """增加使用计数"""
        with self._get_conn() as conn:
            conn.execute(
                "UPDATE memories SET use_count = use_count + 1, updated_at=? WHERE id=?",
                (datetime.now().isoformat(), memory_id),
            )

    # ---------- 分类管理 ----------

    def list_categories(self) -> list[str]:
        with self._get_conn() as conn:
            rows = conn.execute("SELECT name FROM categories ORDER BY name").fetchall()
            return [r["name"] for r in rows]

    def add_category(self, name: str) -> bool:
        try:
            with self._get_conn() as conn:
                conn.execute(
                    "INSERT INTO categories (name, created_at) VALUES (?, ?)",
                    (name, datetime.now().isoformat()),
                )
            return True
        except sqlite3.IntegrityError:
            return False  # 已存在

    def delete_category(self, name: str) -> bool:
        with self._get_conn() as conn:
            cursor = conn.execute("DELETE FROM categories WHERE name=?", (name,))
            return cursor.rowcount > 0

    # ---------- 标签管理 ----------

    def list_tags(self) -> list[str]:
        with self._get_conn() as conn:
            rows = conn.execute("SELECT name FROM tags ORDER BY name").fetchall()
            return [r["name"] for r in rows]

    def add_tag(self, name: str) -> bool:
        try:
            with self._get_conn() as conn:
                conn.execute(
                    "INSERT INTO tags (name, created_at) VALUES (?, ?)",
                    (name, datetime.now().isoformat()),
                )
            return True
        except sqlite3.IntegrityError:
            return False

    def delete_tag(self, name: str) -> bool:
        with self._get_conn() as conn:
            cursor = conn.execute("DELETE FROM tags WHERE name=?", (name,))
            return cursor.rowcount > 0
