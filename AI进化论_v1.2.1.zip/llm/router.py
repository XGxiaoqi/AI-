"""
AI进化论 — LLM 智能路由
根据任务复杂度自动选择本地/云端模型
"""

from typing import Iterator

from loguru import logger

from llm.ollama_client import OllamaClient
from llm.api_client import CloudAPIClient


class LLMRouter:
    """
    LLM 智能路由器
    - 简单任务 → 本地 Ollama（快速、免费）
    - 复杂任务 → 云端 API（能力强）
    - 用户可强制指定
    """

    def __init__(self):
        self.ollama = OllamaClient()
        self.cloud = CloudAPIClient()
        self._local_enabled = self.ollama.check_health()
        self._cloud_providers = self.cloud.list_providers()

        if not self._local_enabled:
            logger.warning("Ollama 不可用，将仅使用云端 API")
        if not self._cloud_providers:
            logger.warning("未配置云端 API，将仅使用本地模型")
        if not self._local_enabled and not self._cloud_providers:
            logger.error("没有任何可用的 LLM 后端！请安装 Ollama 或配置云端 API Key")

    @property
    def local_available(self) -> bool:
        return self._local_enabled

    @property
    def cloud_available(self) -> bool:
        return len(self._cloud_providers) > 0

    def list_local_models(self) -> list[str]:
        return self.ollama.list_models()

    def list_cloud_providers(self) -> list[str]:
        return self._cloud_providers

    def route(
        self,
        messages: list[dict],
        tools: list[dict] | None = None,
        force_provider: str | None = None,
        stream: bool = False,
    ) -> dict | Iterator[dict]:
        """
        智能路由发送请求

        Args:
            messages: 消息列表
            tools: 工具定义
            force_provider: 强制指定 provider (local / deepseek / aliyun_bailian)
            stream: 是否流式

        Returns:
            响应 dict 或流式迭代器
        """
        # 用户强制指定
        if force_provider == "local":
            return self.ollama.chat(messages, tools=tools, stream=stream)
        if force_provider and force_provider in self.PROVIDER_MAP:
            return self.cloud.chat(messages, provider=force_provider, tools=tools, stream=stream)

        # 自动路由：有工具调用需求 → 云端（能力更强）；否则 → 本地
        if tools and self.cloud_available:
            provider = self._cloud_providers[0]
            logger.info(f"检测到工具调用需求，使用云端 {provider}")
            return self.cloud.chat(messages, provider=provider, tools=tools, stream=stream)

        # 有云端但没工具：估算 token 决定
        if self.cloud_available and self._is_complex_task(messages):
            provider = self._cloud_providers[0]
            logger.info(f"复杂任务，使用云端 {provider}")
            return self.cloud.chat(messages, provider=provider, tools=tools, stream=stream)

        # 默认走本地
        if self._local_enabled:
            logger.info("使用本地 Ollama 模型")
            return self.ollama.chat(messages, tools=tools, stream=stream)

        # 本地不可用，走云端
        if self.cloud_available:
            provider = self._cloud_providers[0]
            logger.info(f"本地不可用，使用云端 {provider}")
            return self.cloud.chat(messages, provider=provider, tools=tools, stream=stream)

        raise RuntimeError("没有可用的 LLM 后端")

    PROVIDER_MAP = {"deepseek": True, "aliyun_bailian": True}

    def _is_complex_task(self, messages: list[dict]) -> bool:
        """简单判断任务复杂度（基于总 text 长度）"""
        threshold = 2000  # 字符
        total_text = ""
        for msg in messages:
            total_text += msg.get("content", "")
            # 也检查 tool 返回的内容
            if msg.get("role") == "tool":
                total_text += msg.get("content", "")
        return len(total_text) > threshold

    def get_status(self) -> dict:
        """获取后端状态"""
        return {
            "local": {
                "available": self._local_enabled,
                "models": self.ollama.list_models() if self._local_enabled else [],
            },
            "cloud": {
                "available": self.cloud_available,
                "providers": self._cloud_providers,
            },
        }
