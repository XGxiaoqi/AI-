"""
AI进化论 — Ollama 本地模型客户端
"""

import json
from typing import AsyncIterator, Iterator
import httpx
from loguru import logger

from core.config import config


class OllamaClient:
    """Ollama 本地模型客户端，支持同步和流式调用"""

    def __init__(self):
        self.base_url = config.get("llm.local.base_url", "http://localhost:11434")
        self.default_model = config.get("llm.local.default_model", "qwen3-coder:latest")
        self._available_models: list[str] | None = None

    def _url(self, path: str) -> str:
        return f"{self.base_url}{path}"

    def list_models(self) -> list[str]:
        """获取已安装的模型列表"""
        if self._available_models is not None:
            return self._available_models

        try:
            with httpx.Client(timeout=5) as client:
                resp = client.get(self._url("/api/tags"))
                if resp.status_code == 200:
                    models = [m["name"] for m in resp.json().get("models", [])]
                    self._available_models = models
                    return models
        except Exception as e:
            logger.warning(f"无法连接 Ollama: {e}")

        self._available_models = []
        return []

    def check_health(self) -> bool:
        """检查 Ollama 服务是否可用"""
        try:
            with httpx.Client(timeout=3) as client:
                resp = client.get(self._url("/api/tags"))
                return resp.status_code == 200
        except Exception:
            return False

    def chat(
        self,
        messages: list[dict],
        model: str | None = None,
        temperature: float = 0.7,
        tools: list[dict] | None = None,
        stream: bool = False,
    ) -> dict | Iterator[dict]:
        """
        发送对话请求

        Args:
            messages: 消息列表 [{"role": "user", "content": "..."}]
            model: 模型名称，默认使用配置中的 default_model
            temperature: 采样温度
            tools: 工具定义列表（Function Calling）
            stream: 是否流式输出

        Returns:
            非流式返回完整响应 dict，流式返回迭代器
        """
        model = model or self.default_model
        payload = {
            "model": model,
            "messages": messages,
            "temperature": temperature,
            "stream": stream,
            "options": {"num_ctx": 32768},
        }
        if tools:
            payload["tools"] = tools

        if stream:
            return self._stream_chat(payload)
        return self._sync_chat(payload)

    def _sync_chat(self, payload: dict) -> dict:
        """同步请求"""
        try:
            with httpx.Client(timeout=120) as client:
                resp = client.post(self._url("/api/chat"), json=payload)
                resp.raise_for_status()
                return self._parse_response(resp.json())
        except httpx.HTTPError as e:
            logger.error(f"Ollama 请求失败: {e}")
            raise

    def _stream_chat(self, payload: dict) -> Iterator[dict]:
        """流式请求，返回迭代器"""
        try:
            with httpx.Client(timeout=120) as client:
                with client.stream("POST", self._url("/api/chat"), json=payload) as resp:
                    resp.raise_for_status()
                    for line in resp.iter_lines():
                        if line:
                            try:
                                chunk = json.loads(line)
                                yield self._parse_stream_chunk(chunk)
                            except json.JSONDecodeError:
                                continue
        except httpx.HTTPError as e:
            logger.error(f"Ollama 流式请求失败: {e}")
            raise

    def _parse_response(self, data: dict) -> dict:
        """解析 Ollama 响应为统一格式"""
        message = data.get("message", {})
        return {
            "role": message.get("role", "assistant"),
            "content": message.get("content", ""),
            "tool_calls": message.get("tool_calls"),
            "model": data.get("model", ""),
            "usage": {
                "prompt_tokens": data.get("prompt_eval_count", 0),
                "completion_tokens": data.get("eval_count", 0),
            },
        }

    def _parse_stream_chunk(self, chunk: dict) -> dict:
        """解析流式块"""
        message = chunk.get("message", {})
        return {
            "role": "assistant",
            "content": message.get("content", ""),
            "tool_calls": message.get("tool_calls"),
            "done": chunk.get("done", False),
        }

    def pull_model(self, model_name: str) -> bool:
        """拉取模型（下载）"""
        try:
            with httpx.Client(timeout=600) as client:
                resp = client.post(
                    self._url("/api/pull"),
                    json={"name": model_name, "stream": False},
                )
                if resp.status_code == 200:
                    logger.info(f"模型 {model_name} 拉取成功")
                    self._available_models = None  # 刷新缓存
                    return True
                logger.error(f"模型拉取失败: {resp.text}")
                return False
        except Exception as e:
            logger.error(f"拉取模型出错: {e}")
            return False
