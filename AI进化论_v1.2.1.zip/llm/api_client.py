"""
AI进化论 — 云端 API 客户端（DeepSeek + 阿里百炼）
统一使用 OpenAI 兼容格式
"""

from typing import Iterator
from openai import OpenAI
from loguru import logger

from core.config import config


class CloudAPIClient:
    """云端 API 客户端，支持多 Provider"""

    # Provider 配置映射
    PROVIDERS = {
        "deepseek": {
            "config_key": "llm.cloud.providers.deepseek",
            "default_base": "https://api.deepseek.com",
            "default_model": "deepseek-chat",
        },
        "aliyun_bailian": {
            "config_key": "llm.cloud.providers.aliyun_bailian",
            "default_base": "https://dashscope.aliyuncs.com/compatible-mode/v1",
            "default_model": "qwen-plus",
        },
    }

    def __init__(self):
        self._clients: dict[str, OpenAI] = {}

    def _get_client(self, provider: str) -> OpenAI | None:
        """获取或创建指定 provider 的客户端"""
        if provider not in self.PROVIDERS:
            logger.error(f"未知的 Provider: {provider}")
            return None

        if provider in self._clients:
            return self._clients[provider]

        info = self.PROVIDERS[provider]
        api_key = config.get(f"{info['config_key']}.api_key", "")
        base_url = config.get(f"{info['config_key']}.base_url", info["default_base"])

        if not api_key:
            logger.warning(f"Provider {provider} 未配置 API Key")
            return None

        client = OpenAI(api_key=api_key, base_url=base_url)
        self._clients[provider] = client
        return client

    def get_default_model(self, provider: str) -> str:
        """获取 provider 的默认模型"""
        info = self.PROVIDERS.get(provider, {})
        return config.get(
            f"{info.get('config_key', '')}.default_model",
            info.get("default_model", ""),
        )

    def list_providers(self) -> list[str]:
        """列出已配置的 Provider"""
        available = []
        for name in self.PROVIDERS:
            api_key = config.get(f"llm.cloud.providers.{name}.api_key", "")
            if api_key:
                available.append(name)
        return available

    def list_models(self, provider: str) -> list[str]:
        """列出 provider 的可用模型"""
        info = self.PROVIDERS.get(provider, {})
        return config.get(f"{info.get('config_key', '')}.models", [])

    def chat(
        self,
        messages: list[dict],
        provider: str = "deepseek",
        model: str | None = None,
        temperature: float = 0.7,
        tools: list[dict] | None = None,
        stream: bool = False,
    ) -> dict | Iterator[dict]:
        """
        发送对话请求

        Args:
            messages: 消息列表
            provider: Provider 名称 (deepseek / aliyun_bailian)
            model: 模型名称，默认使用配置
            temperature: 采样温度
            tools: 工具定义
            stream: 是否流式输出
        """
        client = self._get_client(provider)
        if client is None:
            raise RuntimeError(f"Provider {provider} 不可用，请检查 API Key 配置")

        model = model or self.get_default_model(provider)
        kwargs = {
            "model": model,
            "messages": messages,
            "temperature": temperature,
            "stream": stream,
        }
        if tools:
            kwargs["tools"] = tools

        if stream:
            return self._stream_chat(client, **kwargs)
        return self._sync_chat(client, **kwargs)

    def _sync_chat(self, client: OpenAI, **kwargs) -> dict:
        """同步请求"""
        try:
            response = client.chat.completions.create(**kwargs)
            choice = response.choices[0]
            msg = choice.message
            return {
                "role": "assistant",
                "content": msg.content or "",
                "tool_calls": [
                    {
                        "id": tc.id,
                        "type": tc.type,
                        "function": {
                            "name": tc.function.name,
                            "arguments": tc.function.arguments,
                        },
                    }
                    for tc in (msg.tool_calls or [])
                ],
                "model": response.model,
                "usage": {
                    "prompt_tokens": response.usage.prompt_tokens if response.usage else 0,
                    "completion_tokens": response.usage.completion_tokens if response.usage else 0,
                },
            }
        except Exception as e:
            logger.error(f"云端 API 请求失败: {e}")
            raise

    def _stream_chat(self, client: OpenAI, **kwargs) -> Iterator[dict]:
        """流式请求（支持 tool_calls）"""
        try:
            stream = client.chat.completions.create(**kwargs)
            for chunk in stream:
                if chunk.choices and chunk.choices[0]:
                    choice = chunk.choices[0]
                    delta = choice.delta

                    # 处理流式 tool_calls
                    tc_data = None
                    if delta.tool_calls:
                        tc_data = []
                        for tc in delta.tool_calls:
                            tc_item = {}
                            if tc.id:
                                tc_item["id"] = tc.id
                            if tc.type:
                                tc_item["type"] = tc.type
                            if tc.function:
                                func = {}
                                if tc.function.name:
                                    func["name"] = tc.function.name
                                if tc.function.arguments:
                                    func["arguments"] = tc.function.arguments
                                tc_item["function"] = func
                            tc_data.append(tc_item)

                    yield {
                        "role": "assistant",
                        "content": delta.content or "",
                        "tool_calls": tc_data,
                        "done": choice.finish_reason is not None,
                    }
        except Exception as e:
            logger.error(f"云端 API 流式请求失败: {e}")
            raise

    def check_health(self, provider: str = "deepseek") -> bool:
        """检查 Provider 是否可用"""
        client = self._get_client(provider)
        if client is None:
            return False
        try:
            client.models.list()
            return True
        except Exception:
            return False
